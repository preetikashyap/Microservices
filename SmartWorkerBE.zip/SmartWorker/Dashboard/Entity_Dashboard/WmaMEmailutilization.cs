﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMEmailutilization
    {
        public WmaMEmailutilization()
        {
            WmaLEmailutilizationprojectrolemappings = new HashSet<WmaLEmailutilizationprojectrolemapping>();
        }

        public int EmailutilizationId { get; set; }
        public string EmailutilizationVc { get; set; }
        public int? AccessrolelevelId { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual ICollection<WmaLEmailutilizationprojectrolemapping> WmaLEmailutilizationprojectrolemappings { get; set; }
    }
}
