﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMDay
    {
        public int Dayid { get; set; }
        public int Day { get; set; }
        public string Daysrefname { get; set; }
    }
}
