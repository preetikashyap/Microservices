﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMCertificatetype
    {
        public WmaMCertificatetype()
        {
            WmaLCertificationdetails = new HashSet<WmaLCertificationdetail>();
        }

        public int CertificatetypeId { get; set; }
        public string Certificatetypename { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLCertificationdetail> WmaLCertificationdetails { get; set; }
    }
}
