﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMSkilllevel
    {
        public WmaMSkilllevel()
        {
            WmaLWorkerprojecttradedetails = new HashSet<WmaLWorkerprojecttradedetail>();
            WmaLWorkerprojecttradedetailshistories = new HashSet<WmaLWorkerprojecttradedetailshistory>();
            WmaMWageMinwages = new HashSet<WmaMWageMinwage>();
        }

        public int SkilllevelId { get; set; }
        public string SkilllevelVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetailshistory> WmaLWorkerprojecttradedetailshistories { get; set; }
        public virtual ICollection<WmaMWageMinwage> WmaMWageMinwages { get; set; }
    }
}
