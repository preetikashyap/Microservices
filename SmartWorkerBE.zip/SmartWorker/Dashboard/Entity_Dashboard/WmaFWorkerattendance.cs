﻿using System;
using System.Collections.Generic;
using System.Collections;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkerattendance
    {
        public int WorkerattendanceId { get; set; }
        public long? WorkerId { get; set; }
        public DateTime? AttendancescanningonDt { get; set; }
        public DateTime? AttendancesubmittedonDt { get; set; }
        public int? ProjectId { get; set; }
        public bool IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string ShiftVc { get; set; }
        public string SourceVc { get; set; }
        public string Errormessage { get; set; }
        public long? AwsfacerecognitiontransactionId { get; set; }
        public DateTime? ChosendateDt { get; set; }
        public string SectionVc { get; set; }
        public int? InsertedineipNb { get; set; }
        public string ResponsemsgofeipVc { get; set; }
        public string LatitudeVc { get; set; }
        public string LongitudeVc { get; set; }
        public DateTime? AttendanceoutscanningonDt { get; set; }
        public DateTime? AttendanceoutsubmittedonDt { get; set; }
        public int? ShiftId { get; set; }
        public string LocationVc { get; set; }
        public string OutsourceVc { get; set; }
        public string Outerrormessage { get; set; }
        public long? OutawsfacerecognitiontransactionId { get; set; }
        public DateTime? OutchosendateDt { get; set; }
        public string OutlatitudeVc { get; set; }
        public string OutlongitudeVc { get; set; }
        public string OutlocationVc { get; set; }
        public BitArray OtflagBt { get; set; }
    }
}
