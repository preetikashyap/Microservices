﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLAdminuserprojectlevelaccess
    {
        public WmaLAdminuserprojectlevelaccess()
        {
            WmaLAdminuserprojectlevelaccesshistories = new HashSet<WmaLAdminuserprojectlevelaccesshistory>();
        }

        public long AdminuserprojectlevelaccessId { get; set; }
        public long? UserId { get; set; }
        public long? RoleId { get; set; }
        public long? ProjectId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatdonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMRole Role { get; set; }
        public virtual WmaMUser User { get; set; }
        public virtual ICollection<WmaLAdminuserprojectlevelaccesshistory> WmaLAdminuserprojectlevelaccesshistories { get; set; }
    }
}
