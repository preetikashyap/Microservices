﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMTokenmanager
    {
        public int TokenmanagerId { get; set; }
        public string TokenVc { get; set; }
        public DateTime? CreatedonDt { get; set; }
    }
}
