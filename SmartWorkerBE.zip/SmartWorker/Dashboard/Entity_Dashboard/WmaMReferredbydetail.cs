﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMReferredbydetail
    {
        public long Referredid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public string ReferredbyName { get; set; }
        public string ReferredbyEmailid { get; set; }
        public DateTime? ReferredbyDate { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
