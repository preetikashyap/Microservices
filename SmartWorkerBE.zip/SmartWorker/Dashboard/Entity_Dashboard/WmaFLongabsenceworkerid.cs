﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFLongabsenceworkerid
    {
        public int Longabsenceworkerid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public DateTime Dateoflongabsence { get; set; }
    }
}
