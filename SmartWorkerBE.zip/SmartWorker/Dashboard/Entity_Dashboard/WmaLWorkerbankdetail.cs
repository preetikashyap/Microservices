﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWorkerbankdetail
    {
        public long BankdetailId { get; set; }
        public long WorkerId { get; set; }
        public string AccountholdernameVc { get; set; }
        public long? BankaccountnoNb { get; set; }
        public string BanknameVc { get; set; }
        public string BranchnameVc { get; set; }
        public string BranchaddrVc { get; set; }
        public string IfsccodeVc { get; set; }
        public string BankregisteredemailVc { get; set; }
        public string EsiVc { get; set; }
        public long? UannoNb { get; set; }
        public string UannameVc { get; set; }
        public string PfnumberVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public long? MicrNb { get; set; }
        public long? IbanNb { get; set; }
        public string AccounttypeVc { get; set; }
        public string BankaccountnoVc { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
