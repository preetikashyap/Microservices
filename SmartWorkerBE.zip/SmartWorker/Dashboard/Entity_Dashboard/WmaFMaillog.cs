﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFMaillog
    {
        public long Id { get; set; }
        public string Mailsubject { get; set; }
        public string Mailbody { get; set; }
        public string Responsecode { get; set; }
        public string Error { get; set; }
        public string Mailsentto { get; set; }
        public bool? Isattachmentincluded { get; set; }
        public string Attachmentpath { get; set; }
        public int? Mailtype { get; set; }
        public DateTime? Createdon { get; set; }
        public long? Createdby { get; set; }
    }
}
