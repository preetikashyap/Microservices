﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMCoviddose
    {
        public WmaMCoviddose()
        {
            WmaFCovidvaccinationdetailFirstcoviddoses = new HashSet<WmaFCovidvaccinationdetail>();
            WmaFCovidvaccinationdetailSecondcoviddoses = new HashSet<WmaFCovidvaccinationdetail>();
        }

        public long CoviddoseId { get; set; }
        public string CoviddosenameVc { get; set; }
        public bool? IsactiveBt { get; set; }

        public virtual ICollection<WmaFCovidvaccinationdetail> WmaFCovidvaccinationdetailFirstcoviddoses { get; set; }
        public virtual ICollection<WmaFCovidvaccinationdetail> WmaFCovidvaccinationdetailSecondcoviddoses { get; set; }
    }
}
