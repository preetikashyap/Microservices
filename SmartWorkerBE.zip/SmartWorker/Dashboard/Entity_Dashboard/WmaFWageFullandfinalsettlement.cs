﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWageFullandfinalsettlement
    {
        public long Id { get; set; }
        public long? Projectid { get; set; }
        public long Workerid { get; set; }
        public long Releievingtradeid { get; set; }
        public double Releivingwage { get; set; }
        public DateTime? Gratutityfromdate { get; set; }
        public DateTime? Gratutitytodate { get; set; }
        public double? Gratuityamount { get; set; }
        public DateTime Relievingdate { get; set; }
        public double Releievingwage { get; set; }
        public int Releivingelbalance { get; set; }
        public double Encashmentamount { get; set; }
        public double Total { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
