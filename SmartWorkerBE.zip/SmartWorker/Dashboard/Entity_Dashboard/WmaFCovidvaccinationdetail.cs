﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFCovidvaccinationdetail
    {
        public long CovidvaccinationId { get; set; }
        public long? WorkerId { get; set; }
        public long? FirstcoviddoseId { get; set; }
        public DateTime? FirstcoviddoseDt { get; set; }
        public long? SecondcoviddoseId { get; set; }
        public DateTime? SeconddoseDt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedbyDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedbyDt { get; set; }
        public bool? IsactiveBt { get; set; }

        public virtual WmaMCoviddose Firstcoviddose { get; set; }
        public virtual WmaMCoviddose Secondcoviddose { get; set; }
    }
}
