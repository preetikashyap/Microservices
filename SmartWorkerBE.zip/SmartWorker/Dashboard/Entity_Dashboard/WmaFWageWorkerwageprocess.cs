﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWageWorkerwageprocess
    {
        public long Workerwageprocessid { get; set; }
        public long Workerwagemappingid { get; set; }
        public DateTime Processingmonth { get; set; }
        public decimal Wage { get; set; }
        public int Totalworkingdays { get; set; }
        public string Workingdays { get; set; }
        public double Totalwage { get; set; }
        public int Totalothours { get; set; }
        public decimal Totalot { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }
    }
}
