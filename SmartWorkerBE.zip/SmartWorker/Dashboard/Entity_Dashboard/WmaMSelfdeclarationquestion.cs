﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMSelfdeclarationquestion
    {
        public WmaMSelfdeclarationquestion()
        {
            WmaFWorkerselfdeclarationmaps = new HashSet<WmaFWorkerselfdeclarationmap>();
        }

        public int Sdqid { get; set; }
        public string Sdq { get; set; }
        public string Header { get; set; }
        public string Subheader { get; set; }
        public string Optiontype { get; set; }
        public string Options { get; set; }
        public bool Isactive { get; set; }
        public bool Isdatereq { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public virtual ICollection<WmaFWorkerselfdeclarationmap> WmaFWorkerselfdeclarationmaps { get; set; }
    }
}
