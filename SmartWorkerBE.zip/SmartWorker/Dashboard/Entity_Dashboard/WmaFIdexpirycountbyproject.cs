﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFIdexpirycountbyproject
    {
        public int Idexpirycount { get; set; }
        public int Projectid { get; set; }
        public int Day { get; set; }
        public int Totalcount { get; set; }
    }
}
