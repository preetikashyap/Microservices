﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWageWorkerwagemappinghistory
    {
        public long Historyid { get; set; }
        public long Workerwagemappingid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public int Tradeid { get; set; }
        public long Wageid { get; set; }
        public long? Workerwageapprovalid { get; set; }
        public decimal Basicwage { get; set; }
        public decimal Da { get; set; }
        public decimal Others { get; set; }
        public decimal? Recommendedwage { get; set; }
        public DateTime Effectfrom { get; set; }
        public DateTime? Effecttill { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
    }
}
