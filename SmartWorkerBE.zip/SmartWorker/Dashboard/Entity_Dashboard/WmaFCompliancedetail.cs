﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFCompliancedetail
    {
        public int SitelicenseId { get; set; }
        public int? LicensetypeId { get; set; }
        public int? ProjectId { get; set; }
        public string LicensenoVc { get; set; }
        public DateTime? ExpiryonDt { get; set; }
        public string IssuedbyofficeaddressVc { get; set; }
        public int? WorkmencountNb { get; set; }
        public DateTime? ValidtillDt { get; set; }
        public double? SecuritydepositperworkmenFt { get; set; }
        public double? DepositamountFt { get; set; }
        public string RemarksVc { get; set; }
        public string DocumentattachmentnameVc { get; set; }
        public string DocumentattachmenturlVc { get; set; }
        public string DocumentattachmentformatVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public DateTime? ValidfromDt { get; set; }
        public DateTime? IssuedonDt { get; set; }
        public string Issuedby { get; set; }
        public string Occupiername { get; set; }
        public string Registrationno { get; set; }

        public virtual WmaMLicensetype Licensetype { get; set; }
        public virtual WmaMProject Project { get; set; }
    }
}
