﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLRoletradegroupmapping
    {
        public long RoleTradegrpId { get; set; }
        public long? RoleId { get; set; }
        public int? TradegroupId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public DateTime? CreatedbyId { get; set; }
        public bool? IsactiveBt { get; set; }

        public virtual WmaMRole Role { get; set; }
        public virtual WmaMTradegroup Tradegroup { get; set; }
    }
}
