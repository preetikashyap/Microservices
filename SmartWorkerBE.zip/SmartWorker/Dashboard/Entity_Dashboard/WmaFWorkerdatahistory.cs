﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkerdatahistory
    {
        public long WorkerhistoryId { get; set; }
        public long WorkerId { get; set; }
        public long? AadhaarnoNb { get; set; }
        public long? EipId { get; set; }
        public string WorkernameVc { get; set; }
        public string FatherSpouseVc { get; set; }
        public int? EmploymenttypeId { get; set; }
        public string SubcontractornameVc { get; set; }
        public string PresentAddrVc { get; set; }
        public string PermanentAddrVc { get; set; }
        public string BirthplaceVc { get; set; }
        public DateTime? DobDt { get; set; }
        public int? AgeNb { get; set; }
        public string GenderVc { get; set; }
        public long? MobilenoNb { get; set; }
        public long? TelephonenoNb { get; set; }
        public int? MaritalstatusId { get; set; }
        public int? ChildernNb { get; set; }
        public int? LanguageId { get; set; }
        public string LanguagesknownVc { get; set; }
        public string EmergencycontactnameVc { get; set; }
        public long? EmergencycontactnumberNb { get; set; }
        public string EmergencycontactaddressVc { get; set; }
        public string EmergencycontactrelationVc { get; set; }
        public string IdentificationmarkVc { get; set; }
        public bool? IsguiltyforcrimeBt { get; set; }
        public string GuiltyCrimeVc { get; set; }
        public int? NationalityId { get; set; }
        public bool? HastakencstiBt { get; set; }
        public string CstiidVc { get; set; }
        public string Ehsinductionid { get; set; }
        public string WorkerrecordstatusVc { get; set; }
        public int? ProjectId { get; set; }
        public string PhotourlVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? IsnapsBt { get; set; }
        public string IdprooftypeVc { get; set; }
        public string IdproofnumberVc { get; set; }
        public string Vendorcode { get; set; }
        public string QrcodeurlVc { get; set; }
        public DateTime? QrcodeissuedDt { get; set; }
        public string PresentAddr1Vc { get; set; }
        public string PresentAddr2Vc { get; set; }
        public string PresentCityVc { get; set; }
        public int? PresentStateNb { get; set; }
        public string PresentPincodeVc { get; set; }
        public int? PresentCountryNb { get; set; }
        public string PermanentAddr1Vc { get; set; }
        public string PermanentAddr2Vc { get; set; }
        public string PermanentCityVc { get; set; }
        public int? PermanentStateNb { get; set; }
        public string PermanentPincodeVc { get; set; }
        public int? PermanentCountryNb { get; set; }
        public bool? HitjoinapiBt { get; set; }
    }
}
