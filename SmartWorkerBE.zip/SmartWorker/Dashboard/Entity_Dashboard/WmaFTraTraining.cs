﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFTraTraining
    {
        public WmaFTraTraining()
        {
            WmaFTraProjecttrainingdetails = new HashSet<WmaFTraProjecttrainingdetail>();
            WmaLTraTrainingtrademaps = new HashSet<WmaLTraTrainingtrademap>();
        }

        public int TrainingId { get; set; }
        public string TrainingdescriptionVc { get; set; }
        public int TrainingtypeId { get; set; }
        public int TrainingcategoryId { get; set; }
        public int? IcId { get; set; }
        public int? ProjectId { get; set; }
        public decimal? Trainingdurationinhrs { get; set; }
        public string Trainingkeyobjective { get; set; }
        public string Trainingbroadcontent { get; set; }
        public int? Trainingvalidity { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public DateTime? Trainingperiodfrom { get; set; }
        public DateTime? Trainingperiodto { get; set; }
        public bool? Istrainingmandatory { get; set; }
        public int? TrainingmodeId { get; set; }
        public string OthertrainingmodeVc { get; set; }

        public virtual WmaMTraTrainingcategory Trainingcategory { get; set; }
        public virtual WmaMTraTrainingtype Trainingtype { get; set; }
        public virtual ICollection<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetails { get; set; }
        public virtual ICollection<WmaLTraTrainingtrademap> WmaLTraTrainingtrademaps { get; set; }
    }
}
