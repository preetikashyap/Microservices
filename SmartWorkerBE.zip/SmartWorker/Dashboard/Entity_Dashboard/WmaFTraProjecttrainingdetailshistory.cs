﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFTraProjecttrainingdetailshistory
    {
        public long ProjecttrainingdetailshistoryId { get; set; }
        public long? ProjecttrainingId { get; set; }
        public long TrainingId { get; set; }
        public int ProjectId { get; set; }
        public DateTime? Trainingscheduleddate { get; set; }
        public int? ParticipantsexpectedcountNb { get; set; }
        public string Venueormaterials { get; set; }
        public string Trainingoverallbenefits { get; set; }
        public string Trainingremarks { get; set; }
        public long? ProjecttrainingapproverId { get; set; }
        public string ProjecttrainingstatusVc { get; set; }
        public long? ApprovedbyId { get; set; }
        public DateTime? ApprovedonDt { get; set; }
        public string Projecttrainingfeedback { get; set; }
        public string Projecttrainingscopeforimprovement { get; set; }
        public long? ClosedbyId { get; set; }
        public DateTime? ClosedonDt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public DateTime? HistorycreatedonDt { get; set; }
        public string RemarksVc { get; set; }
    }
}
