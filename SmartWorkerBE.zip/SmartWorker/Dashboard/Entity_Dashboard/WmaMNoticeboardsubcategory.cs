﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMNoticeboardsubcategory
    {
        public WmaMNoticeboardsubcategory()
        {
            WmaFNoticeboarddetails = new HashSet<WmaFNoticeboarddetail>();
        }

        public short SubcategoryId { get; set; }
        public string SubcategoryName { get; set; }
        public string Imagename { get; set; }
        public short CategoryId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<WmaFNoticeboarddetail> WmaFNoticeboarddetails { get; set; }
    }
}
