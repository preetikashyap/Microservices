﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkerleavebalancehistory
    {
        public long Historyid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public int Leavetypeid { get; set; }
        public int Leavebalance { get; set; }
        public DateTime Dateofjoining { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }
        public int? Modifiedby { get; set; }
        public DateTime? Modifiedon { get; set; }
        public DateTime Releasedon { get; set; }

        public virtual WmaMLeavetype Leavetype { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
