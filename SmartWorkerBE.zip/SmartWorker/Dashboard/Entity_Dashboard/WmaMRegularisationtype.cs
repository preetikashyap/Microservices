﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMRegularisationtype
    {
        public WmaMRegularisationtype()
        {
            WmaFWageAttendanceregularisations = new HashSet<WmaFWageAttendanceregularisation>();
        }

        public int Regularisationtypeid { get; set; }
        public string Regularisationtypename { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisations { get; set; }
    }
}
