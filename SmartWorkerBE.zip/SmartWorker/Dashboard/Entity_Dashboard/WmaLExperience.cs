﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLExperience
    {
        public long ExperienceId { get; set; }
        public long WorkerId { get; set; }
        public string OrgnameVc { get; set; }
        public string ProjectsiteVc { get; set; }
        public string ProjectcodeVc { get; set; }
        public int? TradeId { get; set; }
        public DateTime? WorkperiodfromDt { get; set; }
        public DateTime? WorkperiodtoDt { get; set; }
        public int? TotalexperienceNb { get; set; }
        public string SalariedorwagedId { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string WorkeravailabilityVc { get; set; }
        public string OrgtypeVc { get; set; }
        public long? SerialnumberId { get; set; }
        public string Releaseremarks { get; set; }
        public string Joinremarks { get; set; }
        public string ExperiencetypeVc { get; set; }
        public string ReleasecommentsVc { get; set; }
        public string TradecapabilitiesVc { get; set; }
        public string GeneralbehaviourVc { get; set; }

        public virtual WmaMTrade Trade { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
