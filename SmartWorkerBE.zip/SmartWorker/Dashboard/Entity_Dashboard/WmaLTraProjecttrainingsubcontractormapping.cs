﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLTraProjecttrainingsubcontractormapping
    {
        public long ProjecttrainingsubcontractormapId { get; set; }
        public long ProjecttrainingId { get; set; }
        public string SubcontractornameVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaFTraProjecttrainingdetail Projecttraining { get; set; }
    }
}
