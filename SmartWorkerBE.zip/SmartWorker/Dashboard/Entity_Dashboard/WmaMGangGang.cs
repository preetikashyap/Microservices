﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMGangGang
    {
        public long GangId { get; set; }
        public string GangnameVc { get; set; }
        public string GangdescriptionVc { get; set; }
        public long? ProjectId { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
