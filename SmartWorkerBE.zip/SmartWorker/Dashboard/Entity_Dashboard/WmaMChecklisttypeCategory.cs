﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMChecklisttypeCategory
    {
        public long ChecklistCategoryid { get; set; }
        public string ChecklistCategorytype { get; set; }
        public bool Isactive { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public int? ModifiedonDt { get; set; }
        public string CategoryCodeVc { get; set; }
    }
}
