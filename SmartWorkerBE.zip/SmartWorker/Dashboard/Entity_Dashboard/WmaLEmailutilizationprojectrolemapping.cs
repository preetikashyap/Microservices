﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLEmailutilizationprojectrolemapping
    {
        public long EmailutilizationprojectrolemappingId { get; set; }
        public int? EmailutilizationId { get; set; }
        public int? ProjectId { get; set; }
        public string RoleId { get; set; }
        public string OtheremailidsVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? IcId { get; set; }

        public virtual WmaMEmailutilization Emailutilization { get; set; }
    }
}
