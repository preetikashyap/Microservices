﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkflow
    {
        public WmaFWorkflow()
        {
            WmaFWorkflowhistories = new HashSet<WmaFWorkflowhistory>();
        }

        public long WorkflowId { get; set; }
        public long WorkerId { get; set; }
        public string WorkflowstatusVc { get; set; }
        public long AssignedbyId { get; set; }
        public long AssignedbyroleId { get; set; }
        public long? AssignedtoId { get; set; }
        public long? AssignedtoroleId { get; set; }
        public DateTime AssignedondateDt { get; set; }
        public DateTime? ApprovedondateDt { get; set; }
        public int CurrentrecordlevelNb { get; set; }
        public int IscurrentlevelchecklistfilledNb { get; set; }
        public bool ArevitalsfilledBt { get; set; }
        public string RemarksVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? ProjectId { get; set; }

        public virtual WmaMUser Assignedby { get; set; }
        public virtual WmaMRole Assignedbyrole { get; set; }
        public virtual WmaMUser Assignedto { get; set; }
        public virtual WmaMRole Assignedtorole { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistories { get; set; }
    }
}
