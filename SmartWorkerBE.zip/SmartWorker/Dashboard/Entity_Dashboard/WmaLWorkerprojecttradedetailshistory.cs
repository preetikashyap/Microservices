﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWorkerprojecttradedetailshistory
    {
        public long TradedetailhistoryId { get; set; }
        public long TradedetailsId { get; set; }
        public long WorkerId { get; set; }
        public int ProjectId { get; set; }
        public int TradeId { get; set; }
        public int SkillcategoryId { get; set; }
        public int SkilllevelId { get; set; }
        public long? TradeapproverId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? TradegroupId { get; set; }
        public int? TradesubgroupId { get; set; }
        public long? FinalapproverId { get; set; }

        public virtual WmaMProject Project { get; set; }
        public virtual WmaMSkillcategory Skillcategory { get; set; }
        public virtual WmaMSkilllevel Skilllevel { get; set; }
        public virtual WmaMTrade Trade { get; set; }
        public virtual WmaLWorkerprojecttradedetail Tradedetails { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
