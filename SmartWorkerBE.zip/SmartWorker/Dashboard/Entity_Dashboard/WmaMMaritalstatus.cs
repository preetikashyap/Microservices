﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMMaritalstatus
    {
        public WmaMMaritalstatus()
        {
            WmaFWorkerdata = new HashSet<WmaFWorkerdatum>();
        }

        public int MaritalstatusId { get; set; }
        public string MaritalstatusVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaFWorkerdatum> WmaFWorkerdata { get; set; }
    }
}
