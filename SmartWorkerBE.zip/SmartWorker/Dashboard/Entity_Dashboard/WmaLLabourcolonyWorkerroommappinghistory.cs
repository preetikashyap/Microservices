﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLLabourcolonyWorkerroommappinghistory
    {
        public long WorkerroommappinghistoryId { get; set; }
        public long? WorkerroommappingId { get; set; }
        public long? WorkerId { get; set; }
        public long? RoomId { get; set; }
        public bool? IsactiveBt { get; set; }
        public bool? HasalertBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public DateTime? AllocatedonDt { get; set; }
        public DateTime? DeallocatedonDt { get; set; }
    }
}
