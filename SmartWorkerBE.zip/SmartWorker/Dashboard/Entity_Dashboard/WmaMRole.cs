﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMRole
    {
        public WmaMRole()
        {
            Testworkflows = new HashSet<Testworkflow>();
            WmaFNoticeboardrolecategorymaps = new HashSet<WmaFNoticeboardrolecategorymap>();
            WmaFWorkflowAssignedbyroles = new HashSet<WmaFWorkflow>();
            WmaFWorkflowAssignedtoroles = new HashSet<WmaFWorkflow>();
            WmaFWorkflowhistoryAssignedbyroles = new HashSet<WmaFWorkflowhistory>();
            WmaFWorkflowhistoryAssignedtoroles = new HashSet<WmaFWorkflowhistory>();
            WmaLAdminuserprojectlevelaccesses = new HashSet<WmaLAdminuserprojectlevelaccess>();
            WmaLAdminuserprojectlevelaccesshistories = new HashSet<WmaLAdminuserprojectlevelaccesshistory>();
            WmaLProjectrlsworkflowmaps = new HashSet<WmaLProjectrlsworkflowmap>();
            WmaLProjectrlsworkflowmaptest1s = new HashSet<WmaLProjectrlsworkflowmaptest1>();
            WmaLProjectworkflowmaps = new HashSet<WmaLProjectworkflowmap>();
            WmaLTraTrainingcategoyrolemappings = new HashSet<WmaLTraTrainingcategoyrolemapping>();
            WmaLUseradminrolemaps = new HashSet<WmaLUseradminrolemap>();
            WmaLUserprojectrolemaps = new HashSet<WmaLUserprojectrolemap>();
            WmaLUsertreemaps = new HashSet<WmaLUsertreemap>();
        }

        public long RoleId { get; set; }
        public string RolenameVc { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? HasmobileaccessBt { get; set; }
        public string RolecodeVc { get; set; }
        public bool? IstradegrplevelaccessBt { get; set; }
        public bool? IsadminroleBt { get; set; }

        public virtual ICollection<Testworkflow> Testworkflows { get; set; }
        public virtual ICollection<WmaFNoticeboardrolecategorymap> WmaFNoticeboardrolecategorymaps { get; set; }
        public virtual ICollection<WmaFWorkflow> WmaFWorkflowAssignedbyroles { get; set; }
        public virtual ICollection<WmaFWorkflow> WmaFWorkflowAssignedtoroles { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistoryAssignedbyroles { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistoryAssignedtoroles { get; set; }
        public virtual ICollection<WmaLAdminuserprojectlevelaccess> WmaLAdminuserprojectlevelaccesses { get; set; }
        public virtual ICollection<WmaLAdminuserprojectlevelaccesshistory> WmaLAdminuserprojectlevelaccesshistories { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmap> WmaLProjectrlsworkflowmaps { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmaptest1> WmaLProjectrlsworkflowmaptest1s { get; set; }
        public virtual ICollection<WmaLProjectworkflowmap> WmaLProjectworkflowmaps { get; set; }
        public virtual ICollection<WmaLTraTrainingcategoyrolemapping> WmaLTraTrainingcategoyrolemappings { get; set; }
        public virtual ICollection<WmaLUseradminrolemap> WmaLUseradminrolemaps { get; set; }
        public virtual ICollection<WmaLUserprojectrolemap> WmaLUserprojectrolemaps { get; set; }
        public virtual ICollection<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
    }
}
