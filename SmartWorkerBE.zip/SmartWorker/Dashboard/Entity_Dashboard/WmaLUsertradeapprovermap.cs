﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLUsertradeapprovermap
    {
        public long UsertradeapprovermapId { get; set; }
        public long UserprojectrolemapId { get; set; }
        public int TradeId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int TradegroupId { get; set; }

        public virtual WmaMTrade Trade { get; set; }
        public virtual WmaMTradegroup Tradegroup { get; set; }
        public virtual WmaLUserprojectrolemap Userprojectrolemap { get; set; }
    }
}
