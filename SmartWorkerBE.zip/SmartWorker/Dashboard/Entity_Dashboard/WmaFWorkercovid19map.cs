﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkercovid19map
    {
        public WmaFWorkercovid19map()
        {
            WmaFWorkercovid19maphistories = new HashSet<WmaFWorkercovid19maphistory>();
        }

        public long Workercovid19detailsid { get; set; }
        public long Workerid { get; set; }
        public int Risklevelid { get; set; }
        public string Risklevelremarks { get; set; }
        public int Covidstatusid { get; set; }
        public DateTime? Covidstatusupdatedon { get; set; }
        public string Covidstatusremarks { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? Isactive { get; set; }
        public bool? VaccinatedBt { get; set; }
        public DateTime? FirstdoseDt { get; set; }
        public DateTime? SeconddoseDt { get; set; }

        public virtual WmaMCovidstatus Covidstatus { get; set; }
        public virtual WmaMRisklevel Risklevel { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
        public virtual ICollection<WmaFWorkercovid19maphistory> WmaFWorkercovid19maphistories { get; set; }
    }
}
