﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMSubprojectjoineip
    {
        public long Subprojectjoineipid { get; set; }
        public int Subprojectid { get; set; }
        public int Workerid { get; set; }
        public bool? Isalreadyjoinedeip { get; set; }
    }
}
