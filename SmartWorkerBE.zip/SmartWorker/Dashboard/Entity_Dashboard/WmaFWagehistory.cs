﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWagehistory
    {
        public long Historyid { get; set; }
        public long? Wageid { get; set; }
        public decimal? Basicwage { get; set; }
        public decimal? Da { get; set; }
        public DateTime? Effectfrom { get; set; }
        public DateTime? Expireon { get; set; }
        public DateTime? Historycreatedon { get; set; }
        public long? Historycreatedby { get; set; }
        public string ActiontypeVc { get; set; }
    }
}
