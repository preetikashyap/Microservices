﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLGangWorkergangmapping
    {
        public long WorkergangmappingId { get; set; }
        public long? WorkerId { get; set; }
        public long? GangId { get; set; }
        public bool? IsleadBt { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
