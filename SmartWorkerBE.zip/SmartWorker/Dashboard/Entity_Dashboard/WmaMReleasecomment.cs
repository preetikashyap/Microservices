﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMReleasecomment
    {
        public long ReleasecommentsId { get; set; }
        public string ReleasenameVc { get; set; }
    }
}
