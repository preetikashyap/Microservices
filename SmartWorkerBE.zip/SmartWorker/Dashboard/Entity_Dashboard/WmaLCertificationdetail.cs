﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLCertificationdetail
    {
        public long CertificationdetailId { get; set; }
        public long WorkerId { get; set; }
        public int? CertificatetypeId { get; set; }
        public string CertificationnameVc { get; set; }
        public DateTime? CertificationdatetimeDt { get; set; }
        public int? CertificationvalidityDt { get; set; }
        public string AttachmentnameVc { get; set; }
        public string AttachmenttypeVc { get; set; }
        public string AttachmenturlVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public DateTime? DocumentvalidityDt { get; set; }

        public virtual WmaMCertificatetype Certificatetype { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
