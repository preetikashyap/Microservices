﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLGangGangdivisionmapping
    {
        public long GangdivisionId { get; set; }
        public long? GangId { get; set; }
        public long? DivisionId { get; set; }
        public long? SubdivisionId { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? YardId { get; set; }
    }
}
