﻿using System;
using Dashboard.Das_Model.Zone;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class SmartWorker_DbContext : DbContext
    {
        public SmartWorker_DbContext()
        {
        }

        public SmartWorker_DbContext(DbContextOptions<SmartWorker_DbContext> options)
            : base(options)
        {
        }

        //Manualy Added DBSet
        public virtual DbSet<ZonesWorker> ZonesWorkers { get; set; }

        public virtual DbSet<ZoneWorkerListDto> ZoneWorkerListDto { get; set; }

        //End

        public virtual DbSet<KycDummydoc> KycDummydocs { get; set; }
        public virtual DbSet<PgBuffercache> PgBuffercaches { get; set; }
        public virtual DbSet<PgStatStatement> PgStatStatements { get; set; }
        public virtual DbSet<SmFComservicelog> SmFComservicelogs { get; set; }
        public virtual DbSet<SmFFrservicelog> SmFFrservicelogs { get; set; }
        public virtual DbSet<SmFWeservicelog> SmFWeservicelogs { get; set; }
        public virtual DbSet<Tbltriggertest> Tbltriggertests { get; set; }
        public virtual DbSet<TempDistrict> TempDistricts { get; set; }
        public virtual DbSet<Testworkflow> Testworkflows { get; set; }
        public virtual DbSet<TmpSkill> TmpSkills { get; set; }
        public virtual DbSet<UsersDetail> UsersDetails { get; set; }
        public virtual DbSet<WisaFAiresult> WisaFAiresults { get; set; }
        public virtual DbSet<WisaFUploadedimagedetail> WisaFUploadedimagedetails { get; set; }
        public virtual DbSet<WisaLAwslog> WisaLAwslogs { get; set; }
        public virtual DbSet<WisaMWorker> WisaMWorkers { get; set; }
        public virtual DbSet<WmaFApirequestresponsedetail> WmaFApirequestresponsedetails { get; set; }
        public virtual DbSet<WmaFAppreciation> WmaFAppreciations { get; set; }
        public virtual DbSet<WmaFAwsfacerecognitiontransaction> WmaFAwsfacerecognitiontransactions { get; set; }
        public virtual DbSet<WmaFAwsrequestresponsedetail> WmaFAwsrequestresponsedetails { get; set; }
        public virtual DbSet<WmaFBiometricdataTemp> WmaFBiometricdataTemps { get; set; }
        public virtual DbSet<WmaFBiometricdatajunkdatum> WmaFBiometricdatajunkdata { get; set; }
        public virtual DbSet<WmaFBiometricdatum> WmaFBiometricdata { get; set; }
        public virtual DbSet<WmaFBiometricfilelog> WmaFBiometricfilelogs { get; set; }
        public virtual DbSet<WmaFBiometricscheduler> WmaFBiometricschedulers { get; set; }
        public virtual DbSet<WmaFBlacklist> WmaFBlacklists { get; set; }
        public virtual DbSet<WmaFChecklistquestionsresponse> WmaFChecklistquestionsresponses { get; set; }
        public virtual DbSet<WmaFChecklistquestionsresponsehistory> WmaFChecklistquestionsresponsehistories { get; set; }
        public virtual DbSet<WmaFCompliancedetail> WmaFCompliancedetails { get; set; }
        public virtual DbSet<WmaFCoviddocumentmap> WmaFCoviddocumentmaps { get; set; }
        public virtual DbSet<WmaFCovidvaccinationdetail> WmaFCovidvaccinationdetails { get; set; }
        public virtual DbSet<WmaFEipapirequestresponsedetail> WmaFEipapirequestresponsedetails { get; set; }
        public virtual DbSet<WmaFIdexpirycountbyproject> WmaFIdexpirycountbyprojects { get; set; }
        public virtual DbSet<WmaFLogtrace> WmaFLogtraces { get; set; }
        public virtual DbSet<WmaFLongabsenceworkerid> WmaFLongabsenceworkerids { get; set; }
        public virtual DbSet<WmaFMaillog> WmaFMaillogs { get; set; }
        public virtual DbSet<WmaFMedicalchecklistquestionsresponse> WmaFMedicalchecklistquestionsresponses { get; set; }
        public virtual DbSet<WmaFMedicalchecklistquestionsresponsehistory> WmaFMedicalchecklistquestionsresponsehistories { get; set; }
        public virtual DbSet<WmaFNoticeboarddetail> WmaFNoticeboarddetails { get; set; }
        public virtual DbSet<WmaFNoticeboarddetailhistory> WmaFNoticeboarddetailhistories { get; set; }
        public virtual DbSet<WmaFNoticeboarddocumentsmap> WmaFNoticeboarddocumentsmaps { get; set; }
        public virtual DbSet<WmaFNoticeboardrolecategorymap> WmaFNoticeboardrolecategorymaps { get; set; }
        public virtual DbSet<WmaFRankingchecklistquestionsresponse> WmaFRankingchecklistquestionsresponses { get; set; }
        public virtual DbSet<WmaFRankingchecklistquestionsresponsehistory> WmaFRankingchecklistquestionsresponsehistories { get; set; }
        public virtual DbSet<WmaFReleaserequest> WmaFReleaserequests { get; set; }
        public virtual DbSet<WmaFReleaserequesthistory> WmaFReleaserequesthistories { get; set; }
        public virtual DbSet<WmaFSubcontractorselfdeclaration> WmaFSubcontractorselfdeclarations { get; set; }
        public virtual DbSet<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetails { get; set; }
        public virtual DbSet<WmaFTraProjecttrainingdetailshistory> WmaFTraProjecttrainingdetailshistories { get; set; }
        public virtual DbSet<WmaFTraTraining> WmaFTraTrainings { get; set; }
        public virtual DbSet<WmaFWageArrear> WmaFWageArrears { get; set; }
        public virtual DbSet<WmaFWageArrearprocesslog> WmaFWageArrearprocesslogs { get; set; }
        public virtual DbSet<WmaFWageArrearworkersitelevelcompdetail> WmaFWageArrearworkersitelevelcompdetails { get; set; }
        public virtual DbSet<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisations { get; set; }
        public virtual DbSet<WmaFWageBonusdetail> WmaFWageBonusdetails { get; set; }
        public virtual DbSet<WmaFWageComponentsdeductiblefrommap> WmaFWageComponentsdeductiblefrommaps { get; set; }
        public virtual DbSet<WmaFWageFullandfinalsettlement> WmaFWageFullandfinalsettlements { get; set; }
        public virtual DbSet<WmaFWageHolidaycalendar> WmaFWageHolidaycalendars { get; set; }
        public virtual DbSet<WmaFWageOtregularisation> WmaFWageOtregularisations { get; set; }
        public virtual DbSet<WmaFWageProcessedbonusdetail> WmaFWageProcessedbonusdetails { get; set; }
        public virtual DbSet<WmaFWageSitelevelcomponent> WmaFWageSitelevelcomponents { get; set; }
        public virtual DbSet<WmaFWageWageprocesslog> WmaFWageWageprocesslogs { get; set; }
        public virtual DbSet<WmaFWageWorkersitelevelcompdetail> WmaFWageWorkersitelevelcompdetails { get; set; }
        public virtual DbSet<WmaFWageWorkerwageapproval> WmaFWageWorkerwageapprovals { get; set; }
        public virtual DbSet<WmaFWageWorkerwagemapping> WmaFWageWorkerwagemappings { get; set; }
        public virtual DbSet<WmaFWageWorkerwagemappinghistory> WmaFWageWorkerwagemappinghistories { get; set; }
        public virtual DbSet<WmaFWageWorkerwageprocess> WmaFWageWorkerwageprocesses { get; set; }
        public virtual DbSet<WmaFWagehistory> WmaFWagehistories { get; set; }
        public virtual DbSet<WmaFWorkerattachment> WmaFWorkerattachments { get; set; }
        public virtual DbSet<WmaFWorkerattendance> WmaFWorkerattendances { get; set; }
        public virtual DbSet<WmaFWorkercovid19map> WmaFWorkercovid19maps { get; set; }
        public virtual DbSet<WmaFWorkercovid19maphistory> WmaFWorkercovid19maphistories { get; set; }
        public virtual DbSet<WmaFWorkerdatahistory> WmaFWorkerdatahistories { get; set; }
        public virtual DbSet<WmaFWorkerdatum> WmaFWorkerdata { get; set; }
        public virtual DbSet<WmaFWorkerjunkattendance> WmaFWorkerjunkattendances { get; set; }
        public virtual DbSet<WmaFWorkerleaveattachment> WmaFWorkerleaveattachments { get; set; }
        public virtual DbSet<WmaFWorkerleavebalance> WmaFWorkerleavebalances { get; set; }
        public virtual DbSet<WmaFWorkerleavebalancehistory> WmaFWorkerleavebalancehistories { get; set; }
        public virtual DbSet<WmaFWorkerleavedetail> WmaFWorkerleavedetails { get; set; }
        public virtual DbSet<WmaFWorkerobservationdetail> WmaFWorkerobservationdetails { get; set; }
        public virtual DbSet<WmaFWorkerranking> WmaFWorkerrankings { get; set; }
        public virtual DbSet<WmaFWorkerrankinghistory> WmaFWorkerrankinghistories { get; set; }
        public virtual DbSet<WmaFWorkerselfdeclarationmap> WmaFWorkerselfdeclarationmaps { get; set; }
        public virtual DbSet<WmaFWorkerselfdeclarationmaphistory> WmaFWorkerselfdeclarationmaphistories { get; set; }
        public virtual DbSet<WmaFWorkertravellinghistory> WmaFWorkertravellinghistories { get; set; }
        public virtual DbSet<WmaFWorkervital> WmaFWorkervitals { get; set; }
        public virtual DbSet<WmaFWorkervitalshistroy> WmaFWorkervitalshistroys { get; set; }
        public virtual DbSet<WmaFWorkerzoneattendance> WmaFWorkerzoneattendances { get; set; }
        public virtual DbSet<WmaFWorkflow> WmaFWorkflows { get; set; }
        public virtual DbSet<WmaFWorkflowhistory> WmaFWorkflowhistories { get; set; }
        public virtual DbSet<WmaLActivityprojectrolemapping> WmaLActivityprojectrolemappings { get; set; }
        public virtual DbSet<WmaLAdminuserprojectlevelaccess> WmaLAdminuserprojectlevelaccesses { get; set; }
        public virtual DbSet<WmaLAdminuserprojectlevelaccesshistory> WmaLAdminuserprojectlevelaccesshistories { get; set; }
        public virtual DbSet<WmaLCertificationdetail> WmaLCertificationdetails { get; set; }
        public virtual DbSet<WmaLChecklistfortestvalidity> WmaLChecklistfortestvalidities { get; set; }
        public virtual DbSet<WmaLChecklistfortestvalidityhistory> WmaLChecklistfortestvalidityhistories { get; set; }
        public virtual DbSet<WmaLChecklistquesresponsetypemap> WmaLChecklistquesresponsetypemaps { get; set; }
        public virtual DbSet<WmaLChecklistquestiongroupmap> WmaLChecklistquestiongroupmaps { get; set; }
        public virtual DbSet<WmaLChecklistquestionsmap> WmaLChecklistquestionsmaps { get; set; }
        public virtual DbSet<WmaLChecklisttraderoleapprovalmap> WmaLChecklisttraderoleapprovalmaps { get; set; }
        public virtual DbSet<WmaLEducationdetail> WmaLEducationdetails { get; set; }
        public virtual DbSet<WmaLEmailutilizationprojectrolemapping> WmaLEmailutilizationprojectrolemappings { get; set; }
        public virtual DbSet<WmaLExperience> WmaLExperiences { get; set; }
        public virtual DbSet<WmaLGangGangdivisionmapping> WmaLGangGangdivisionmappings { get; set; }
        public virtual DbSet<WmaLGangWorkergangmapping> WmaLGangWorkergangmappings { get; set; }
        public virtual DbSet<WmaLGenericmessage> WmaLGenericmessages { get; set; }
        public virtual DbSet<WmaLLabourcolonyWorkerroommapping> WmaLLabourcolonyWorkerroommappings { get; set; }
        public virtual DbSet<WmaLLabourcolonyWorkerroommappinghistory> WmaLLabourcolonyWorkerroommappinghistories { get; set; }
        public virtual DbSet<WmaLMenumapping> WmaLMenumappings { get; set; }
        public virtual DbSet<WmaLMobileloginOtp> WmaLMobileloginOtps { get; set; }
        public virtual DbSet<WmaLObservationmapping> WmaLObservationmappings { get; set; }
        public virtual DbSet<WmaLProjectMedicalperiodicchecklistmapping> WmaLProjectMedicalperiodicchecklistmappings { get; set; }
        public virtual DbSet<WmaLProjectattachment> WmaLProjectattachments { get; set; }
        public virtual DbSet<WmaLProjectchecklistmap> WmaLProjectchecklistmaps { get; set; }
        public virtual DbSet<WmaLProjectfeaturemapping> WmaLProjectfeaturemappings { get; set; }
        public virtual DbSet<WmaLProjectrlsworkflowmap> WmaLProjectrlsworkflowmaps { get; set; }
        public virtual DbSet<WmaLProjectrlsworkflowmaptest1> WmaLProjectrlsworkflowmaptest1s { get; set; }
        public virtual DbSet<WmaLProjectscompoundgroupmapping> WmaLProjectscompoundgroupmappings { get; set; }
        public virtual DbSet<WmaLProjectvincensemapping> WmaLProjectvincensemappings { get; set; }
        public virtual DbSet<WmaLProjectworkerevaluationchecklistmapping> WmaLProjectworkerevaluationchecklistmappings { get; set; }
        public virtual DbSet<WmaLProjectworkflowmap> WmaLProjectworkflowmaps { get; set; }
        public virtual DbSet<WmaLQuestiongrouptrademap> WmaLQuestiongrouptrademaps { get; set; }
        public virtual DbSet<WmaLRoletradegroupmapping> WmaLRoletradegroupmappings { get; set; }
        public virtual DbSet<WmaLTraProjecttrainingattachment> WmaLTraProjecttrainingattachments { get; set; }
        public virtual DbSet<WmaLTraProjecttrainingattendance> WmaLTraProjecttrainingattendances { get; set; }
        public virtual DbSet<WmaLTraProjecttrainingconcernedusersmapping> WmaLTraProjecttrainingconcernedusersmappings { get; set; }
        public virtual DbSet<WmaLTraProjecttrainingfacultymapping> WmaLTraProjecttrainingfacultymappings { get; set; }
        public virtual DbSet<WmaLTraProjecttrainingsubcontractormapping> WmaLTraProjecttrainingsubcontractormappings { get; set; }
        public virtual DbSet<WmaLTraTrainingcategoyrolemapping> WmaLTraTrainingcategoyrolemappings { get; set; }
        public virtual DbSet<WmaLTraTrainingtrademap> WmaLTraTrainingtrademaps { get; set; }
        public virtual DbSet<WmaLUseradminrolemap> WmaLUseradminrolemaps { get; set; }
        public virtual DbSet<WmaLUserprojectrolemap> WmaLUserprojectrolemaps { get; set; }
        public virtual DbSet<WmaLUsertradeapprovermap> WmaLUsertradeapprovermaps { get; set; }
        public virtual DbSet<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
        public virtual DbSet<WmaLWageWorkerwageprocessarrearmapping> WmaLWageWorkerwageprocessarrearmappings { get; set; }
        public virtual DbSet<WmaLWageWorkerwageprocessed> WmaLWageWorkerwageprocesseds { get; set; }
        public virtual DbSet<WmaLWageZonemapping> WmaLWageZonemappings { get; set; }
        public virtual DbSet<WmaLWorkerbankdetail> WmaLWorkerbankdetails { get; set; }
        public virtual DbSet<WmaLWorkerkyc> WmaLWorkerkycs { get; set; }
        public virtual DbSet<WmaLWorkerkycdocument> WmaLWorkerkycdocuments { get; set; }
        public virtual DbSet<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
        public virtual DbSet<WmaLWorkerprojecttradedetailshistory> WmaLWorkerprojecttradedetailshistories { get; set; }
        public virtual DbSet<WmaLWorkerzonemapping> WmaLWorkerzonemappings { get; set; }
        public virtual DbSet<WmaMActivity> WmaMActivities { get; set; }
        public virtual DbSet<WmaMApiconfigdetail> WmaMApiconfigdetails { get; set; }
        public virtual DbSet<WmaMApkversionlog> WmaMApkversionlogs { get; set; }
        public virtual DbSet<WmaMAwscompanymap> WmaMAwscompanymaps { get; set; }
        public virtual DbSet<WmaMBonustype> WmaMBonustypes { get; set; }
        public virtual DbSet<WmaMBu> WmaMBus { get; set; }
        public virtual DbSet<WmaMCertificatetype> WmaMCertificatetypes { get; set; }
        public virtual DbSet<WmaMChecklist> WmaMChecklists { get; set; }
        public virtual DbSet<WmaMChecklisttypeCategory> WmaMChecklisttypeCategories { get; set; }
        public virtual DbSet<WmaMCity> WmaMCities { get; set; }
        public virtual DbSet<WmaMCluster> WmaMClusters { get; set; }
        public virtual DbSet<WmaMCompoundgroup> WmaMCompoundgroups { get; set; }
        public virtual DbSet<WmaMCountry> WmaMCountries { get; set; }
        public virtual DbSet<WmaMCoviddose> WmaMCoviddoses { get; set; }
        public virtual DbSet<WmaMCovidstatus> WmaMCovidstatuses { get; set; }
        public virtual DbSet<WmaMDay> WmaMDays { get; set; }
        public virtual DbSet<WmaMDistrict> WmaMDistricts { get; set; }
        public virtual DbSet<WmaMEmailutilization> WmaMEmailutilizations { get; set; }
        public virtual DbSet<WmaMEmploymenttype> WmaMEmploymenttypes { get; set; }
        public virtual DbSet<WmaMExam> WmaMExams { get; set; }
        public virtual DbSet<WmaMFamilydetail> WmaMFamilydetails { get; set; }
        public virtual DbSet<WmaMFeature> WmaMFeatures { get; set; }
        public virtual DbSet<WmaMGangGang> WmaMGangGangs { get; set; }
        public virtual DbSet<WmaMGangProjectdivision> WmaMGangProjectdivisions { get; set; }
        public virtual DbSet<WmaMGangSubdivision> WmaMGangSubdivisions { get; set; }
        public virtual DbSet<WmaMGeospatialstatus> WmaMGeospatialstatuses { get; set; }
        public virtual DbSet<WmaMGovermenttype> WmaMGovermenttypes { get; set; }
        public virtual DbSet<WmaMIc> WmaMIcs { get; set; }
        public virtual DbSet<WmaMIdproof> WmaMIdproofs { get; set; }
        public virtual DbSet<WmaMLabourcolonyBuilding> WmaMLabourcolonyBuildings { get; set; }
        public virtual DbSet<WmaMLabourcolonyFloor> WmaMLabourcolonyFloors { get; set; }
        public virtual DbSet<WmaMLabourcolonyRoom> WmaMLabourcolonyRooms { get; set; }
        public virtual DbSet<WmaMLanguage> WmaMLanguages { get; set; }
        public virtual DbSet<WmaMLeavetype> WmaMLeavetypes { get; set; }
        public virtual DbSet<WmaMLicensetype> WmaMLicensetypes { get; set; }
        public virtual DbSet<WmaMMainmenu> WmaMMainmenus { get; set; }
        public virtual DbSet<WmaMMaritalstatus> WmaMMaritalstatuses { get; set; }
        public virtual DbSet<WmaMNoticeboardcategory> WmaMNoticeboardcategories { get; set; }
        public virtual DbSet<WmaMNoticeboardsubcategory> WmaMNoticeboardsubcategories { get; set; }
        public virtual DbSet<WmaMObservationcategory> WmaMObservationcategories { get; set; }
        public virtual DbSet<WmaMObservationsubcategory> WmaMObservationsubcategories { get; set; }
        public virtual DbSet<WmaMProject> WmaMProjects { get; set; }
        public virtual DbSet<WmaMRanking> WmaMRankings { get; set; }
        public virtual DbSet<WmaMReferredbydetail> WmaMReferredbydetails { get; set; }
        public virtual DbSet<WmaMRegularisationtype> WmaMRegularisationtypes { get; set; }
        public virtual DbSet<WmaMRelationtype> WmaMRelationtypes { get; set; }
        public virtual DbSet<WmaMReleasecomment> WmaMReleasecomments { get; set; }
        public virtual DbSet<WmaMResponsetype> WmaMResponsetypes { get; set; }
        public virtual DbSet<WmaMRisklevel> WmaMRisklevels { get; set; }
        public virtual DbSet<WmaMRole> WmaMRoles { get; set; }
        public virtual DbSet<WmaMSbg> WmaMSbgs { get; set; }
        public virtual DbSet<WmaMSection> WmaMSections { get; set; }
        public virtual DbSet<WmaMSectionsubproject> WmaMSectionsubprojects { get; set; }
        public virtual DbSet<WmaMSegment> WmaMSegments { get; set; }
        public virtual DbSet<WmaMSelfdeclarationquestion> WmaMSelfdeclarationquestions { get; set; }
        public virtual DbSet<WmaMSkill> WmaMSkills { get; set; }
        public virtual DbSet<WmaMSkillcategory> WmaMSkillcategories { get; set; }
        public virtual DbSet<WmaMSkilllevel> WmaMSkilllevels { get; set; }
        public virtual DbSet<WmaMState> WmaMStates { get; set; }
        public virtual DbSet<WmaMStatus> WmaMStatuses { get; set; }
        public virtual DbSet<WmaMSubcontractortype> WmaMSubcontractortypes { get; set; }
        public virtual DbSet<WmaMSubmenu> WmaMSubmenus { get; set; }
        public virtual DbSet<WmaMSubprojectjoineip> WmaMSubprojectjoineips { get; set; }
        public virtual DbSet<WmaMThirdpartyuser> WmaMThirdpartyusers { get; set; }
        public virtual DbSet<WmaMTokenmanager> WmaMTokenmanagers { get; set; }
        public virtual DbSet<WmaMTraTrainingcategory> WmaMTraTrainingcategories { get; set; }
        public virtual DbSet<WmaMTraTrainingmode> WmaMTraTrainingmodes { get; set; }
        public virtual DbSet<WmaMTraTrainingtype> WmaMTraTrainingtypes { get; set; }
        public virtual DbSet<WmaMTrade> WmaMTrades { get; set; }
        public virtual DbSet<WmaMTradegroup> WmaMTradegroups { get; set; }
        public virtual DbSet<WmaMTradesubgroup> WmaMTradesubgroups { get; set; }
        public virtual DbSet<WmaMTraining> WmaMTrainings { get; set; }
        public virtual DbSet<WmaMUanmaster> WmaMUanmasters { get; set; }
        public virtual DbSet<WmaMUser> WmaMUsers { get; set; }
        public virtual DbSet<WmaMUserhistory> WmaMUserhistories { get; set; }
        public virtual DbSet<WmaMWageArreartype> WmaMWageArreartypes { get; set; }
        public virtual DbSet<WmaMWageDeduction> WmaMWageDeductions { get; set; }
        public virtual DbSet<WmaMWageDeductionhistory> WmaMWageDeductionhistories { get; set; }
        public virtual DbSet<WmaMWageGovernmenttype> WmaMWageGovernmenttypes { get; set; }
        public virtual DbSet<WmaMWageHolidaytypemst> WmaMWageHolidaytypemsts { get; set; }
        public virtual DbSet<WmaMWageMinwage> WmaMWageMinwages { get; set; }
        public virtual DbSet<WmaMWageMinwagehistory> WmaMWageMinwagehistories { get; set; }
        public virtual DbSet<WmaMWageNatureofwork> WmaMWageNatureofworks { get; set; }
        public virtual DbSet<WmaMWageSitecomponentMst> WmaMWageSitecomponentMsts { get; set; }
        public virtual DbSet<WmaMWageSundayworkingtrademst> WmaMWageSundayworkingtrademsts { get; set; }
        public virtual DbSet<WmaMWageTempminwagehistory> WmaMWageTempminwagehistories { get; set; }
        public virtual DbSet<WmaMWageZone> WmaMWageZones { get; set; }
        public virtual DbSet<WmaMWorkerdetailsection> WmaMWorkerdetailsections { get; set; }
        public virtual DbSet<WmaMWorkershift> WmaMWorkershifts { get; set; }
        public virtual DbSet<WmaMZone> WmaMZones { get; set; }
        public virtual DbSet<Wrongempdatum> Wrongempdata { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseNpgsql("Host=wnsdevsmartworker.postgres.database.azure.com;Database=SmartWorker_Db;Username=smartworkeradm@wnsdevsmartworker.postgres.database.azure.com;Password=mN$73vSw@4#W0rKE4;Ssl Mode=Require");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasPostgresExtension("pg_buffercache")
                .HasPostgresExtension("pg_stat_statements")
                .HasAnnotation("Relational:Collation", "English_United States.1252");

            //Added Manually for function
            modelBuilder.Entity<ZoneWorkerListDto>().HasNoKey();

            modelBuilder.Entity<ZonesWorker>().HasNoKey();
            //ENd


            modelBuilder.Entity<KycDummydoc>(entity =>
            {
                entity.HasKey(e => e.KycId)
                    .HasName("pk_kyc_dummydoc");

                entity.ToTable("kyc_dummydoc");

                entity.Property(e => e.KycId)
                    .HasColumnName("kyc_id")
                    .HasDefaultValueSql("nextval('kyc_dummydoc_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ExpiryonDt)
                    .HasPrecision(3)
                    .HasColumnName("expiryon_dt");

                entity.Property(e => e.IdproofId).HasColumnName("idproof_id");

                entity.Property(e => e.IdproofvalueVc)
                    .HasMaxLength(100)
                    .HasColumnName("idproofvalue_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IssuedonDt)
                    .HasPrecision(3)
                    .HasColumnName("issuedon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<PgBuffercache>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("pg_buffercache");

                entity.Property(e => e.Bufferid).HasColumnName("bufferid");

                entity.Property(e => e.Isdirty).HasColumnName("isdirty");

                entity.Property(e => e.PinningBackends).HasColumnName("pinning_backends");

                entity.Property(e => e.Relblocknumber).HasColumnName("relblocknumber");

                entity.Property(e => e.Reldatabase)
                    .HasColumnType("oid")
                    .HasColumnName("reldatabase");

                entity.Property(e => e.Relfilenode)
                    .HasColumnType("oid")
                    .HasColumnName("relfilenode");

                entity.Property(e => e.Relforknumber).HasColumnName("relforknumber");

                entity.Property(e => e.Reltablespace)
                    .HasColumnType("oid")
                    .HasColumnName("reltablespace");

                entity.Property(e => e.Usagecount).HasColumnName("usagecount");
            });

            modelBuilder.Entity<PgStatStatement>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("pg_stat_statements");

                entity.Property(e => e.BlkReadTime).HasColumnName("blk_read_time");

                entity.Property(e => e.BlkWriteTime).HasColumnName("blk_write_time");

                entity.Property(e => e.Calls).HasColumnName("calls");

                entity.Property(e => e.Dbid)
                    .HasColumnType("oid")
                    .HasColumnName("dbid");

                entity.Property(e => e.LocalBlksDirtied).HasColumnName("local_blks_dirtied");

                entity.Property(e => e.LocalBlksHit).HasColumnName("local_blks_hit");

                entity.Property(e => e.LocalBlksRead).HasColumnName("local_blks_read");

                entity.Property(e => e.LocalBlksWritten).HasColumnName("local_blks_written");

                entity.Property(e => e.MaxTime).HasColumnName("max_time");

                entity.Property(e => e.MeanTime).HasColumnName("mean_time");

                entity.Property(e => e.MinTime).HasColumnName("min_time");

                entity.Property(e => e.Query).HasColumnName("query");

                entity.Property(e => e.Queryid).HasColumnName("queryid");

                entity.Property(e => e.Rows).HasColumnName("rows");

                entity.Property(e => e.SharedBlksDirtied).HasColumnName("shared_blks_dirtied");

                entity.Property(e => e.SharedBlksHit).HasColumnName("shared_blks_hit");

                entity.Property(e => e.SharedBlksRead).HasColumnName("shared_blks_read");

                entity.Property(e => e.SharedBlksWritten).HasColumnName("shared_blks_written");

                entity.Property(e => e.StddevTime).HasColumnName("stddev_time");

                entity.Property(e => e.TempBlksRead).HasColumnName("temp_blks_read");

                entity.Property(e => e.TempBlksWritten).HasColumnName("temp_blks_written");

                entity.Property(e => e.TotalTime).HasColumnName("total_time");

                entity.Property(e => e.Userid)
                    .HasColumnType("oid")
                    .HasColumnName("userid");
            });

            modelBuilder.Entity<SmFComservicelog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("sm_f_comservicelog");

                entity.Property(e => e.Classname)
                    .HasMaxLength(50)
                    .HasColumnName("classname");

                entity.Property(e => e.ComtransId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("comtrans_id")
                    .UseIdentityAlwaysColumn();

                entity.Property(e => e.ErrcreatedbyId).HasColumnName("errcreatedby_id");

                entity.Property(e => e.ErrorcreatedDt).HasColumnName("errorcreated_dt");

                entity.Property(e => e.Errormsg)
                    .HasMaxLength(4000)
                    .HasColumnName("errormsg");

                entity.Property(e => e.Linenumber).HasColumnName("linenumber");

                entity.Property(e => e.Methodname)
                    .HasMaxLength(50)
                    .HasColumnName("methodname");

                entity.Property(e => e.Servicename)
                    .HasMaxLength(20)
                    .HasColumnName("servicename");
            });

            modelBuilder.Entity<SmFFrservicelog>(entity =>
            {
                entity.HasKey(e => e.FrtransId)
                    .HasName("sm_f_frservicelog_pkey");

                entity.ToTable("sm_f_frservicelog");

                entity.Property(e => e.FrtransId)
                    .HasColumnName("frtrans_id")
                    .UseIdentityAlwaysColumn();

                entity.Property(e => e.Classname)
                    .HasMaxLength(50)
                    .HasColumnName("classname");

                entity.Property(e => e.ErrcreatedbyId).HasColumnName("errcreatedby_id");

                entity.Property(e => e.ErrorcreatedDt).HasColumnName("errorcreated_dt");

                entity.Property(e => e.Errormsg)
                    .HasMaxLength(4000)
                    .HasColumnName("errormsg");

                entity.Property(e => e.Linenumber).HasColumnName("linenumber");

                entity.Property(e => e.Methodname)
                    .HasMaxLength(50)
                    .HasColumnName("methodname");

                entity.Property(e => e.Servicename)
                    .HasMaxLength(20)
                    .HasColumnName("servicename");
            });

            modelBuilder.Entity<SmFWeservicelog>(entity =>
            {
                entity.HasKey(e => e.WetransId)
                    .HasName("sm_f_weservicelog_pkey");

                entity.ToTable("sm_f_weservicelog");

                entity.Property(e => e.WetransId)
                    .HasColumnName("wetrans_id")
                    .UseIdentityAlwaysColumn();

                entity.Property(e => e.Classname)
                    .HasMaxLength(50)
                    .HasColumnName("classname");

                entity.Property(e => e.ErrcreatedbyId).HasColumnName("errcreatedby_id");

                entity.Property(e => e.ErrorcreatedDt).HasColumnName("errorcreated_dt");

                entity.Property(e => e.Errormsg)
                    .HasMaxLength(4000)
                    .HasColumnName("errormsg");

                entity.Property(e => e.Linenumber).HasColumnName("linenumber");

                entity.Property(e => e.Methodname)
                    .HasMaxLength(50)
                    .HasColumnName("methodname");

                entity.Property(e => e.Servicename)
                    .HasMaxLength(20)
                    .HasColumnName("servicename");
            });

            modelBuilder.Entity<Tbltriggertest>(entity =>
            {
                entity.HasKey(e => e.Pkid)
                    .HasName("tbltriggertest_pkey");

                entity.ToTable("tbltriggertest");

                entity.Property(e => e.Pkid)
                    .HasColumnName("pkid")
                    .HasDefaultValueSql("nextval('tbltriggertest_seq'::regclass)");

                entity.Property(e => e.Orderapprovaldatetime)
                    .HasPrecision(3)
                    .HasColumnName("orderapprovaldatetime");

                entity.Property(e => e.Orderstatus)
                    .HasMaxLength(20)
                    .HasColumnName("orderstatus");
            });

            modelBuilder.Entity<TempDistrict>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("temp_districts");

                entity.Property(e => e.District)
                    .HasMaxLength(100)
                    .HasColumnName("district");

                entity.Property(e => e.Districtcode)
                    .HasMaxLength(50)
                    .HasColumnName("districtcode");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Statecode)
                    .HasMaxLength(10)
                    .HasColumnName("statecode");

                entity.Property(e => e.Statename)
                    .HasMaxLength(100)
                    .HasColumnName("statename");

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .HasColumnName("title");

                entity.Property(e => e.Xdistrictcode)
                    .HasMaxLength(50)
                    .HasColumnName("xdistrictcode");
            });

            modelBuilder.Entity<Testworkflow>(entity =>
            {
                entity.HasKey(e => e.ProjectworkflowmapId)
                    .HasName("pk_testworkflow_1");

                entity.ToTable("testworkflow");

                entity.Property(e => e.ProjectworkflowmapId)
                    .HasColumnName("projectworkflowmap_id")
                    .HasDefaultValueSql("nextval('testworkflow_seq'::regclass)");

                entity.Property(e => e.ApprovalroleId).HasColumnName("approvalrole_id");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SortorderNb).HasColumnName("sortorder_nb");

                entity.Property(e => e.WorkflowstageVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("workflowstage_vc");

                entity.HasOne(d => d.Approvalrole)
                    .WithMany(p => p.Testworkflows)
                    .HasForeignKey(d => d.ApprovalroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_testworkflow_wma_m_roles");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.Testworkflows)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("fk_testworkflow_wma_m_checklist");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.Testworkflows)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_testworkflow_wma_m_projects");
            });

            modelBuilder.Entity<TmpSkill>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tmp_skill");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Skillcategory)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("skillcategory");

                entity.Property(e => e.Skillcode).HasColumnName("skillcode");

                entity.Property(e => e.Skilldescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("skilldescription");

                entity.Property(e => e.Skillgroup)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("skillgroup");

                entity.Property(e => e.Skillgroupdesc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("skillgroupdesc");

                entity.Property(e => e.Skillsubgroupdesc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("skillsubgroupdesc");
            });

            modelBuilder.Entity<UsersDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("users_detail");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("name");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password");
            });

            modelBuilder.Entity<WisaFAiresult>(entity =>
            {
                entity.ToTable("wisa_f_airesult");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wisa_f_airesult_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.MatchpercentNb)
                    .HasPrecision(18, 2)
                    .HasColumnName("matchpercent_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ReferenceimageVc).HasColumnName("referenceimage_vc");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.StatusBt).HasColumnName("status_bt");

                entity.Property(e => e.TransactionId).HasColumnName("transaction_id");

                entity.Property(e => e.UploadedimageVc).HasColumnName("uploadedimage_vc");

                entity.Property(e => e.WorkerrunningId).HasColumnName("workerrunning_id");
            });

            modelBuilder.Entity<WisaFUploadedimagedetail>(entity =>
            {
                entity.HasKey(e => e.TransactionId)
                    .HasName("pk_wisa_f_uploadedimagedetails");

                entity.ToTable("wisa_f_uploadedimagedetails");

                entity.Property(e => e.TransactionId)
                    .HasColumnName("transaction_id")
                    .HasDefaultValueSql("nextval('wisa_f_uploadedimagedetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.StatusBt).HasColumnName("status_bt");

                entity.Property(e => e.Uid)
                    .HasMaxLength(40)
                    .HasColumnName("uid");

                entity.Property(e => e.UploaddatetimeDt)
                    .HasPrecision(3)
                    .HasColumnName("uploaddatetime_dt");

                entity.Property(e => e.UploadedimageVc).HasColumnName("uploadedimage_vc");
            });

            modelBuilder.Entity<WisaLAwslog>(entity =>
            {
                entity.HasKey(e => e.AwslogId)
                    .HasName("pk_wisa_l_awslog_id");

                entity.ToTable("wisa_l_awslog");

                entity.Property(e => e.AwslogId)
                    .HasColumnName("awslog_id")
                    .HasDefaultValueSql("nextval('wisa_l_awslog_seq'::regclass)");

                entity.Property(e => e.Companycode)
                    .HasMaxLength(100)
                    .HasColumnName("companycode");

                entity.Property(e => e.Iccode)
                    .HasMaxLength(100)
                    .HasColumnName("iccode");

                entity.Property(e => e.ImageVc)
                    .HasMaxLength(500)
                    .HasColumnName("image_vc");

                entity.Property(e => e.InitiatedbyId).HasColumnName("initiatedby_id");

                entity.Property(e => e.InitiatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("initiatedon_dt");

                entity.Property(e => e.NooftimesId).HasColumnName("nooftimes_id");

                entity.Property(e => e.OperationVc)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("operation_vc");

                entity.Property(e => e.TransactionVc)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("transaction_vc");
            });

            modelBuilder.Entity<WisaMWorker>(entity =>
            {
                entity.HasKey(e => e.WorkerrunningId)
                    .HasName("wisa_m_worker_pkey");

                entity.ToTable("wisa_m_worker");

                entity.Property(e => e.WorkerrunningId)
                    .HasColumnName("workerrunning_id")
                    .HasDefaultValueSql("nextval('wisa_m_worker_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FaceidVc).HasColumnName("faceid_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.WisaId).HasColumnName("wisa_id");

                entity.Property(e => e.WorkerimageVc).HasColumnName("workerimage_vc");

                entity.Property(e => e.WorkernameVc)
                    .HasMaxLength(255)
                    .HasColumnName("workername_vc");
            });

            modelBuilder.Entity<WmaFApirequestresponsedetail>(entity =>
            {
                entity.HasKey(e => e.ReqresId)
                    .HasName("wma_f_apirequestresponsedetails_pkey");

                entity.ToTable("wma_f_apirequestresponsedetails");

                entity.Property(e => e.ReqresId)
                    .HasColumnName("reqres_id")
                    .HasDefaultValueSql("nextval('wma_f_apirequestresponsedetails_seq'::regclass)");

                entity.Property(e => e.ActionnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("actionname_vc");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FullurlVc)
                    .HasMaxLength(1000)
                    .HasColumnName("fullurl_vc");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.RequestVc).HasColumnName("request_vc");

                entity.Property(e => e.ResponseVc).HasColumnName("response_vc");
            });

            modelBuilder.Entity<WmaFAppreciation>(entity =>
            {
                entity.HasKey(e => e.WorkerappreciationId)
                    .HasName("wma_f_appreciation_pkey");

                entity.ToTable("wma_f_appreciation");

                entity.Property(e => e.WorkerappreciationId)
                    .HasColumnName("workerappreciation_id")
                    .HasDefaultValueSql("nextval('wma_f_appreciation_seq'::regclass)");

                entity.Property(e => e.AppreciatedbyId).HasColumnName("appreciatedby_id");

                entity.Property(e => e.AppreciatingonDt)
                    .HasPrecision(3)
                    .HasColumnName("appreciatingon_dt");

                entity.Property(e => e.AppreciationcategoryId).HasColumnName("appreciationcategory_id");

                entity.Property(e => e.AppreciationdescriptionVc).HasColumnName("appreciationdescription_vc");

                entity.Property(e => e.AppreciationsubcategoryId).HasColumnName("appreciationsubcategory_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactieBt).HasColumnName("isactie_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Appreciationcategory)
                    .WithMany(p => p.WmaFAppreciations)
                    .HasForeignKey(d => d.AppreciationcategoryId)
                    .HasConstraintName("wma_f_appreciation_appreciationcategory_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFAppreciations)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("fk_wma_f_appreciation_wma_m_projects");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFAppreciations)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("wma_f_appreciation_worker_id_fkey");
            });

            modelBuilder.Entity<WmaFAwsfacerecognitiontransaction>(entity =>
            {
                entity.HasKey(e => e.AwsfacerecognitiontransactionId)
                    .HasName("pk_wma_f_awsfacerecognitiontransaction");

                entity.ToTable("wma_f_awsfacerecognitiontransaction");

                entity.Property(e => e.AwsfacerecognitiontransactionId)
                    .HasColumnName("awsfacerecognitiontransaction_id")
                    .HasDefaultValueSql("nextval('wma_f_awsfacerecognitiontransaction_seq'::regclass)");

                entity.Property(e => e.AttendancebaseimageurlVc).HasColumnName("attendancebaseimageurl_vc");

                entity.Property(e => e.AttendancedateDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancedate_dt");

                entity.Property(e => e.Attendancemarked).HasColumnName("attendancemarked");

                entity.Property(e => e.AttendancemarkedbyId).HasColumnName("attendancemarkedby_id");

                entity.Property(e => e.AwsrunningId).HasColumnName("awsrunning_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Errormessage).HasColumnName("errormessage");

                entity.Property(e => e.ImageuploadedurlVc).HasColumnName("imageuploadedurl_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MatchingpercentageVc)
                    .HasMaxLength(50)
                    .HasColumnName("matchingpercentage_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ReferenceimageurlVc).HasColumnName("referenceimageurl_vc");

                entity.Property(e => e.WisaId).HasColumnName("wisa_id");
            });

            modelBuilder.Entity<WmaFAwsrequestresponsedetail>(entity =>
            {
                entity.HasKey(e => e.AwsrequestresponsedetailId)
                    .HasName("pk_wma_f_awsrequestresponsedetail");

                entity.ToTable("wma_f_awsrequestresponsedetail");

                entity.Property(e => e.AwsrequestresponsedetailId)
                    .HasColumnName("awsrequestresponsedetail_id")
                    .HasDefaultValueSql("nextval('wma_f_awsrequestresponsedetail_seq'::regclass)");

                entity.Property(e => e.ApinameVc)
                    .HasMaxLength(500)
                    .HasColumnName("apiname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RequestcontentVc).HasColumnName("requestcontent_vc");

                entity.Property(e => e.RequesttypeVc)
                    .HasMaxLength(500)
                    .HasColumnName("requesttype_vc");

                entity.Property(e => e.ResponsecontentVc).HasColumnName("responsecontent_vc");

                entity.Property(e => e.ResponsestauscodeVc).HasColumnName("responsestauscode_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFAwsrequestresponsedetails)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("fk_wma_f_awsrequestresponsedetail");
            });

            modelBuilder.Entity<WmaFBiometricdataTemp>(entity =>
            {
                entity.HasKey(e => e.BiometricdataId)
                    .HasName("wma_f_biometricdata_temp_pkey");

                entity.ToTable("wma_f_biometricdata_temp");

                entity.Property(e => e.BiometricdataId)
                    .HasColumnName("biometricdata_id")
                    .HasDefaultValueSql("nextval('wma_f_biometricdata_temp_seq'::regclass)");

                entity.Property(e => e.AttendancestatusBt).HasColumnName("attendancestatus_bt");

                entity.Property(e => e.BiometricfilelogId).HasColumnName("biometricfilelog_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.EipId).HasColumnName("eip_id");

                entity.Property(e => e.ErrordataVc).HasColumnName("errordata_vc");

                entity.Property(e => e.JobcodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("jobcode_vc");

                entity.Property(e => e.MachineId).HasColumnName("machine_id");

                entity.Property(e => e.OrginaltextVc)
                    .HasMaxLength(50)
                    .HasColumnName("orginaltext_vc");

                entity.Property(e => e.PunchedonDt)
                    .HasPrecision(3)
                    .HasColumnName("punchedon_dt");

                entity.Property(e => e.PunchingtypeVc)
                    .HasMaxLength(10)
                    .HasColumnName("punchingtype_vc");
            });

            modelBuilder.Entity<WmaFBiometricdatajunkdatum>(entity =>
            {
                entity.HasKey(e => e.BiojunkdataId)
                    .HasName("wma_f_biometricdatajunkdata_pkey");

                entity.ToTable("wma_f_biometricdatajunkdata");

                entity.Property(e => e.BiojunkdataId)
                    .HasColumnName("biojunkdata_id")
                    .HasDefaultValueSql("nextval('wma_f_biometricdatajunkdata_seq'::regclass)");

                entity.Property(e => e.BiometricfilelogId).HasColumnName("biometricfilelog_id");

                entity.Property(e => e.JunkdataVc).HasColumnName("junkdata_vc");

                entity.HasOne(d => d.Biometricfilelog)
                    .WithMany(p => p.WmaFBiometricdatajunkdata)
                    .HasForeignKey(d => d.BiometricfilelogId)
                    .HasConstraintName("fk_wma_f_biometricdatajunkdata_biometricfilelogid");
            });

            modelBuilder.Entity<WmaFBiometricdatum>(entity =>
            {
                entity.HasKey(e => e.BiometricdataId)
                    .HasName("wma_f_biometricdata_pkey");

                entity.ToTable("wma_f_biometricdata");

                entity.Property(e => e.BiometricdataId)
                    .HasColumnName("biometricdata_id")
                    .HasDefaultValueSql("nextval('wma_f_biometricdata_seq'::regclass)");

                entity.Property(e => e.AttendancestatusBt).HasColumnName("attendancestatus_bt");

                entity.Property(e => e.BiometricfilelogId).HasColumnName("biometricfilelog_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.EipId).HasColumnName("eip_id");

                entity.Property(e => e.ErrordataVc).HasColumnName("errordata_vc");

                entity.Property(e => e.JobcodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("jobcode_vc");

                entity.Property(e => e.MachineId).HasColumnName("machine_id");

                entity.Property(e => e.OrginaltextVc)
                    .HasMaxLength(50)
                    .HasColumnName("orginaltext_vc");

                entity.Property(e => e.PunchedonDt)
                    .HasPrecision(3)
                    .HasColumnName("punchedon_dt");

                entity.Property(e => e.PunchingtypeVc)
                    .HasMaxLength(10)
                    .HasColumnName("punchingtype_vc");

                entity.HasOne(d => d.Biometricfilelog)
                    .WithMany(p => p.WmaFBiometricdata)
                    .HasForeignKey(d => d.BiometricfilelogId)
                    .HasConstraintName("fk_wma_f_biometricfilelog_biometricfilelogid");
            });

            modelBuilder.Entity<WmaFBiometricfilelog>(entity =>
            {
                entity.HasKey(e => e.BiometricfilelogId)
                    .HasName("wma_f_biometricfilelog_pkey");

                entity.ToTable("wma_f_biometricfilelog");

                entity.Property(e => e.BiometricfilelogId)
                    .HasColumnName("biometricfilelog_id")
                    .HasDefaultValueSql("nextval('wma_f_biometricfilelog_seq'::regclass)");

                entity.Property(e => e.BiometricschedulerId).HasColumnName("biometricscheduler_id");

                entity.Property(e => e.FilenameVc)
                    .HasMaxLength(100)
                    .HasColumnName("filename_vc");

                entity.Property(e => e.FilestatusVc)
                    .HasMaxLength(20)
                    .HasColumnName("filestatus_vc");

                entity.Property(e => e.MessageVc)
                    .HasMaxLength(500)
                    .HasColumnName("message_vc");

                entity.Property(e => e.NoofworkersInt).HasColumnName("noofworkers_int");

                entity.Property(e => e.ProcessendsatDt)
                    .HasPrecision(3)
                    .HasColumnName("processendsat_dt");

                entity.Property(e => e.ProcessstartsatDt)
                    .HasPrecision(3)
                    .HasColumnName("processstartsat_dt");

                entity.HasOne(d => d.Biometricscheduler)
                    .WithMany(p => p.WmaFBiometricfilelogs)
                    .HasForeignKey(d => d.BiometricschedulerId)
                    .HasConstraintName("fk_wma_f_biometricscheduler_biometricscheduler_id");
            });

            modelBuilder.Entity<WmaFBiometricscheduler>(entity =>
            {
                entity.HasKey(e => e.BiometricschedulerId)
                    .HasName("wma_f_biometricscheduler_pkey");

                entity.ToTable("wma_f_biometricscheduler");

                entity.Property(e => e.BiometricschedulerId)
                    .HasColumnName("biometricscheduler_id")
                    .HasDefaultValueSql("nextval('wma_f_biometricscheduler_seq'::regclass)");

                entity.Property(e => e.SchedulerendsatDt)
                    .HasPrecision(3)
                    .HasColumnName("schedulerendsat_dt");

                entity.Property(e => e.SchedulermesageVc)
                    .HasMaxLength(500)
                    .HasColumnName("schedulermesage_vc");

                entity.Property(e => e.SchedulerstartsatDt)
                    .HasPrecision(3)
                    .HasColumnName("schedulerstartsat_dt");

                entity.Property(e => e.SchedulerstatusVc)
                    .HasMaxLength(20)
                    .HasColumnName("schedulerstatus_vc");
            });

            modelBuilder.Entity<WmaFBlacklist>(entity =>
            {
                entity.HasKey(e => e.BlacklistId)
                    .HasName("pk_wma_f_blacklist");

                entity.ToTable("wma_f_blacklist");

                entity.Property(e => e.BlacklistId)
                    .HasColumnName("blacklist_id")
                    .HasDefaultValueSql("nextval('wma_f_blacklist_seq'::regclass)");

                entity.Property(e => e.ApprovedbyId).HasColumnName("approvedby_id");

                entity.Property(e => e.ApprovedonDt)
                    .HasPrecision(3)
                    .HasColumnName("approvedon_dt");

                entity.Property(e => e.BlackedfromprojectId).HasColumnName("blackedfromproject_id");

                entity.Property(e => e.BlacklistattachmentnameVc).HasColumnName("blacklistattachmentname_vc");

                entity.Property(e => e.BlacklistattachmenturlVc).HasColumnName("blacklistattachmenturl_vc");

                entity.Property(e => e.BlaklistattachmentformatVc).HasColumnName("blaklistattachmentformat_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IcadmincommentsVc).HasColumnName("icadmincomments_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ReasonVc).HasColumnName("reason_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFBlacklists)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_blacklist_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFChecklistquestionsresponse>(entity =>
            {
                entity.HasKey(e => e.ChecklistresponseId)
                    .HasName("pk_wma_f_checklistquestionsresponse");

                entity.ToTable("wma_f_checklistquestionsresponse");

                entity.Property(e => e.ChecklistresponseId)
                    .HasColumnName("checklistresponse_id")
                    .HasDefaultValueSql("nextval('wma_f_checklistquestionsresponse_seq'::regclass)");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(50)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ResponseVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaFChecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_checklistquestionsresponse_wma_m_checklist");

                entity.HasOne(d => d.Checklistquestionsmap)
                    .WithMany(p => p.WmaFChecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistquestionsmapId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_checklistquestionsresponse_wma_l_checklistquestionsmap");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFChecklistquestionsresponses)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_checklistquestionsresponse_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFChecklistquestionsresponsehistory>(entity =>
            {
                entity.HasKey(e => e.ChecklistresponsehistoryId)
                    .HasName("pk_wma_f_checklistquestionsresponsehistory");

                entity.ToTable("wma_f_checklistquestionsresponsehistory");

                entity.Property(e => e.ChecklistresponsehistoryId)
                    .HasColumnName("checklistresponsehistory_id")
                    .HasDefaultValueSql("nextval('wma_f_checklistquestionsresponsehistory_seq'::regclass)");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(50)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.ChecklistresponseId).HasColumnName("checklistresponse_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ResponseVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFCompliancedetail>(entity =>
            {
                entity.HasKey(e => e.SitelicenseId)
                    .HasName("pk_wma_f_compliancedetails");

                entity.ToTable("wma_f_compliancedetails");

                entity.Property(e => e.SitelicenseId)
                    .HasColumnName("sitelicense_id")
                    .HasDefaultValueSql("nextval('wma_f_compliancedetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DepositamountFt).HasColumnName("depositamount_ft");

                entity.Property(e => e.DocumentattachmentformatVc).HasColumnName("documentattachmentformat_vc");

                entity.Property(e => e.DocumentattachmentnameVc).HasColumnName("documentattachmentname_vc");

                entity.Property(e => e.DocumentattachmenturlVc).HasColumnName("documentattachmenturl_vc");

                entity.Property(e => e.ExpiryonDt)
                    .HasPrecision(3)
                    .HasColumnName("expiryon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.Issuedby)
                    .HasMaxLength(100)
                    .HasColumnName("issuedby");

                entity.Property(e => e.IssuedbyofficeaddressVc).HasColumnName("issuedbyofficeaddress_vc");

                entity.Property(e => e.IssuedonDt)
                    .HasPrecision(3)
                    .HasColumnName("issuedon_dt");

                entity.Property(e => e.LicensenoVc)
                    .HasMaxLength(100)
                    .HasColumnName("licenseno_vc");

                entity.Property(e => e.LicensetypeId).HasColumnName("licensetype_id");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.Occupiername)
                    .HasMaxLength(200)
                    .HasColumnName("occupiername");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.Registrationno)
                    .HasMaxLength(30)
                    .HasColumnName("registrationno");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.SecuritydepositperworkmenFt).HasColumnName("securitydepositperworkmen_ft");

                entity.Property(e => e.ValidfromDt)
                    .HasPrecision(3)
                    .HasColumnName("validfrom_dt");

                entity.Property(e => e.ValidtillDt)
                    .HasPrecision(3)
                    .HasColumnName("validtill_dt");

                entity.Property(e => e.WorkmencountNb).HasColumnName("workmencount_nb");

                entity.HasOne(d => d.Licensetype)
                    .WithMany(p => p.WmaFCompliancedetails)
                    .HasForeignKey(d => d.LicensetypeId)
                    .HasConstraintName("fk_wma_f_compliancedetails_wma_f_compliancedetails");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFCompliancedetails)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("fk_wma_f_compliancedetails_wma_m_projects");
            });

            modelBuilder.Entity<WmaFCoviddocumentmap>(entity =>
            {
                entity.ToTable("wma_f_coviddocumentmap");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_coviddocumentmap_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkerattachmentId).HasColumnName("workerattachment_id");

                entity.Property(e => e.Workercovid19detailsid).HasColumnName("workercovid19detailsid");

                entity.HasOne(d => d.Workerattachment)
                    .WithMany(p => p.WmaFCoviddocumentmaps)
                    .HasForeignKey(d => d.WorkerattachmentId)
                    .HasConstraintName("fk_wma_f_coviddocumentmap_wma_f_workerattachments");
            });

            modelBuilder.Entity<WmaFCovidvaccinationdetail>(entity =>
            {
                entity.HasKey(e => e.CovidvaccinationId)
                    .HasName("wma_f_covidvaccinationdetails_pkey");

                entity.ToTable("wma_f_covidvaccinationdetails");

                entity.Property(e => e.CovidvaccinationId)
                    .HasColumnName("covidvaccination_id")
                    .HasDefaultValueSql("nextval('wma_f_covidvaccinationdetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyDt)
                    .HasPrecision(3)
                    .HasColumnName("createdby_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.FirstcoviddoseDt)
                    .HasPrecision(3)
                    .HasColumnName("firstcoviddose_dt");

                entity.Property(e => e.FirstcoviddoseId).HasColumnName("firstcoviddose_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedby_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.SecondcoviddoseId).HasColumnName("secondcoviddose_id");

                entity.Property(e => e.SeconddoseDt)
                    .HasPrecision(3)
                    .HasColumnName("seconddose_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Firstcoviddose)
                    .WithMany(p => p.WmaFCovidvaccinationdetailFirstcoviddoses)
                    .HasForeignKey(d => d.FirstcoviddoseId)
                    .HasConstraintName("fk__wma_f_cov__first__6399a2aa");

                entity.HasOne(d => d.Secondcoviddose)
                    .WithMany(p => p.WmaFCovidvaccinationdetailSecondcoviddoses)
                    .HasForeignKey(d => d.SecondcoviddoseId)
                    .HasConstraintName("fk__wma_f_cov__secon__648dc6e3");
            });

            modelBuilder.Entity<WmaFEipapirequestresponsedetail>(entity =>
            {
                entity.HasKey(e => e.EiprequestrepsonsedetailsId)
                    .HasName("pk_wma_f_eipapirequestresponsedetail");

                entity.ToTable("wma_f_eipapirequestresponsedetail");

                entity.Property(e => e.EiprequestrepsonsedetailsId)
                    .HasColumnName("eiprequestrepsonsedetails_id")
                    .HasDefaultValueSql("nextval('wma_f_eipapirequestresponsedetail_seq'::regclass)");

                entity.Property(e => e.ApinameVc)
                    .HasMaxLength(500)
                    .HasColumnName("apiname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FunctionalityVc).HasColumnName("functionality_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RequestcontentVc).HasColumnName("requestcontent_vc");

                entity.Property(e => e.RequesttypeVc)
                    .HasMaxLength(500)
                    .HasColumnName("requesttype_vc");

                entity.Property(e => e.ResponsecontentVc).HasColumnName("responsecontent_vc");

                entity.Property(e => e.ResponsestatuscodeVc).HasColumnName("responsestatuscode_vc");
            });

            modelBuilder.Entity<WmaFIdexpirycountbyproject>(entity =>
            {
                entity.HasKey(e => e.Idexpirycount)
                    .HasName("wma_f_idexpirycountbyproject_pkey");

                entity.ToTable("wma_f_idexpirycountbyproject");

                entity.Property(e => e.Idexpirycount)
                    .HasColumnName("idexpirycount")
                    .HasDefaultValueSql("nextval('wma_f_idexpirycountbyproject_seq'::regclass)");

                entity.Property(e => e.Day).HasColumnName("day");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Totalcount).HasColumnName("totalcount");
            });

            modelBuilder.Entity<WmaFLogtrace>(entity =>
            {
                entity.HasKey(e => e.LogId)
                    .HasName("pk_wma_f_logtrace");

                entity.ToTable("wma_f_logtrace");

                entity.Property(e => e.LogId)
                    .HasColumnName("log_id")
                    .HasDefaultValueSql("nextval('wma_f_logtrace_seq'::regclass)");

                entity.Property(e => e.LogdateDt)
                    .HasPrecision(3)
                    .HasColumnName("logdate_dt");

                entity.Property(e => e.LogmessageVc).HasColumnName("logmessage_vc");

                entity.Property(e => e.LogtypeVc)
                    .HasMaxLength(250)
                    .HasColumnName("logtype_vc");

                entity.Property(e => e.UseridVc)
                    .HasMaxLength(500)
                    .HasColumnName("userid_vc");
            });

            modelBuilder.Entity<WmaFLongabsenceworkerid>(entity =>
            {
                entity.HasKey(e => e.Longabsenceworkerid)
                    .HasName("wma_f_longabsenceworkerid_pkey");

                entity.ToTable("wma_f_longabsenceworkerid");

                entity.Property(e => e.Longabsenceworkerid)
                    .HasColumnName("longabsenceworkerid")
                    .HasDefaultValueSql("nextval('wma_f_longabsenceworkerid_seq'::regclass)");

                entity.Property(e => e.Dateoflongabsence)
                    .HasPrecision(3)
                    .HasColumnName("dateoflongabsence");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");
            });

            modelBuilder.Entity<WmaFMaillog>(entity =>
            {
                entity.ToTable("wma_f_maillog");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_maillog_seq'::regclass)");

                entity.Property(e => e.Attachmentpath)
                    .HasMaxLength(1000)
                    .HasColumnName("attachmentpath");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Error).HasColumnName("error");

                entity.Property(e => e.Isattachmentincluded).HasColumnName("isattachmentincluded");

                entity.Property(e => e.Mailbody).HasColumnName("mailbody");

                entity.Property(e => e.Mailsentto)
                    .HasMaxLength(3000)
                    .HasColumnName("mailsentto");

                entity.Property(e => e.Mailsubject)
                    .HasMaxLength(1000)
                    .HasColumnName("mailsubject");

                entity.Property(e => e.Mailtype).HasColumnName("mailtype");

                entity.Property(e => e.Responsecode)
                    .HasMaxLength(50)
                    .HasColumnName("responsecode");
            });

            modelBuilder.Entity<WmaFMedicalchecklistquestionsresponse>(entity =>
            {
                entity.HasKey(e => e.ChecklistresponseId)
                    .HasName("wma_f_medicalchecklistquestionsresponse_pkey");

                entity.ToTable("wma_f_medicalchecklistquestionsresponse");

                entity.Property(e => e.ChecklistresponseId)
                    .HasColumnName("checklistresponse_id")
                    .HasDefaultValueSql("nextval('wma_f_medicalchecklistquestionsresponse_seq'::regclass)");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(50)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ResponseVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaFMedicalchecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_f_medicalchecklistquestionsresponse_checklist_id_fkey");

                entity.HasOne(d => d.Checklistquestionsmap)
                    .WithMany(p => p.WmaFMedicalchecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistquestionsmapId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_f_medicalchecklistquestionsre_checklistquestionsmap_id_fkey");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFMedicalchecklistquestionsresponses)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_f_medicalchecklistquestionsresponse_worker_id_fkey");
            });

            modelBuilder.Entity<WmaFMedicalchecklistquestionsresponsehistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wma_f_medicalchecklistquestionsresponsehistory");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(50)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.ChecklistresponseId).HasColumnName("checklistresponse_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.MedicalchecklistresponsehistoryId)
                    .HasColumnName("medicalchecklistresponsehistory_id")
                    .HasDefaultValueSql("nextval('wma_f_medicalchecklistquestionsresponsehistory_seq'::regclass)");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ResponseVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFNoticeboarddetail>(entity =>
            {
                entity.HasKey(e => e.Noticeboarddetailid)
                    .HasName("pk_wma_f_noticeboarddocumentmap");

                entity.ToTable("wma_f_noticeboarddetail");

                entity.Property(e => e.Noticeboarddetailid)
                    .HasColumnName("noticeboarddetailid")
                    .HasDefaultValueSql("nextval('wma_f_noticeboarddetail_seq'::regclass)");

                entity.Property(e => e.CategoryId).HasColumnName("category_id");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Createdbyroleid).HasColumnName("createdbyroleid");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Noticecategoryname)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("noticecategoryname");

                entity.Property(e => e.Remarks)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("remarks");

                entity.Property(e => e.Revision).HasColumnName("revision");

                entity.Property(e => e.SubcategoryId).HasColumnName("subcategory_id");

                entity.Property(e => e.ViewAccess)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("view_access");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.WmaFNoticeboarddetailCreatedByNavigations)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_noticeboarddetail_wma_f_noticeboarddetail");

                entity.HasOne(d => d.ModifiedByNavigation)
                    .WithMany(p => p.WmaFNoticeboarddetailModifiedByNavigations)
                    .HasForeignKey(d => d.ModifiedBy)
                    .HasConstraintName("fk_wma_f_noticeboarddetail_wma_m_user");

                entity.HasOne(d => d.Subcategory)
                    .WithMany(p => p.WmaFNoticeboarddetails)
                    .HasForeignKey(d => d.SubcategoryId)
                    .HasConstraintName("fk_wma_f_noticeboarddocumentmap_wma_m_noticeboardsubcategory");
            });

            modelBuilder.Entity<WmaFNoticeboarddetailhistory>(entity =>
            {
                entity.HasKey(e => e.HistoryId)
                    .HasName("pk_wma_f_noticeboarddocumentmaphistory");

                entity.ToTable("wma_f_noticeboarddetailhistory");

                entity.Property(e => e.HistoryId)
                    .HasColumnName("history_id")
                    .HasDefaultValueSql("nextval('wma_f_noticeboarddetailhistory_seq'::regclass)");

                entity.Property(e => e.CategoryId).HasColumnName("category_id");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Createdbyroleid).HasColumnName("createdbyroleid");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Noticeboarddetailid).HasColumnName("noticeboarddetailid");

                entity.Property(e => e.Noticecategoryname)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("noticecategoryname");

                entity.Property(e => e.Remarks)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("remarks");

                entity.Property(e => e.Revision).HasColumnName("revision");

                entity.Property(e => e.SubcategoryId).HasColumnName("subcategory_id");

                entity.Property(e => e.ViewAccess)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("view_access");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.WmaFNoticeboarddetailhistories)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_noticeboarddetailhistory_wma_m_user");
            });

            modelBuilder.Entity<WmaFNoticeboarddocumentsmap>(entity =>
            {
                entity.ToTable("wma_f_noticeboarddocumentsmap");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_noticeboarddocumentsmap_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Documentid).HasColumnName("documentid");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Noticeboardid).HasColumnName("noticeboardid");

                entity.Property(e => e.Revision).HasColumnName("revision");

                entity.HasOne(d => d.Document)
                    .WithMany(p => p.WmaFNoticeboarddocumentsmaps)
                    .HasForeignKey(d => d.Documentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_noticeboarddocumentsmap_wma_l_projectattachments");

                entity.HasOne(d => d.Noticeboard)
                    .WithMany(p => p.WmaFNoticeboarddocumentsmaps)
                    .HasForeignKey(d => d.Noticeboardid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_noticeboarddocumentsmap_wma_f_noticeboarddetail");
            });

            modelBuilder.Entity<WmaFNoticeboardrolecategorymap>(entity =>
            {
                entity.ToTable("wma_f_noticeboardrolecategorymap");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_noticeboardrolecategorymap_seq'::regclass)");

                entity.Property(e => e.CategoryId).HasColumnName("category_id");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.DeleteAccess).HasColumnName("delete_access");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.IsSubcategory).HasColumnName("is_subcategory");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ReadAccess).HasColumnName("read_access");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UploadAccess).HasColumnName("upload_access");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaFNoticeboardrolecategorymaps)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_noticeboardrolecategorymap_wma_f_noticeboardrolecatego");
            });

            modelBuilder.Entity<WmaFRankingchecklistquestionsresponse>(entity =>
            {
                entity.HasKey(e => e.ChecklistresponseId)
                    .HasName("wma_f_rankingchecklistquestionsresponse_pkey");

                entity.ToTable("wma_f_rankingchecklistquestionsresponse");

                entity.Property(e => e.ChecklistresponseId)
                    .HasColumnName("checklistresponse_id")
                    .HasDefaultValueSql("nextval('wma_f_rankingchecklistquestionsresponse_seq'::regclass)");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ResponseVc)
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaFRankingchecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("wma_f_rankingchecklistquestionsresponse_checklist_id_fkey");

                entity.HasOne(d => d.Checklistquestionsmap)
                    .WithMany(p => p.WmaFRankingchecklistquestionsresponses)
                    .HasForeignKey(d => d.ChecklistquestionsmapId)
                    .HasConstraintName("wma_f_rankingchecklistquestionsre_checklistquestionsmap_id_fkey");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFRankingchecklistquestionsresponses)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("wma_f_rankingchecklistquestionsresponse_worker_id_fkey");
            });

            modelBuilder.Entity<WmaFRankingchecklistquestionsresponsehistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wma_f_rankingchecklistquestionsresponsehistory");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.ChecklistresponseId).HasColumnName("checklistresponse_id");

                entity.Property(e => e.ChecklistresponsehistoryId)
                    .HasColumnName("checklistresponsehistory_id")
                    .HasDefaultValueSql("nextval('wma_f_rankingchecklistquestionsresponsehistory_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ResponseVc)
                    .HasMaxLength(50)
                    .HasColumnName("response_vc");

                entity.Property(e => e.ResponsecommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("responsecomments_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFReleaserequest>(entity =>
            {
                entity.HasKey(e => e.ReleaserequestId)
                    .HasName("pk_wma_f_releaserequest");

                entity.ToTable("wma_f_releaserequest");

                entity.Property(e => e.ReleaserequestId)
                    .HasColumnName("releaserequest_id")
                    .HasDefaultValueSql("nextval('wma_f_releaserequest_seq'::regclass)");

                entity.Property(e => e.CommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("comments_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ExistingprojectId).HasColumnName("existingproject_id");

                entity.Property(e => e.IsreleasedBt).HasColumnName("isreleased_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RequestingprojectId).HasColumnName("requestingproject_id");

                entity.Property(e => e.SubmittedbyId).HasColumnName("submittedby_id");

                entity.Property(e => e.SubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("submittedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Existingproject)
                    .WithMany(p => p.WmaFReleaserequestExistingprojects)
                    .HasForeignKey(d => d.ExistingprojectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequest_wma_m_projects");

                entity.HasOne(d => d.Requestingproject)
                    .WithMany(p => p.WmaFReleaserequestRequestingprojects)
                    .HasForeignKey(d => d.RequestingprojectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequest_wma_m_projects1");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFReleaserequests)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequest_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFReleaserequesthistory>(entity =>
            {
                entity.HasKey(e => e.ReleaserequesthistoryId)
                    .HasName("pk_wma_f_releaserequesthistory");

                entity.ToTable("wma_f_releaserequesthistory");

                entity.Property(e => e.ReleaserequesthistoryId)
                    .HasColumnName("releaserequesthistory_id")
                    .HasDefaultValueSql("nextval('wma_f_releaserequesthistory_seq'::regclass)");

                entity.Property(e => e.CommentsVc)
                    .HasMaxLength(500)
                    .HasColumnName("comments_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ExistingprojectId).HasColumnName("existingproject_id");

                entity.Property(e => e.IsreleasedBt).HasColumnName("isreleased_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ReleaserequestId).HasColumnName("releaserequest_id");

                entity.Property(e => e.RequestingprojectId).HasColumnName("requestingproject_id");

                entity.Property(e => e.SubmittedbyId).HasColumnName("submittedby_id");

                entity.Property(e => e.SubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("submittedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Existingproject)
                    .WithMany(p => p.WmaFReleaserequesthistoryExistingprojects)
                    .HasForeignKey(d => d.ExistingprojectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequesthistory_wma_m_projects");

                entity.HasOne(d => d.Releaserequest)
                    .WithMany(p => p.WmaFReleaserequesthistories)
                    .HasForeignKey(d => d.ReleaserequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequesthistory_wma_f_releaserequest");

                entity.HasOne(d => d.Requestingproject)
                    .WithMany(p => p.WmaFReleaserequesthistoryRequestingprojects)
                    .HasForeignKey(d => d.RequestingprojectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequesthistory_wma_m_projects1");

                entity.HasOne(d => d.Submittedby)
                    .WithMany(p => p.WmaFReleaserequesthistories)
                    .HasForeignKey(d => d.SubmittedbyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequesthistory_wma_m_user");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFReleaserequesthistories)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_releaserequesthistory_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFSubcontractorselfdeclaration>(entity =>
            {
                entity.HasKey(e => e.Subcontractorsdid)
                    .HasName("pk_wma_f_subcontractorselfdeclaration");

                entity.ToTable("wma_f_subcontractorselfdeclaration");

                entity.Property(e => e.Subcontractorsdid)
                    .HasColumnName("subcontractorsdid")
                    .HasDefaultValueSql("nextval('wma_f_subcontractorselfdeclaration_seq'::regclass)");

                entity.Property(e => e.Attachmentid).HasColumnName("attachmentid");

                entity.Property(e => e.Contractorname)
                    .HasMaxLength(500)
                    .HasColumnName("contractorname");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Mobileno)
                    .HasMaxLength(20)
                    .HasColumnName("mobileno");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.Noofworkers).HasColumnName("noofworkers");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Vendorcode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("vendorcode");

                entity.Property(e => e.Vendorname)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("vendorname");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFSubcontractorselfdeclarations)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_subcontractorselfdeclaration_wma_m_projects");
            });

            modelBuilder.Entity<WmaFTraProjecttrainingdetail>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingId)
                    .HasName("wma_f_tra_projecttrainingdetails_pkey");

                entity.ToTable("wma_f_tra_projecttrainingdetails");

                entity.Property(e => e.ProjecttrainingId)
                    .HasColumnName("projecttraining_id")
                    .HasDefaultValueSql("nextval('wma_f_tra_projecttrainingdetails_seq'::regclass)");

                entity.Property(e => e.ApprovedbyId).HasColumnName("approvedby_id");

                entity.Property(e => e.ApprovedonDt)
                    .HasPrecision(3)
                    .HasColumnName("approvedon_dt");

                entity.Property(e => e.ClosedbyId).HasColumnName("closedby_id");

                entity.Property(e => e.ClosedonDt)
                    .HasPrecision(3)
                    .HasColumnName("closedon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ParticipantsexpectedcountNb).HasColumnName("participantsexpectedcount_nb");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ProjecttrainingapproverId).HasColumnName("projecttrainingapprover_id");

                entity.Property(e => e.Projecttrainingfeedback)
                    .HasMaxLength(200)
                    .HasColumnName("projecttrainingfeedback");

                entity.Property(e => e.Projecttrainingscopeforimprovement)
                    .HasMaxLength(200)
                    .HasColumnName("projecttrainingscopeforimprovement");

                entity.Property(e => e.ProjecttrainingstatusVc)
                    .HasMaxLength(30)
                    .HasColumnName("projecttrainingstatus_vc");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.TrainingId).HasColumnName("training_id");

                entity.Property(e => e.Trainingoverallbenefits)
                    .HasMaxLength(200)
                    .HasColumnName("trainingoverallbenefits");

                entity.Property(e => e.Trainingremarks)
                    .HasMaxLength(200)
                    .HasColumnName("trainingremarks");

                entity.Property(e => e.Trainingscheduleddate)
                    .HasColumnType("date")
                    .HasColumnName("trainingscheduleddate");

                entity.Property(e => e.Venueormaterials)
                    .HasMaxLength(200)
                    .HasColumnName("venueormaterials");

                entity.HasOne(d => d.Approvedby)
                    .WithMany(p => p.WmaFTraProjecttrainingdetailApprovedbies)
                    .HasForeignKey(d => d.ApprovedbyId)
                    .HasConstraintName("fk_wma_f_tra_projecttrainingdetails_wma_m_user_2");

                entity.HasOne(d => d.Closedby)
                    .WithMany(p => p.WmaFTraProjecttrainingdetailClosedbies)
                    .HasForeignKey(d => d.ClosedbyId)
                    .HasConstraintName("fk_wma_f_tra_projecttrainingdetails_wma_m_user_3");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFTraProjecttrainingdetails)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_tra_projecttrainingdetails_wma_m_projects");

                entity.HasOne(d => d.Projecttrainingapprover)
                    .WithMany(p => p.WmaFTraProjecttrainingdetailProjecttrainingapprovers)
                    .HasForeignKey(d => d.ProjecttrainingapproverId)
                    .HasConstraintName("fk_wma_f_tra_projecttrainingdetails_wma_m_user_1");

                entity.HasOne(d => d.Training)
                    .WithMany(p => p.WmaFTraProjecttrainingdetails)
                    .HasForeignKey(d => d.TrainingId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_tra_projecttrainingdetails_wma_f_tra_training");
            });

            modelBuilder.Entity<WmaFTraProjecttrainingdetailshistory>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingdetailshistoryId)
                    .HasName("wma_f_tra_projecttrainingdetailshistory_pkey");

                entity.ToTable("wma_f_tra_projecttrainingdetailshistory");

                entity.Property(e => e.ProjecttrainingdetailshistoryId)
                    .HasColumnName("projecttrainingdetailshistory_id")
                    .HasDefaultValueSql("nextval('wma_f_tra_projecttrainingdetailshistory_seq'::regclass)");

                entity.Property(e => e.ApprovedbyId).HasColumnName("approvedby_id");

                entity.Property(e => e.ApprovedonDt)
                    .HasPrecision(3)
                    .HasColumnName("approvedon_dt");

                entity.Property(e => e.ClosedbyId).HasColumnName("closedby_id");

                entity.Property(e => e.ClosedonDt)
                    .HasPrecision(3)
                    .HasColumnName("closedon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.HistorycreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("historycreatedon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ParticipantsexpectedcountNb).HasColumnName("participantsexpectedcount_nb");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");

                entity.Property(e => e.ProjecttrainingapproverId).HasColumnName("projecttrainingapprover_id");

                entity.Property(e => e.Projecttrainingfeedback)
                    .HasMaxLength(200)
                    .HasColumnName("projecttrainingfeedback");

                entity.Property(e => e.Projecttrainingscopeforimprovement)
                    .HasMaxLength(200)
                    .HasColumnName("projecttrainingscopeforimprovement");

                entity.Property(e => e.ProjecttrainingstatusVc)
                    .HasMaxLength(30)
                    .HasColumnName("projecttrainingstatus_vc");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.TrainingId).HasColumnName("training_id");

                entity.Property(e => e.Trainingoverallbenefits)
                    .HasMaxLength(200)
                    .HasColumnName("trainingoverallbenefits");

                entity.Property(e => e.Trainingremarks)
                    .HasMaxLength(200)
                    .HasColumnName("trainingremarks");

                entity.Property(e => e.Trainingscheduleddate)
                    .HasColumnType("date")
                    .HasColumnName("trainingscheduleddate");

                entity.Property(e => e.Venueormaterials)
                    .HasMaxLength(200)
                    .HasColumnName("venueormaterials");
            });

            modelBuilder.Entity<WmaFTraTraining>(entity =>
            {
                entity.HasKey(e => e.TrainingId)
                    .HasName("pk__wma_f_tr__ef9c381690632d9d");

                entity.ToTable("wma_f_tra_training");

                entity.Property(e => e.TrainingId)
                    .HasColumnName("training_id")
                    .HasDefaultValueSql("nextval('wma_f_tra_training_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.Istrainingmandatory).HasColumnName("istrainingmandatory");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.OthertrainingmodeVc)
                    .HasMaxLength(100)
                    .HasColumnName("othertrainingmode_vc");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.Trainingbroadcontent)
                    .HasMaxLength(200)
                    .HasColumnName("trainingbroadcontent");

                entity.Property(e => e.TrainingcategoryId).HasColumnName("trainingcategory_id");

                entity.Property(e => e.TrainingdescriptionVc)
                    .HasMaxLength(100)
                    .HasColumnName("trainingdescription_vc");

                entity.Property(e => e.Trainingdurationinhrs)
                    .HasPrecision(18, 2)
                    .HasColumnName("trainingdurationinhrs");

                entity.Property(e => e.Trainingkeyobjective)
                    .HasMaxLength(100)
                    .HasColumnName("trainingkeyobjective");

                entity.Property(e => e.TrainingmodeId).HasColumnName("trainingmode_id");

                entity.Property(e => e.Trainingperiodfrom)
                    .HasPrecision(3)
                    .HasColumnName("trainingperiodfrom");

                entity.Property(e => e.Trainingperiodto)
                    .HasPrecision(3)
                    .HasColumnName("trainingperiodto");

                entity.Property(e => e.TrainingtypeId).HasColumnName("trainingtype_id");

                entity.Property(e => e.Trainingvalidity).HasColumnName("trainingvalidity");

                entity.HasOne(d => d.Trainingcategory)
                    .WithMany(p => p.WmaFTraTrainings)
                    .HasForeignKey(d => d.TrainingcategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_tra_training_wma_m_tra_trainingcategory");

                entity.HasOne(d => d.Trainingtype)
                    .WithMany(p => p.WmaFTraTrainings)
                    .HasForeignKey(d => d.TrainingtypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_tra_training_wma_m_tra_trainingtypes");
            });

            modelBuilder.Entity<WmaFWageArrear>(entity =>
            {
                entity.HasKey(e => e.Arrearid)
                    .HasName("pk_wma_f_wage_arrear");

                entity.ToTable("wma_f_wage_arrear");

                entity.Property(e => e.Arrearid)
                    .HasColumnName("arrearid")
                    .HasDefaultValueSql("nextval('wma_f_wage_arrear_seq'::regclass)");

                entity.Property(e => e.Arrearamount)
                    .HasPrecision(10, 2)
                    .HasColumnName("arrearamount");

                entity.Property(e => e.Arreartype).HasColumnName("arreartype");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectivefrom)
                    .HasPrecision(3)
                    .HasColumnName("effectivefrom");

                entity.Property(e => e.Esci)
                    .HasPrecision(10, 2)
                    .HasColumnName("esci");

                entity.Property(e => e.Incometax)
                    .HasPrecision(10, 2)
                    .HasColumnName("incometax");

                entity.Property(e => e.Insurance)
                    .HasPrecision(10, 2)
                    .HasColumnName("insurance");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isprocessed).HasColumnName("isprocessed");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Netpayment)
                    .HasPrecision(10, 2)
                    .HasColumnName("netpayment");

                entity.Property(e => e.Otarrear)
                    .HasPrecision(10, 2)
                    .HasColumnName("otarrear");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Othersded)
                    .HasPrecision(10, 2)
                    .HasColumnName("othersded");

                entity.Property(e => e.Pfdeduction)
                    .HasPrecision(10, 2)
                    .HasColumnName("pfdeduction");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Recoveries)
                    .HasPrecision(10, 2)
                    .HasColumnName("recoveries");

                entity.Property(e => e.Requesttypemapid).HasColumnName("requesttypemapid");

                entity.Property(e => e.Society)
                    .HasPrecision(10, 2)
                    .HasColumnName("society");

                entity.Property(e => e.Totaldeductions)
                    .HasPrecision(10, 2)
                    .HasColumnName("totaldeductions");

                entity.Property(e => e.Totalearnings)
                    .HasPrecision(10, 2)
                    .HasColumnName("totalearnings");

                entity.Property(e => e.Totalothours).HasColumnName("totalothours");

                entity.Property(e => e.Totalworkingdays).HasColumnName("totalworkingdays");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");

                entity.Property(e => e.Workerwageprocessid).HasColumnName("workerwageprocessid");
            });

            modelBuilder.Entity<WmaFWageArrearprocesslog>(entity =>
            {
                entity.HasKey(e => e.Arrearprocesslogid)
                    .HasName("wma_f_wage_arrearprocesslog_pkey");

                entity.ToTable("wma_f_wage_arrearprocesslog");

                entity.Property(e => e.Arrearprocesslogid)
                    .HasColumnName("arrearprocesslogid")
                    .HasDefaultValueSql("nextval('wma_f_wage_arrearprocesslog_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Processenddatetime)
                    .HasPrecision(3)
                    .HasColumnName("processenddatetime");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Processstartdatetime)
                    .HasPrecision(3)
                    .HasColumnName("processstartdatetime");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Remarks)
                    .IsRequired()
                    .HasColumnName("remarks");

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<WmaFWageArrearworkersitelevelcompdetail>(entity =>
            {
                entity.ToTable("wma_f_wage_arrearworkersitelevelcompdetail");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_arrearworkersitelevelcompdetail_seq'::regclass)");

                entity.Property(e => e.Amount)
                    .HasPrecision(10, 2)
                    .HasColumnName("amount");

                entity.Property(e => e.Arrearid).HasColumnName("arrearid");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive)
                    .HasColumnName("isactive")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Isallowancecomp).HasColumnName("isallowancecomp");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Projectid).HasColumnName("projectid");
            });

            modelBuilder.Entity<WmaFWageAttendanceregularisation>(entity =>
            {
                entity.HasKey(e => e.AttendanceRegularisationId)
                    .HasName("pk_wma_f_wage_attendanceregularisation");

                entity.ToTable("wma_f_wage_attendanceregularisation");

                entity.Property(e => e.AttendanceRegularisationId)
                    .HasColumnName("attendance_regularisation_id")
                    .HasDefaultValueSql("nextval('wma_f_wage_attendanceregularisation_seq'::regclass)");

                entity.Property(e => e.Approvalremarks)
                    .HasMaxLength(200)
                    .HasColumnName("approvalremarks");

                entity.Property(e => e.Approvalrequestedtoid).HasColumnName("approvalrequestedtoid");

                entity.Property(e => e.Approvedby).HasColumnName("approvedby");

                entity.Property(e => e.Approvedon)
                    .HasPrecision(3)
                    .HasColumnName("approvedon");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Date)
                    .HasPrecision(3)
                    .HasColumnName("date");

                entity.Property(e => e.Intime)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("intime");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isapproved).HasColumnName("isapproved");

                entity.Property(e => e.Isexcelupload).HasColumnName("isexcelupload");

                entity.Property(e => e.Isprocessed).HasColumnName("isprocessed");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Outtime)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("outtime");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Regularisationtypeid).HasColumnName("regularisationtypeid");

                entity.Property(e => e.Requestremarks)
                    .HasMaxLength(200)
                    .HasColumnName("requestremarks");

                entity.Property(e => e.Shiftid).HasColumnName("shiftid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.ApprovedbyNavigation)
                    .WithMany(p => p.WmaFWageAttendanceregularisationApprovedbyNavigations)
                    .HasForeignKey(d => d.Approvedby)
                    .HasConstraintName("fk_wma_f_wage_attendanceregularisation_wma_m_user");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.WmaFWageAttendanceregularisationCreatedByNavigations)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_attendanceregularisation_wma_m_user1");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWageAttendanceregularisations)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_attendanceregularisation_wma_m_projects");

                entity.HasOne(d => d.Regularisationtype)
                    .WithMany(p => p.WmaFWageAttendanceregularisations)
                    .HasForeignKey(d => d.Regularisationtypeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_attendanceregularisation_wma_m_regularisationtype");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWageAttendanceregularisations)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_attendanceregularisation_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWageBonusdetail>(entity =>
            {
                entity.ToTable("wma_f_wage_bonusdetail");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_bonusdetail_seq'::regclass)");

                entity.Property(e => e.Bonusname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("bonusname");

                entity.Property(e => e.Bonustypeid).HasColumnName("bonustypeid");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Effectivefrom)
                    .HasPrecision(3)
                    .HasColumnName("effectivefrom");

                entity.Property(e => e.Effectiveto)
                    .HasPrecision(3)
                    .HasColumnName("effectiveto");

                entity.Property(e => e.Eligibility).HasColumnName("eligibility");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Ispercent).HasColumnName("ispercent");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Value)
                    .HasPrecision(10, 2)
                    .HasColumnName("value");

                entity.HasOne(d => d.Bonustype)
                    .WithMany(p => p.WmaFWageBonusdetails)
                    .HasForeignKey(d => d.Bonustypeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_bonusdetail_wma_m_bonustype");
            });

            modelBuilder.Entity<WmaFWageComponentsdeductiblefrommap>(entity =>
            {
                entity.ToTable("wma_f_wage_componentsdeductiblefrommap");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_componentsdeductiblefrommap_seq'::regclass)");

                entity.Property(e => e.CompTxnId).HasColumnName("comp_txn_id");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.HasOne(d => d.CompTxn)
                    .WithMany(p => p.WmaFWageComponentsdeductiblefrommaps)
                    .HasForeignKey(d => d.CompTxnId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_componentsdeductiblefrommap_wma_f_wage_components");

                entity.HasOne(d => d.Component)
                    .WithMany(p => p.WmaFWageComponentsdeductiblefrommaps)
                    .HasForeignKey(d => d.Componentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_componentsdeductiblefrommap_wma_m_wage_sitecompon");
            });

            modelBuilder.Entity<WmaFWageFullandfinalsettlement>(entity =>
            {
                entity.ToTable("wma_f_wage_fullandfinalsettlement");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_fullandfinalsettlement_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Encashmentamount).HasColumnName("encashmentamount");

                entity.Property(e => e.Gratuityamount).HasColumnName("gratuityamount");

                entity.Property(e => e.Gratutityfromdate)
                    .HasPrecision(3)
                    .HasColumnName("gratutityfromdate");

                entity.Property(e => e.Gratutitytodate)
                    .HasPrecision(3)
                    .HasColumnName("gratutitytodate");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Releievingtradeid).HasColumnName("releievingtradeid");

                entity.Property(e => e.Releievingwage).HasColumnName("releievingwage");

                entity.Property(e => e.Releivingelbalance).HasColumnName("releivingelbalance");

                entity.Property(e => e.Releivingwage).HasColumnName("releivingwage");

                entity.Property(e => e.Relievingdate)
                    .HasPrecision(3)
                    .HasColumnName("relievingdate");

                entity.Property(e => e.Total).HasColumnName("total");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWageFullandfinalsettlements)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_fullandfinalsettlement_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWageHolidaycalendar>(entity =>
            {
                entity.ToTable("wma_f_wage_holidaycalendar");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_holidaycalendar_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Date)
                    .HasPrecision(3)
                    .HasColumnName("date");

                entity.Property(e => e.Holidayname)
                    .HasMaxLength(50)
                    .HasColumnName("holidayname");

                entity.Property(e => e.Holidaytypeid).HasColumnName("holidaytypeid");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Ispaidholiday).HasColumnName("ispaidholiday");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Projectid).HasColumnName("projectid");
            });

            modelBuilder.Entity<WmaFWageOtregularisation>(entity =>
            {
                entity.HasKey(e => e.OtRegularisationId)
                    .HasName("pk_wma_f_wage_otregularisation");

                entity.ToTable("wma_f_wage_otregularisation");

                entity.Property(e => e.OtRegularisationId)
                    .HasColumnName("ot_regularisation_id")
                    .HasDefaultValueSql("nextval('wma_f_wage_otregularisation_seq'::regclass)");

                entity.Property(e => e.Approvalremarks)
                    .HasMaxLength(200)
                    .HasColumnName("approvalremarks");

                entity.Property(e => e.Approvalrequestedtoid).HasColumnName("approvalrequestedtoid");

                entity.Property(e => e.Approvedby).HasColumnName("approvedby");

                entity.Property(e => e.Approvedon)
                    .HasPrecision(3)
                    .HasColumnName("approvedon");

                entity.Property(e => e.Areaofworking)
                    .HasMaxLength(80)
                    .HasColumnName("areaofworking");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Date)
                    .HasPrecision(3)
                    .HasColumnName("date");

                entity.Property(e => e.Intime)
                    .HasColumnType("time(2) without time zone")
                    .HasColumnName("intime");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isapproved).HasColumnName("isapproved");

                entity.Property(e => e.Isprocessed).HasColumnName("isprocessed");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Othours).HasColumnName("othours");

                entity.Property(e => e.Outtime)
                    .HasColumnType("time(2) without time zone")
                    .HasColumnName("outtime");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Type)
                    .HasMaxLength(100)
                    .HasColumnName("type");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Approvalrequestedto)
                    .WithMany(p => p.WmaFWageOtregularisationApprovalrequestedtos)
                    .HasForeignKey(d => d.Approvalrequestedtoid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_otregularisation_wma_m_user");

                entity.HasOne(d => d.ApprovedbyNavigation)
                    .WithMany(p => p.WmaFWageOtregularisationApprovedbyNavigations)
                    .HasForeignKey(d => d.Approvedby)
                    .HasConstraintName("fk_wma_f_wage_otregularisation_wma_m_user2");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.WmaFWageOtregularisationCreatedByNavigations)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_otregularisation_wma_m_user1");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWageOtregularisations)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_otregularisation_wma_m_projects");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWageOtregularisations)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_otregularisation_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWageProcessedbonusdetail>(entity =>
            {
                entity.ToTable("wma_f_wage_processedbonusdetail");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_processedbonusdetail_seq'::regclass)");

                entity.Property(e => e.Amount)
                    .HasPrecision(10, 2)
                    .HasColumnName("amount");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Effectivefrom)
                    .HasPrecision(3)
                    .HasColumnName("effectivefrom");

                entity.Property(e => e.Effectiveto)
                    .HasPrecision(3)
                    .HasColumnName("effectiveto");

                entity.Property(e => e.Isactive)
                    .IsRequired()
                    .HasColumnName("isactive")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Ispercent).HasColumnName("ispercent");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");
            });

            modelBuilder.Entity<WmaFWageSitelevelcomponent>(entity =>
            {
                entity.HasKey(e => e.CompTxnId)
                    .HasName("pk_wma_f_sitelevelcomponents");

                entity.ToTable("wma_f_wage_sitelevelcomponents");

                entity.Property(e => e.CompTxnId)
                    .HasColumnName("comp_txn_id")
                    .HasDefaultValueSql("nextval('wma_f_wage_sitelevelcomponents_seq'::regclass)");

                entity.Property(e => e.ApprovedBy).HasColumnName("approved_by");

                entity.Property(e => e.ApprovedOn)
                    .HasPrecision(3)
                    .HasColumnName("approved_on");

                entity.Property(e => e.Approverremarks)
                    .HasMaxLength(500)
                    .HasColumnName("approverremarks");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Effectivefrom)
                    .HasPrecision(3)
                    .HasColumnName("effectivefrom");

                entity.Property(e => e.Effectiveto)
                    .HasPrecision(3)
                    .HasColumnName("effectiveto");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isallowancecomponent).HasColumnName("isallowancecomponent");

                entity.Property(e => e.Isapproved).HasColumnName("isapproved");

                entity.Property(e => e.Ispercent).HasColumnName("ispercent");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Value)
                    .HasPrecision(10, 2)
                    .HasColumnName("value");

                entity.HasOne(d => d.ApprovedByNavigation)
                    .WithMany(p => p.WmaFWageSitelevelcomponents)
                    .HasForeignKey(d => d.ApprovedBy)
                    .HasConstraintName("fk_wma_f_wage_sitelevelcomponents_wma_m_user");

                entity.HasOne(d => d.Component)
                    .WithMany(p => p.WmaFWageSitelevelcomponents)
                    .HasForeignKey(d => d.Componentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_sitelevelcomponents_wma_m_wage_sitecomponent_mst");
            });

            modelBuilder.Entity<WmaFWageWageprocesslog>(entity =>
            {
                entity.HasKey(e => e.Wagprocesslogid)
                    .HasName("pk_wma_f_wage_wageprocesslog");

                entity.ToTable("wma_f_wage_wageprocesslog");

                entity.Property(e => e.Wagprocesslogid)
                    .HasColumnName("wagprocesslogid")
                    .HasDefaultValueSql("nextval('wma_f_wage_wageprocesslog_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Processenddatetime)
                    .HasPrecision(3)
                    .HasColumnName("processenddatetime");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Processstartdatetime)
                    .HasPrecision(3)
                    .HasColumnName("processstartdatetime");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Remarks)
                    .IsRequired()
                    .HasColumnName("remarks");

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<WmaFWageWorkersitelevelcompdetail>(entity =>
            {
                entity.ToTable("wma_f_wage_workersitelevelcompdetail");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_wage_workersitelevelcompdetail_seq'::regclass)");

                entity.Property(e => e.Amount)
                    .HasPrecision(10, 2)
                    .HasColumnName("amount");

                entity.Property(e => e.Componentid).HasColumnName("componentid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive)
                    .HasColumnName("isactive")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Isallowancecomp).HasColumnName("isallowancecomp");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");

                entity.HasOne(d => d.Component)
                    .WithMany(p => p.WmaFWageWorkersitelevelcompdetails)
                    .HasForeignKey(d => d.Componentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_workersitelevelcompdetail_wma_m_wage_sitecomponen");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaFWageWorkersitelevelcompdetails)
                    .HasForeignKey(d => d.Tradeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_wage_workersitelevelcompdetail_wma_m_trades");
            });

            modelBuilder.Entity<WmaFWageWorkerwageapproval>(entity =>
            {
                entity.HasKey(e => e.Workerwageapprovalid)
                    .HasName("wma_f_wage_workerwageapproval_pkey");

                entity.ToTable("wma_f_wage_workerwageapproval");

                entity.Property(e => e.Workerwageapprovalid)
                    .HasColumnName("workerwageapprovalid")
                    .HasDefaultValueSql("nextval('wma_f_wage_workerwageapproval_seq'::regclass)");

                entity.Property(e => e.Approvedby).HasColumnName("approvedby");

                entity.Property(e => e.Approvedon)
                    .HasPrecision(3)
                    .HasColumnName("approvedon");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isapproved).HasColumnName("isapproved");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Remark).HasColumnName("remark");

                entity.Property(e => e.Requestingwage)
                    .HasPrecision(18)
                    .HasColumnName("requestingwage");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");
            });

            modelBuilder.Entity<WmaFWageWorkerwagemapping>(entity =>
            {
                entity.HasKey(e => e.Workerwagemappingid)
                    .HasName("pk__wma_f_wa__4f31fd5977727311");

                entity.ToTable("wma_f_wage_workerwagemapping");

                entity.Property(e => e.Workerwagemappingid)
                    .HasColumnName("workerwagemappingid")
                    .HasDefaultValueSql("nextval('wma_f_wage_workerwagemapping_seq'::regclass)");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Recommendedwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("recommendedwage");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");

                entity.Property(e => e.Wageid).HasColumnName("wageid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerwageapprovalid).HasColumnName("workerwageapprovalid");
            });

            modelBuilder.Entity<WmaFWageWorkerwagemappinghistory>(entity =>
            {
                entity.HasKey(e => e.Historyid)
                    .HasName("pk_wma_f_wage_workerwagemappinghistory");

                entity.ToTable("wma_f_wage_workerwagemappinghistory");

                entity.Property(e => e.Historyid)
                    .HasColumnName("historyid")
                    .HasDefaultValueSql("nextval('wma_f_wage_workerwagemappinghistory_seq'::regclass)");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Recommendedwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("recommendedwage");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");

                entity.Property(e => e.Wageid).HasColumnName("wageid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerwageapprovalid).HasColumnName("workerwageapprovalid");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");
            });

            modelBuilder.Entity<WmaFWageWorkerwageprocess>(entity =>
            {
                entity.HasKey(e => e.Workerwageprocessid)
                    .HasName("pk_wma_f_wage_workerwageprocess");

                entity.ToTable("wma_f_wage_workerwageprocess");

                entity.Property(e => e.Workerwageprocessid)
                    .HasColumnName("workerwageprocessid")
                    .HasDefaultValueSql("nextval('wma_f_wage_workerwageprocess_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Processingmonth)
                    .HasPrecision(3)
                    .HasColumnName("processingmonth");

                entity.Property(e => e.Totalot)
                    .HasPrecision(10, 2)
                    .HasColumnName("totalot");

                entity.Property(e => e.Totalothours).HasColumnName("totalothours");

                entity.Property(e => e.Totalwage).HasColumnName("totalwage");

                entity.Property(e => e.Totalworkingdays).HasColumnName("totalworkingdays");

                entity.Property(e => e.Wage)
                    .HasPrecision(10, 2)
                    .HasColumnName("wage");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");

                entity.Property(e => e.Workingdays).HasColumnName("workingdays");
            });

            modelBuilder.Entity<WmaFWagehistory>(entity =>
            {
                entity.HasKey(e => e.Historyid)
                    .HasName("wma_f_wagehistory_pkey");

                entity.ToTable("wma_f_wagehistory");

                entity.Property(e => e.Historyid)
                    .HasColumnName("historyid")
                    .HasDefaultValueSql("nextval('wma_f_wagehistory_seq'::regclass)");

                entity.Property(e => e.ActiontypeVc)
                    .HasMaxLength(255)
                    .HasColumnName("actiontype_vc");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Expireon)
                    .HasPrecision(3)
                    .HasColumnName("expireon");

                entity.Property(e => e.Historycreatedby).HasColumnName("historycreatedby");

                entity.Property(e => e.Historycreatedon)
                    .HasPrecision(3)
                    .HasColumnName("historycreatedon")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Wageid).HasColumnName("wageid");
            });

            modelBuilder.Entity<WmaFWorkerattachment>(entity =>
            {
                entity.HasKey(e => e.WorkerattachmentId)
                    .HasName("pk_wma_f_attachments");

                entity.ToTable("wma_f_workerattachments");

                entity.Property(e => e.WorkerattachmentId)
                    .HasColumnName("workerattachment_id")
                    .HasDefaultValueSql("nextval('wma_f_workerattachments_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifedbyId).HasColumnName("modifedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkerattachmentcategoryVc)
                    .HasMaxLength(500)
                    .HasColumnName("workerattachmentcategory_vc");

                entity.Property(e => e.WorkerattachmentformatVc)
                    .HasMaxLength(500)
                    .HasColumnName("workerattachmentformat_vc");

                entity.Property(e => e.WorkerattachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("workerattachmentname_vc");

                entity.Property(e => e.WorkerattachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("workerattachmenturl_vc");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkerattachments)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("fk_wma_f_attachments_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerattendance>(entity =>
            {
                entity.HasKey(e => e.WorkerattendanceId)
                    .HasName("pk__wma_f_workerattendance");

                entity.ToTable("wma_f_workerattendance");

                entity.Property(e => e.WorkerattendanceId)
                    .HasColumnName("workerattendance_id")
                    .HasDefaultValueSql("nextval('wma_f_workerattendance_seq'::regclass)");

                entity.Property(e => e.AttendanceoutscanningonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendanceoutscanningon_dt");

                entity.Property(e => e.AttendanceoutsubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendanceoutsubmittedon_dt");

                entity.Property(e => e.AttendancescanningonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancescanningon_dt");

                entity.Property(e => e.AttendancesubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancesubmittedon_dt");

                entity.Property(e => e.AwsfacerecognitiontransactionId).HasColumnName("awsfacerecognitiontransaction_id");

                entity.Property(e => e.ChosendateDt)
                    .HasPrecision(3)
                    .HasColumnName("chosendate_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.Errormessage)
                    .HasMaxLength(500)
                    .HasColumnName("errormessage");

                entity.Property(e => e.InsertedineipNb).HasColumnName("insertedineip_nb");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.LatitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("latitude_vc");

                entity.Property(e => e.LocationVc)
                    .HasMaxLength(100)
                    .HasColumnName("location_vc");

                entity.Property(e => e.LongitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("longitude_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.OtflagBt)
                    .IsRequired()
                    .HasColumnType("bit(1)")
                    .HasColumnName("otflag_bt");

                entity.Property(e => e.OutawsfacerecognitiontransactionId).HasColumnName("outawsfacerecognitiontransaction_id");

                entity.Property(e => e.OutchosendateDt)
                    .HasPrecision(3)
                    .HasColumnName("outchosendate_dt");

                entity.Property(e => e.Outerrormessage)
                    .HasMaxLength(200)
                    .HasColumnName("outerrormessage");

                entity.Property(e => e.OutlatitudeVc)
                    .HasMaxLength(50)
                    .HasColumnName("outlatitude_vc");

                entity.Property(e => e.OutlocationVc)
                    .HasMaxLength(100)
                    .HasColumnName("outlocation_vc");

                entity.Property(e => e.OutlongitudeVc)
                    .HasMaxLength(50)
                    .HasColumnName("outlongitude_vc");

                entity.Property(e => e.OutsourceVc)
                    .HasMaxLength(20)
                    .HasColumnName("outsource_vc");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ResponsemsgofeipVc)
                    .HasMaxLength(50)
                    .HasColumnName("responsemsgofeip_vc");

                entity.Property(e => e.SectionVc)
                    .HasMaxLength(100)
                    .HasColumnName("section_vc");

                entity.Property(e => e.ShiftId).HasColumnName("shift_id");

                entity.Property(e => e.ShiftVc)
                    .HasMaxLength(50)
                    .HasColumnName("shift_vc");

                entity.Property(e => e.SourceVc)
                    .HasMaxLength(255)
                    .HasColumnName("source_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFWorkercovid19map>(entity =>
            {
                entity.HasKey(e => e.Workercovid19detailsid)
                    .HasName("pk_wma_f_workercovid19map");

                entity.ToTable("wma_f_workercovid19map");

                entity.Property(e => e.Workercovid19detailsid)
                    .HasColumnName("workercovid19detailsid")
                    .HasDefaultValueSql("nextval('wma_f_workercovid19map_seq'::regclass)");

                entity.Property(e => e.Covidstatusid).HasColumnName("covidstatusid");

                entity.Property(e => e.Covidstatusremarks)
                    .HasMaxLength(200)
                    .HasColumnName("covidstatusremarks");

                entity.Property(e => e.Covidstatusupdatedon)
                    .HasPrecision(3)
                    .HasColumnName("covidstatusupdatedon");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.FirstdoseDt)
                    .HasPrecision(3)
                    .HasColumnName("firstdose_dt");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Risklevelid).HasColumnName("risklevelid");

                entity.Property(e => e.Risklevelremarks)
                    .HasMaxLength(200)
                    .HasColumnName("risklevelremarks");

                entity.Property(e => e.SeconddoseDt)
                    .HasPrecision(3)
                    .HasColumnName("seconddose_dt");

                entity.Property(e => e.VaccinatedBt).HasColumnName("vaccinated_bt");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Covidstatus)
                    .WithMany(p => p.WmaFWorkercovid19maps)
                    .HasForeignKey(d => d.Covidstatusid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19map_wma_m_covidstatus");

                entity.HasOne(d => d.Risklevel)
                    .WithMany(p => p.WmaFWorkercovid19maps)
                    .HasForeignKey(d => d.Risklevelid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19map_wma_m_risklevel");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkercovid19maps)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19map_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkercovid19maphistory>(entity =>
            {
                entity.HasKey(e => e.Historyid)
                    .HasName("pk_wma_f_workercovid19history");

                entity.ToTable("wma_f_workercovid19maphistory");

                entity.Property(e => e.Historyid)
                    .HasColumnName("historyid")
                    .HasDefaultValueSql("nextval('wma_f_workercovid19maphistory_seq'::regclass)");

                entity.Property(e => e.Covidstatusid).HasColumnName("covidstatusid");

                entity.Property(e => e.Covidstatusremarks)
                    .HasMaxLength(200)
                    .HasColumnName("covidstatusremarks");

                entity.Property(e => e.Covidstatusupdatedon)
                    .HasPrecision(3)
                    .HasColumnName("covidstatusupdatedon");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Risklevelid).HasColumnName("risklevelid");

                entity.Property(e => e.Risklevelremarks)
                    .HasMaxLength(200)
                    .HasColumnName("risklevelremarks");

                entity.Property(e => e.Workercovid19detailsid).HasColumnName("workercovid19detailsid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Covidstatus)
                    .WithMany(p => p.WmaFWorkercovid19maphistories)
                    .HasForeignKey(d => d.Covidstatusid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19maphistory_wma_m_covidstatus");

                entity.HasOne(d => d.Risklevel)
                    .WithMany(p => p.WmaFWorkercovid19maphistories)
                    .HasForeignKey(d => d.Risklevelid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19maphistory_wma_m_risklevel");

                entity.HasOne(d => d.Workercovid19details)
                    .WithMany(p => p.WmaFWorkercovid19maphistories)
                    .HasForeignKey(d => d.Workercovid19detailsid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19maphistory_wma_f_workercovid19map");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkercovid19maphistories)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workercovid19maphistory_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerdatahistory>(entity =>
            {
                entity.HasKey(e => e.WorkerhistoryId)
                    .HasName("pk_wma_f_workerdatahistory");

                entity.ToTable("wma_f_workerdatahistory");

                entity.Property(e => e.WorkerhistoryId)
                    .HasColumnName("workerhistory_id")
                    .HasDefaultValueSql("nextval('wma_f_workerdatahistory_seq'::regclass)");

                entity.Property(e => e.AadhaarnoNb).HasColumnName("aadhaarno_nb");

                entity.Property(e => e.AgeNb).HasColumnName("age_nb");

                entity.Property(e => e.BirthplaceVc)
                    .HasMaxLength(250)
                    .HasColumnName("birthplace_vc");

                entity.Property(e => e.ChildernNb).HasColumnName("childern_nb");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.CstiidVc)
                    .HasMaxLength(500)
                    .HasColumnName("cstiid_vc");

                entity.Property(e => e.DobDt)
                    .HasPrecision(3)
                    .HasColumnName("dob_dt");

                entity.Property(e => e.Ehsinductionid)
                    .HasMaxLength(250)
                    .HasColumnName("ehsinductionid");

                entity.Property(e => e.EipId).HasColumnName("eip_id");

                entity.Property(e => e.EmergencycontactaddressVc).HasColumnName("emergencycontactaddress_vc");

                entity.Property(e => e.EmergencycontactnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("emergencycontactname_vc");

                entity.Property(e => e.EmergencycontactnumberNb).HasColumnName("emergencycontactnumber_nb");

                entity.Property(e => e.EmergencycontactrelationVc)
                    .HasMaxLength(250)
                    .HasColumnName("emergencycontactrelation_vc");

                entity.Property(e => e.EmploymenttypeId).HasColumnName("employmenttype_id");

                entity.Property(e => e.FatherSpouseVc)
                    .HasMaxLength(500)
                    .HasColumnName("father_spouse_vc");

                entity.Property(e => e.GenderVc)
                    .HasMaxLength(100)
                    .HasColumnName("gender_vc");

                entity.Property(e => e.GuiltyCrimeVc).HasColumnName("guilty_crime_vc");

                entity.Property(e => e.HastakencstiBt).HasColumnName("hastakencsti_bt");

                entity.Property(e => e.HitjoinapiBt).HasColumnName("hitjoinapi_bt");

                entity.Property(e => e.IdentificationmarkVc)
                    .HasMaxLength(500)
                    .HasColumnName("identificationmark_vc");

                entity.Property(e => e.IdproofnumberVc)
                    .HasMaxLength(250)
                    .HasColumnName("idproofnumber_vc");

                entity.Property(e => e.IdprooftypeVc)
                    .HasMaxLength(250)
                    .HasColumnName("idprooftype_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IsguiltyforcrimeBt).HasColumnName("isguiltyforcrime_bt");

                entity.Property(e => e.IsnapsBt).HasColumnName("isnaps_bt");

                entity.Property(e => e.LanguageId).HasColumnName("language_id");

                entity.Property(e => e.LanguagesknownVc)
                    .HasMaxLength(500)
                    .HasColumnName("languagesknown_vc");

                entity.Property(e => e.MaritalstatusId).HasColumnName("maritalstatus_id");

                entity.Property(e => e.MobilenoNb).HasColumnName("mobileno_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.NationalityId).HasColumnName("nationality_id");

                entity.Property(e => e.PermanentAddr1Vc)
                    .HasMaxLength(200)
                    .HasColumnName("permanent_addr1_vc");

                entity.Property(e => e.PermanentAddr2Vc)
                    .HasMaxLength(100)
                    .HasColumnName("permanent_addr2_vc");

                entity.Property(e => e.PermanentAddrVc).HasColumnName("permanent_addr_vc");

                entity.Property(e => e.PermanentCityVc)
                    .HasMaxLength(50)
                    .HasColumnName("permanent_city_vc");

                entity.Property(e => e.PermanentCountryNb).HasColumnName("permanent_country_nb");

                entity.Property(e => e.PermanentPincodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("permanent_pincode_vc");

                entity.Property(e => e.PermanentStateNb).HasColumnName("permanent_state_nb");

                entity.Property(e => e.PhotourlVc).HasColumnName("photourl_vc");

                entity.Property(e => e.PresentAddr1Vc)
                    .HasMaxLength(200)
                    .HasColumnName("present_addr1_vc");

                entity.Property(e => e.PresentAddr2Vc)
                    .HasMaxLength(100)
                    .HasColumnName("present_addr2_vc");

                entity.Property(e => e.PresentAddrVc).HasColumnName("present_addr_vc");

                entity.Property(e => e.PresentCityVc)
                    .HasMaxLength(50)
                    .HasColumnName("present_city_vc");

                entity.Property(e => e.PresentCountryNb).HasColumnName("present_country_nb");

                entity.Property(e => e.PresentPincodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("present_pincode_vc");

                entity.Property(e => e.PresentStateNb).HasColumnName("present_state_nb");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.QrcodeissuedDt)
                    .HasPrecision(3)
                    .HasColumnName("qrcodeissued_dt");

                entity.Property(e => e.QrcodeurlVc).HasColumnName("qrcodeurl_vc");

                entity.Property(e => e.SubcontractornameVc)
                    .HasMaxLength(500)
                    .HasColumnName("subcontractorname_vc");

                entity.Property(e => e.TelephonenoNb).HasColumnName("telephoneno_nb");

                entity.Property(e => e.Vendorcode)
                    .HasMaxLength(250)
                    .HasColumnName("vendorcode");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkernameVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("workername_vc");

                entity.Property(e => e.WorkerrecordstatusVc)
                    .HasMaxLength(250)
                    .HasColumnName("workerrecordstatus_vc");
            });

            modelBuilder.Entity<WmaFWorkerdatum>(entity =>
            {
                entity.HasKey(e => e.WorkerId)
                    .HasName("pk_wma_f_workerdata");

                entity.ToTable("wma_f_workerdata");

                entity.Property(e => e.WorkerId)
                    .HasColumnName("worker_id")
                    .HasDefaultValueSql("nextval('wma_f_workerdata_seq'::regclass)");

                entity.Property(e => e.AadhaarnoNb).HasColumnName("aadhaarno_nb");

                entity.Property(e => e.AgeNb).HasColumnName("age_nb");

                entity.Property(e => e.BirthplaceVc)
                    .HasMaxLength(250)
                    .HasColumnName("birthplace_vc");

                entity.Property(e => e.BloodgroupVc)
                    .HasMaxLength(5)
                    .HasColumnName("bloodgroup_vc");

                entity.Property(e => e.ChildernNb).HasColumnName("childern_nb");

                entity.Property(e => e.CountrycodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("countrycode_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.CstiidVc)
                    .HasMaxLength(500)
                    .HasColumnName("cstiid_vc");

                entity.Property(e => e.DobDt)
                    .HasPrecision(3)
                    .HasColumnName("dob_dt");

                entity.Property(e => e.Ehsinductionid)
                    .HasMaxLength(250)
                    .HasColumnName("ehsinductionid");

                entity.Property(e => e.EipId).HasColumnName("eip_id");

                entity.Property(e => e.EmergencycontactaddressVc).HasColumnName("emergencycontactaddress_vc");

                entity.Property(e => e.EmergencycontactnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("emergencycontactname_vc");

                entity.Property(e => e.EmergencycontactnumberNb).HasColumnName("emergencycontactnumber_nb");

                entity.Property(e => e.EmergencycontactrelationVc)
                    .HasMaxLength(250)
                    .HasColumnName("emergencycontactrelation_vc");

                entity.Property(e => e.EmergencycountrycodeVc)
                    .HasMaxLength(5)
                    .HasColumnName("emergencycountrycode_vc");

                entity.Property(e => e.EmploymenttypeId).HasColumnName("employmenttype_id");

                entity.Property(e => e.EntrypassvalidityNb).HasColumnName("entrypassvalidity_nb");

                entity.Property(e => e.FatherSpouseVc)
                    .HasMaxLength(500)
                    .HasColumnName("father_spouse_vc");

                entity.Property(e => e.GenderVc)
                    .HasMaxLength(100)
                    .HasColumnName("gender_vc");

                entity.Property(e => e.GuiltyCrimeVc).HasColumnName("guilty_crime_vc");

                entity.Property(e => e.HastakencstiBt)
                    .HasColumnName("hastakencsti_bt")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.HitjoinapiBt).HasColumnName("hitjoinapi_bt");

                entity.Property(e => e.IdentificationmarkVc)
                    .HasMaxLength(500)
                    .HasColumnName("identificationmark_vc");

                entity.Property(e => e.IdproofnumberVc)
                    .HasMaxLength(250)
                    .HasColumnName("idproofnumber_vc");

                entity.Property(e => e.IdprooftypeVc)
                    .HasMaxLength(250)
                    .HasColumnName("idprooftype_vc");

                entity.Property(e => e.IsRlsWorker).HasColumnName("is_rls_worker");

                entity.Property(e => e.IsactiveBt)
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IsguiltyforcrimeBt)
                    .HasColumnName("isguiltyforcrime_bt")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsnapsBt).HasColumnName("isnaps_bt");

                entity.Property(e => e.Isrlsacquaintancesinlnt).HasColumnName("isrlsacquaintancesinlnt");

                entity.Property(e => e.LanguageId).HasColumnName("language_id");

                entity.Property(e => e.LanguagesknownVc)
                    .HasMaxLength(500)
                    .HasColumnName("languagesknown_vc");

                entity.Property(e => e.MaritalstatusId).HasColumnName("maritalstatus_id");

                entity.Property(e => e.MobilenoNb).HasColumnName("mobileno_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.NameofrelativeVc)
                    .HasMaxLength(100)
                    .HasColumnName("nameofrelative_vc");

                entity.Property(e => e.NationalityId).HasColumnName("nationality_id");

                entity.Property(e => e.PermanentAddr1Vc)
                    .HasMaxLength(200)
                    .HasColumnName("permanent_addr1_vc");

                entity.Property(e => e.PermanentAddr2Vc)
                    .HasMaxLength(100)
                    .HasColumnName("permanent_addr2_vc");

                entity.Property(e => e.PermanentAddrVc).HasColumnName("permanent_addr_vc");

                entity.Property(e => e.PermanentCityVc)
                    .HasMaxLength(50)
                    .HasColumnName("permanent_city_vc");

                entity.Property(e => e.PermanentCountryNb).HasColumnName("permanent_country_nb");

                entity.Property(e => e.PermanentPincodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("permanent_pincode_vc");

                entity.Property(e => e.PermanentStateNb).HasColumnName("permanent_state_nb");

                entity.Property(e => e.PhotourlVc).HasColumnName("photourl_vc");

                entity.Property(e => e.PresentAddr1Vc)
                    .HasMaxLength(200)
                    .HasColumnName("present_addr1_vc");

                entity.Property(e => e.PresentAddr2Vc)
                    .HasMaxLength(100)
                    .HasColumnName("present_addr2_vc");

                entity.Property(e => e.PresentAddrVc).HasColumnName("present_addr_vc");

                entity.Property(e => e.PresentCityVc)
                    .HasMaxLength(50)
                    .HasColumnName("present_city_vc");

                entity.Property(e => e.PresentCountryNb).HasColumnName("present_country_nb");

                entity.Property(e => e.PresentPincodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("present_pincode_vc");

                entity.Property(e => e.PresentStateNb).HasColumnName("present_state_nb");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.QrcodeissuedDt)
                    .HasPrecision(3)
                    .HasColumnName("qrcodeissued_dt");

                entity.Property(e => e.QrcodeurlVc).HasColumnName("qrcodeurl_vc");

                entity.Property(e => e.QrexpiryonDt)
                    .HasPrecision(3)
                    .HasColumnName("qrexpiryon_dt");

                entity.Property(e => e.QrstatusVc)
                    .HasMaxLength(30)
                    .HasColumnName("qrstatus_vc");

                entity.Property(e => e.RelationtypeVc)
                    .HasMaxLength(100)
                    .HasColumnName("relationtype_vc");

                entity.Property(e => e.Rlsfromdate)
                    .HasPrecision(3)
                    .HasColumnName("rlsfromdate");

                entity.Property(e => e.Rlstodate)
                    .HasPrecision(3)
                    .HasColumnName("rlstodate");

                entity.Property(e => e.SubcontractornameVc)
                    .HasMaxLength(500)
                    .HasColumnName("subcontractorname_vc");

                entity.Property(e => e.TelephonenoNb).HasColumnName("telephoneno_nb");

                entity.Property(e => e.Vendorcode)
                    .HasMaxLength(250)
                    .HasColumnName("vendorcode");

                entity.Property(e => e.WorkeremailVc)
                    .HasMaxLength(255)
                    .HasColumnName("workeremail_vc");

                entity.Property(e => e.WorkernameVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("workername_vc");

                entity.Property(e => e.WorkerrecordstatusVc)
                    .HasMaxLength(250)
                    .HasColumnName("workerrecordstatus_vc");

                entity.HasOne(d => d.Employmenttype)
                    .WithMany(p => p.WmaFWorkerdata)
                    .HasForeignKey(d => d.EmploymenttypeId)
                    .HasConstraintName("fk_wma_f_workerdata_wma_m_employmenttype");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.WmaFWorkerdata)
                    .HasForeignKey(d => d.LanguageId)
                    .HasConstraintName("fk_wma_f_workerdata_wma_m_languages");

                entity.HasOne(d => d.Maritalstatus)
                    .WithMany(p => p.WmaFWorkerdata)
                    .HasForeignKey(d => d.MaritalstatusId)
                    .HasConstraintName("fk_wma_f_workerdata_wma_m_maritalstatus");

                entity.HasOne(d => d.Nationality)
                    .WithMany(p => p.WmaFWorkerdata)
                    .HasForeignKey(d => d.NationalityId)
                    .HasConstraintName("fk_wma_f_workerdata_wma_m_country");
            });

            modelBuilder.Entity<WmaFWorkerjunkattendance>(entity =>
            {
                entity.HasKey(e => e.WorkerjunkattendanceId)
                    .HasName("pk__wma_f_workerjunkattendance");

                entity.ToTable("wma_f_workerjunkattendance");

                entity.Property(e => e.WorkerjunkattendanceId)
                    .HasColumnName("workerjunkattendance_id")
                    .HasDefaultValueSql("nextval('wma_f_workerjunkattendance_seq'::regclass)");

                entity.Property(e => e.AttendanceoutscanningonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendanceoutscanningon_dt");

                entity.Property(e => e.AttendanceoutsubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendanceoutsubmittedon_dt");

                entity.Property(e => e.AttendancescanningonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancescanningon_dt");

                entity.Property(e => e.AttendancesubmittedonDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancesubmittedon_dt");

                entity.Property(e => e.AwsfacerecognitiontransactionId).HasColumnName("awsfacerecognitiontransaction_id");

                entity.Property(e => e.ChosendateDt)
                    .HasPrecision(3)
                    .HasColumnName("chosendate_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.Errormessage)
                    .HasMaxLength(500)
                    .HasColumnName("errormessage");

                entity.Property(e => e.InsertedineipNb).HasColumnName("insertedineip_nb");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.LatitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("latitude_vc");

                entity.Property(e => e.LocationVc)
                    .HasMaxLength(100)
                    .HasColumnName("location_vc");

                entity.Property(e => e.LongitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("longitude_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.OtflagBt)
                    .IsRequired()
                    .HasColumnType("bit(1)")
                    .HasColumnName("otflag_bt");

                entity.Property(e => e.OutawsfacerecognitiontransactionId).HasColumnName("outawsfacerecognitiontransaction_id");

                entity.Property(e => e.OutchosendateDt)
                    .HasPrecision(3)
                    .HasColumnName("outchosendate_dt");

                entity.Property(e => e.Outerrormessage)
                    .HasMaxLength(200)
                    .HasColumnName("outerrormessage");

                entity.Property(e => e.OutlatitudeVc)
                    .HasMaxLength(50)
                    .HasColumnName("outlatitude_vc");

                entity.Property(e => e.OutlocationVc)
                    .HasMaxLength(100)
                    .HasColumnName("outlocation_vc");

                entity.Property(e => e.OutlongitudeVc)
                    .HasMaxLength(50)
                    .HasColumnName("outlongitude_vc");

                entity.Property(e => e.OutsourceVc)
                    .HasMaxLength(20)
                    .HasColumnName("outsource_vc");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ResponsemsgofeipVc)
                    .HasMaxLength(50)
                    .HasColumnName("responsemsgofeip_vc");

                entity.Property(e => e.SectionVc)
                    .HasMaxLength(100)
                    .HasColumnName("section_vc");

                entity.Property(e => e.ShiftId).HasColumnName("shift_id");

                entity.Property(e => e.ShiftVc)
                    .HasMaxLength(50)
                    .HasColumnName("shift_vc");

                entity.Property(e => e.SourceVc)
                    .HasMaxLength(255)
                    .HasColumnName("source_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFWorkerleaveattachment>(entity =>
            {
                entity.HasKey(e => e.Attachmentid)
                    .HasName("pk_wma_f_workerleaveattachments");

                entity.ToTable("wma_f_workerleaveattachments");

                entity.Property(e => e.Attachmentid)
                    .HasColumnName("attachmentid")
                    .HasDefaultValueSql("nextval('wma_f_workerleaveattachments_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Workerattachmentformat)
                    .IsRequired()
                    .HasMaxLength(350)
                    .HasColumnName("workerattachmentformat");

                entity.Property(e => e.Workerattachmentname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("workerattachmentname");

                entity.Property(e => e.Workerattachmenturl)
                    .IsRequired()
                    .HasMaxLength(300)
                    .HasColumnName("workerattachmenturl");
            });

            modelBuilder.Entity<WmaFWorkerleavebalance>(entity =>
            {
                entity.ToTable("wma_f_workerleavebalance");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_workerleavebalance_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Dateofjoining)
                    .HasPrecision(3)
                    .HasColumnName("dateofjoining");

                entity.Property(e => e.Lastupdatedon)
                    .HasPrecision(3)
                    .HasColumnName("lastupdatedon");

                entity.Property(e => e.Leavebalance).HasColumnName("leavebalance");

                entity.Property(e => e.Leavetypeid).HasColumnName("leavetypeid");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Leavetype)
                    .WithMany(p => p.WmaFWorkerleavebalances)
                    .HasForeignKey(d => d.Leavetypeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavebalance_wma_m_leavetype");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWorkerleavebalances)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavebalance_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerleavebalancehistory>(entity =>
            {
                entity.HasKey(e => e.Historyid)
                    .HasName("pk_wma_f_workerleavebalancehistory");

                entity.ToTable("wma_f_workerleavebalancehistory");

                entity.Property(e => e.Historyid)
                    .HasColumnName("historyid")
                    .HasDefaultValueSql("nextval('wma_f_workerleavebalancehistory_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Dateofjoining)
                    .HasPrecision(3)
                    .HasColumnName("dateofjoining");

                entity.Property(e => e.Leavebalance).HasColumnName("leavebalance");

                entity.Property(e => e.Leavetypeid).HasColumnName("leavetypeid");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Releasedon)
                    .HasPrecision(3)
                    .HasColumnName("releasedon");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Leavetype)
                    .WithMany(p => p.WmaFWorkerleavebalancehistories)
                    .HasForeignKey(d => d.Leavetypeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavebalancehistory_wma_m_leavetype");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWorkerleavebalancehistories)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavebalancehistory_wma_m_projects");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkerleavebalancehistories)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavebalancehistory_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerleavedetail>(entity =>
            {
                entity.ToTable("wma_f_workerleavedetail");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_f_workerleavedetail_seq'::regclass)");

                entity.Property(e => e.Attachmentid).HasColumnName("attachmentid");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Fromdate)
                    .HasPrecision(3)
                    .HasColumnName("fromdate");

                entity.Property(e => e.Leavetypeid).HasColumnName("leavetypeid");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Todate)
                    .HasPrecision(3)
                    .HasColumnName("todate");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Leavetype)
                    .WithMany(p => p.WmaFWorkerleavedetails)
                    .HasForeignKey(d => d.Leavetypeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavedetail_wma_m_leavetype");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWorkerleavedetails)
                    .HasForeignKey(d => d.Projectid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavedetail_wma_m_projects");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkerleavedetails)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerleavedetail_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerobservationdetail>(entity =>
            {
                entity.HasKey(e => e.WorkerobservationdetailId)
                    .HasName("pk__wma_f_workerobservationdetails__a498aa44ce1cd541");

                entity.ToTable("wma_f_workerobservationdetails");

                entity.Property(e => e.WorkerobservationdetailId)
                    .HasColumnName("workerobservationdetail_id")
                    .HasDefaultValueSql("nextval('wma_f_workerobservationdetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ObservationcategoryId).HasColumnName("observationcategory_id");

                entity.Property(e => e.ObservationdescriptionVc).HasColumnName("observationdescription_vc");

                entity.Property(e => e.ObservationlocationVc)
                    .HasMaxLength(100)
                    .HasColumnName("observationlocation_vc");

                entity.Property(e => e.ObservationraisedbyVc)
                    .HasMaxLength(100)
                    .HasColumnName("observationraisedby_vc");

                entity.Property(e => e.ObservationraisedonDt)
                    .HasPrecision(3)
                    .HasColumnName("observationraisedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ObservationsubcategoryId).HasColumnName("observationsubcategory_id");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Observationcategory)
                    .WithMany(p => p.WmaFWorkerobservationdetails)
                    .HasForeignKey(d => d.ObservationcategoryId)
                    .HasConstraintName("wma_f_workerobservationdetails_observationcategory_id_fkey");

                entity.HasOne(d => d.Observationsubcategory)
                    .WithMany(p => p.WmaFWorkerobservationdetails)
                    .HasForeignKey(d => d.ObservationsubcategoryId)
                    .HasConstraintName("wma_f_workerobservationdetails_observationsubcategory_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaFWorkerobservationdetails)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("fk_wma_f_workerobservationdetails_wma_m_projects");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkerobservationdetails)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("wma_f_workerobservationdetails_worker_id_fkey");
            });

            modelBuilder.Entity<WmaFWorkerranking>(entity =>
            {
                entity.HasKey(e => e.WorkerrankingId)
                    .HasName("wma_f_workerranking_pkey");

                entity.ToTable("wma_f_workerranking");

                entity.Property(e => e.WorkerrankingId)
                    .HasColumnName("workerranking_id")
                    .HasDefaultValueSql("nextval('wma_f_workerranking_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RankId).HasColumnName("rank_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaFWorkerrankinghistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wma_f_workerrankinghistory");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RankId).HasColumnName("rank_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkerrankingId).HasColumnName("workerranking_id");

                entity.Property(e => e.WorkerrankinghistoryId)
                    .HasColumnName("workerrankinghistory_id")
                    .HasDefaultValueSql("nextval('wma_f_workerrankinghistory_seq'::regclass)");
            });

            modelBuilder.Entity<WmaFWorkerselfdeclarationmap>(entity =>
            {
                entity.HasKey(e => e.Workerselfdeclarationid)
                    .HasName("pk_wma_f_workerselfdeclarationmap");

                entity.ToTable("wma_f_workerselfdeclarationmap");

                entity.Property(e => e.Workerselfdeclarationid)
                    .HasColumnName("workerselfdeclarationid")
                    .HasDefaultValueSql("nextval('wma_f_workerselfdeclarationmap_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Onsetdate)
                    .HasPrecision(3)
                    .HasColumnName("onsetdate");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(200)
                    .HasColumnName("remarks");

                entity.Property(e => e.Sdqid).HasColumnName("sdqid");

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("value");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Sdq)
                    .WithMany(p => p.WmaFWorkerselfdeclarationmaps)
                    .HasForeignKey(d => d.Sdqid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerselfdeclarationmap_wma_m_selfdeclarationquestion");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkerselfdeclarationmaps)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workerselfdeclarationmap_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkerselfdeclarationmaphistory>(entity =>
            {
                entity.HasKey(e => e.Historyid)
                    .HasName("pk_wma_f_workerselfdeclarationmaphistory");

                entity.ToTable("wma_f_workerselfdeclarationmaphistory");

                entity.Property(e => e.Historyid)
                    .HasColumnName("historyid")
                    .HasDefaultValueSql("nextval('wma_f_workerselfdeclarationmaphistory_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Onsetdate)
                    .HasPrecision(3)
                    .HasColumnName("onsetdate");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(200)
                    .HasColumnName("remarks");

                entity.Property(e => e.Sdqid).HasColumnName("sdqid");

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("value");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.Property(e => e.Workerselfdeclarationid).HasColumnName("workerselfdeclarationid");
            });

            modelBuilder.Entity<WmaFWorkertravellinghistory>(entity =>
            {
                entity.HasKey(e => e.Workertravelhistoryid)
                    .HasName("pk_wma_f_workertravellinghistory");

                entity.ToTable("wma_f_workertravellinghistory");

                entity.Property(e => e.Workertravelhistoryid)
                    .HasColumnName("workertravelhistoryid")
                    .HasDefaultValueSql("nextval('wma_f_workertravellinghistory_seq'::regclass)");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Date)
                    .HasPrecision(3)
                    .HasColumnName("date");

                entity.Property(e => e.Districtid).HasColumnName("districtid");

                entity.Property(e => e.Geospatialstatusid).HasColumnName("geospatialstatusid");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Stateid).HasColumnName("stateid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Geospatialstatus)
                    .WithMany(p => p.WmaFWorkertravellinghistories)
                    .HasForeignKey(d => d.Geospatialstatusid)
                    .HasConstraintName("fk_wma_f_workertravellinghistory_wma_m_geospatialstatus");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.WmaFWorkertravellinghistories)
                    .HasForeignKey(d => d.Stateid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workertravellinghistory_wma_m_state");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkertravellinghistories)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workertravellinghistory_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkervital>(entity =>
            {
                entity.HasKey(e => e.WorkervitalsId)
                    .HasName("pk_wma_f_workervitals");

                entity.ToTable("wma_f_workervitals");

                entity.Property(e => e.WorkervitalsId)
                    .HasColumnName("workervitals_id")
                    .HasDefaultValueSql("nextval('wma_f_workervitals_seq'::regclass)");

                entity.Property(e => e.BmiVc)
                    .HasMaxLength(250)
                    .HasColumnName("bmi_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DateVc)
                    .HasMaxLength(250)
                    .HasColumnName("date_vc");

                entity.Property(e => e.DiastolicVc)
                    .HasMaxLength(250)
                    .HasColumnName("diastolic_vc");

                entity.Property(e => e.HeightVc)
                    .HasMaxLength(250)
                    .HasColumnName("height_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.PulseVc)
                    .HasMaxLength(250)
                    .HasColumnName("pulse_vc");

                entity.Property(e => e.RrVc)
                    .HasMaxLength(250)
                    .HasColumnName("rr_vc");

                entity.Property(e => e.SkintempVc)
                    .HasMaxLength(250)
                    .HasColumnName("skintemp_vc");

                entity.Property(e => e.Spo2Vc)
                    .HasMaxLength(250)
                    .HasColumnName("spo2_vc");

                entity.Property(e => e.SugarVc)
                    .HasMaxLength(250)
                    .HasColumnName("sugar_vc");

                entity.Property(e => e.SystolicVc)
                    .HasMaxLength(250)
                    .HasColumnName("systolic_vc");

                entity.Property(e => e.TimeVc)
                    .HasMaxLength(250)
                    .HasColumnName("time_vc");

                entity.Property(e => e.WeightVc)
                    .HasMaxLength(250)
                    .HasColumnName("weight_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkervitals)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workervitals_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkervitalshistroy>(entity =>
            {
                entity.HasKey(e => e.WorkervitalshistoryId)
                    .HasName("pk_wma_f_workervitalshistroy");

                entity.ToTable("wma_f_workervitalshistroy");

                entity.Property(e => e.WorkervitalshistoryId)
                    .HasColumnName("workervitalshistory_id")
                    .HasDefaultValueSql("nextval('wma_f_workervitalshistroy_seq'::regclass)");

                entity.Property(e => e.BmiVc)
                    .HasMaxLength(250)
                    .HasColumnName("bmi_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DateVc)
                    .HasMaxLength(250)
                    .HasColumnName("date_vc");

                entity.Property(e => e.DiastolicVc)
                    .HasMaxLength(250)
                    .HasColumnName("diastolic_vc");

                entity.Property(e => e.HeightVc)
                    .HasMaxLength(250)
                    .HasColumnName("height_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.PulseVc)
                    .HasMaxLength(250)
                    .HasColumnName("pulse_vc");

                entity.Property(e => e.RrVc)
                    .HasMaxLength(250)
                    .HasColumnName("rr_vc");

                entity.Property(e => e.SkintempVc)
                    .HasMaxLength(250)
                    .HasColumnName("skintemp_vc");

                entity.Property(e => e.Spo2Vc)
                    .HasMaxLength(250)
                    .HasColumnName("spo2_vc");

                entity.Property(e => e.SugarVc)
                    .HasMaxLength(250)
                    .HasColumnName("sugar_vc");

                entity.Property(e => e.SystolicVc)
                    .HasMaxLength(250)
                    .HasColumnName("systolic_vc");

                entity.Property(e => e.TimeVc)
                    .HasMaxLength(250)
                    .HasColumnName("time_vc");

                entity.Property(e => e.WeightVc)
                    .HasMaxLength(250)
                    .HasColumnName("weight_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkervitalsId).HasColumnName("workervitals_id");
            });

            modelBuilder.Entity<WmaFWorkerzoneattendance>(entity =>
            {
                entity.HasKey(e => e.WorkerzoneattendanceId)
                    .HasName("wma_f_workerzoneattendance_pkey");

                entity.ToTable("wma_f_workerzoneattendance");

                entity.Property(e => e.WorkerzoneattendanceId)
                    .HasColumnName("workerzoneattendance_id")
                    .UseIdentityAlwaysColumn();

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.InattendanceDt)
                    .HasPrecision(3)
                    .HasColumnName("inattendance_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.OutattendanceDt)
                    .HasPrecision(3)
                    .HasColumnName("outattendance_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");
            });

            modelBuilder.Entity<WmaFWorkflow>(entity =>
            {
                entity.HasKey(e => e.WorkflowId)
                    .HasName("pk_wma_f_workflow");

                entity.ToTable("wma_f_workflow");

                entity.Property(e => e.WorkflowId)
                    .HasColumnName("workflow_id")
                    .HasDefaultValueSql("nextval('wma_f_workflow_seq'::regclass)");

                entity.Property(e => e.ApprovedondateDt)
                    .HasPrecision(3)
                    .HasColumnName("approvedondate_dt");

                entity.Property(e => e.ArevitalsfilledBt).HasColumnName("arevitalsfilled_bt");

                entity.Property(e => e.AssignedbyId).HasColumnName("assignedby_id");

                entity.Property(e => e.AssignedbyroleId).HasColumnName("assignedbyrole_id");

                entity.Property(e => e.AssignedondateDt)
                    .HasPrecision(3)
                    .HasColumnName("assignedondate_dt");

                entity.Property(e => e.AssignedtoId).HasColumnName("assignedto_id");

                entity.Property(e => e.AssignedtoroleId).HasColumnName("assignedtorole_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.CurrentrecordlevelNb).HasColumnName("currentrecordlevel_nb");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IscurrentlevelchecklistfilledNb)
                    .HasColumnName("iscurrentlevelchecklistfilled_nb")
                    .HasDefaultValueSql("'-1'::integer");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkflowstatusVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("workflowstatus_vc");

                entity.HasOne(d => d.Assignedby)
                    .WithMany(p => p.WmaFWorkflowAssignedbies)
                    .HasForeignKey(d => d.AssignedbyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflow_wma_m_user");

                entity.HasOne(d => d.Assignedbyrole)
                    .WithMany(p => p.WmaFWorkflowAssignedbyroles)
                    .HasForeignKey(d => d.AssignedbyroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflow_wma_m_roles");

                entity.HasOne(d => d.Assignedto)
                    .WithMany(p => p.WmaFWorkflowAssignedtos)
                    .HasForeignKey(d => d.AssignedtoId)
                    .HasConstraintName("fk_wma_f_workflow_wma_m_user1");

                entity.HasOne(d => d.Assignedtorole)
                    .WithMany(p => p.WmaFWorkflowAssignedtoroles)
                    .HasForeignKey(d => d.AssignedtoroleId)
                    .HasConstraintName("fk_wma_f_workflow_wma_m_roles1");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkflows)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflow_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaFWorkflowhistory>(entity =>
            {
                entity.HasKey(e => e.WorkflowhistoryId)
                    .HasName("pk_wma_f_workflowhistory");

                entity.ToTable("wma_f_workflowhistory");

                entity.Property(e => e.WorkflowhistoryId)
                    .HasColumnName("workflowhistory_id")
                    .HasDefaultValueSql("nextval('wma_f_workflowhistory_seq'::regclass)");

                entity.Property(e => e.ApprovedondateDt)
                    .HasPrecision(3)
                    .HasColumnName("approvedondate_dt");

                entity.Property(e => e.ArevitalsfilledBt).HasColumnName("arevitalsfilled_bt");

                entity.Property(e => e.AssignedbyId).HasColumnName("assignedby_id");

                entity.Property(e => e.AssignedbyroleId).HasColumnName("assignedbyrole_id");

                entity.Property(e => e.AssignedondateDt)
                    .HasPrecision(3)
                    .HasColumnName("assignedondate_dt");

                entity.Property(e => e.AssignedtoId).HasColumnName("assignedto_id");

                entity.Property(e => e.AssignedtoroleId).HasColumnName("assignedtorole_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.CurrentrecordlevelNb).HasColumnName("currentrecordlevel_nb");

                entity.Property(e => e.IsactiveBt)
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IscurrentlevelchecklistfilledNb)
                    .HasColumnName("iscurrentlevelchecklistfilled_nb")
                    .HasDefaultValueSql("'-1'::integer");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(500)
                    .HasColumnName("remarks_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkflowId).HasColumnName("workflow_id");

                entity.Property(e => e.WorkflowstatusVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("workflowstatus_vc");

                entity.HasOne(d => d.Assignedby)
                    .WithMany(p => p.WmaFWorkflowhistoryAssignedbies)
                    .HasForeignKey(d => d.AssignedbyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_m_user");

                entity.HasOne(d => d.Assignedbyrole)
                    .WithMany(p => p.WmaFWorkflowhistoryAssignedbyroles)
                    .HasForeignKey(d => d.AssignedbyroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_m_roles");

                entity.HasOne(d => d.Assignedto)
                    .WithMany(p => p.WmaFWorkflowhistoryAssignedtos)
                    .HasForeignKey(d => d.AssignedtoId)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_m_user1");

                entity.HasOne(d => d.Assignedtorole)
                    .WithMany(p => p.WmaFWorkflowhistoryAssignedtoroles)
                    .HasForeignKey(d => d.AssignedtoroleId)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_m_roles1");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaFWorkflowhistories)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_f_workerdata");

                entity.HasOne(d => d.Workflow)
                    .WithMany(p => p.WmaFWorkflowhistories)
                    .HasForeignKey(d => d.WorkflowId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_f_workflowhistory_wma_f_workflow");
            });

            modelBuilder.Entity<WmaLActivityprojectrolemapping>(entity =>
            {
                entity.HasKey(e => e.ActivitymappingId)
                    .HasName("wma_l_activityprojectrolemapping_pkey");

                entity.ToTable("wma_l_activityprojectrolemapping");

                entity.Property(e => e.ActivitymappingId)
                    .HasColumnName("activitymapping_id")
                    .HasDefaultValueSql("nextval('wma_l_activityprojectrolemapping_seq'::regclass)");

                entity.Property(e => e.ActivityId).HasColumnName("activity_id");

                entity.Property(e => e.ActivitydateDt)
                    .HasPrecision(3)
                    .HasColumnName("activitydate_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Activity)
                    .WithMany(p => p.WmaLActivityprojectrolemappings)
                    .HasForeignKey(d => d.ActivityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_wma_l_activityprojectrolemapping_wma_m_activity");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLActivityprojectrolemappings)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_wma_l_activityprojectrolemapping_wma_m_user");
            });

            modelBuilder.Entity<WmaLAdminuserprojectlevelaccess>(entity =>
            {
                entity.HasKey(e => e.AdminuserprojectlevelaccessId)
                    .HasName("wma_l_adminuserprojectlevelaccess_pkey");

                entity.ToTable("wma_l_adminuserprojectlevelaccess");

                entity.Property(e => e.AdminuserprojectlevelaccessId)
                    .HasColumnName("adminuserprojectlevelaccess_id")
                    .HasDefaultValueSql("nextval('wma_l_adminuserprojectlevelaccess_seq'::regclass)");

                entity.Property(e => e.CreatdonDt)
                    .HasPrecision(3)
                    .HasColumnName("creatdon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLAdminuserprojectlevelaccesses)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("wma_l_adminuserprojectlevelaccess_role_id_fkey");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLAdminuserprojectlevelaccesses)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("wma_l_adminuserprojectlevelaccess_user_id_fkey");
            });

            modelBuilder.Entity<WmaLAdminuserprojectlevelaccesshistory>(entity =>
            {
                entity.HasKey(e => e.AdminuserprojectlevelaccesshistoryId)
                    .HasName("wma_l_adminuserprojectlevelaccesshistory_pkey");

                entity.ToTable("wma_l_adminuserprojectlevelaccesshistory");

                entity.Property(e => e.AdminuserprojectlevelaccesshistoryId)
                    .HasColumnName("adminuserprojectlevelaccesshistory_id")
                    .HasDefaultValueSql("nextval('wma_l_adminuserprojectlevelaccesshistory_seq'::regclass)");

                entity.Property(e => e.AdminuserprojectlevelaccessId).HasColumnName("adminuserprojectlevelaccess_id");

                entity.Property(e => e.CreatdonDt)
                    .HasPrecision(3)
                    .HasColumnName("creatdon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Adminuserprojectlevelaccess)
                    .WithMany(p => p.WmaLAdminuserprojectlevelaccesshistories)
                    .HasForeignKey(d => d.AdminuserprojectlevelaccessId)
                    .HasConstraintName("wma_l_adminuserprojectlevelac_adminuserprojectlevelaccess__fkey");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLAdminuserprojectlevelaccesshistories)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("wma_l_adminuserprojectlevelaccesshistory_role_id_fkey");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLAdminuserprojectlevelaccesshistories)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("wma_l_adminuserprojectlevelaccesshistory_user_id_fkey");
            });

            modelBuilder.Entity<WmaLCertificationdetail>(entity =>
            {
                entity.HasKey(e => e.CertificationdetailId)
                    .HasName("pk_wma_l_certificationdetails");

                entity.ToTable("wma_l_certificationdetails");

                entity.Property(e => e.CertificationdetailId)
                    .HasColumnName("certificationdetail_id")
                    .HasDefaultValueSql("nextval('wma_l_certificationdetails_seq'::regclass)");

                entity.Property(e => e.AttachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("attachmentname_vc");

                entity.Property(e => e.AttachmenttypeVc)
                    .HasMaxLength(250)
                    .HasColumnName("attachmenttype_vc");

                entity.Property(e => e.AttachmenturlVc)
                    .HasMaxLength(250)
                    .HasColumnName("attachmenturl_vc");

                entity.Property(e => e.CertificatetypeId).HasColumnName("certificatetype_id");

                entity.Property(e => e.CertificationdatetimeDt)
                    .HasPrecision(3)
                    .HasColumnName("certificationdatetime_dt");

                entity.Property(e => e.CertificationnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("certificationname_vc");

                entity.Property(e => e.CertificationvalidityDt).HasColumnName("certificationvalidity_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.DocumentvalidityDt)
                    .HasPrecision(3)
                    .HasColumnName("documentvalidity_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Certificatetype)
                    .WithMany(p => p.WmaLCertificationdetails)
                    .HasForeignKey(d => d.CertificatetypeId)
                    .HasConstraintName("fk_wma_l_certificationdetails_wma_m_certificatetype");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLCertificationdetails)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_certificationdetails_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLChecklistfortestvalidity>(entity =>
            {
                entity.HasKey(e => e.TestvalidityId)
                    .HasName("wma_l_checklistfortestvalidity_pkey");

                entity.ToTable("wma_l_checklistfortestvalidity");

                entity.Property(e => e.TestvalidityId)
                    .HasColumnName("testvalidity_id")
                    .HasDefaultValueSql("nextval('wma_l_checklistfortestvalidity_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.TestattendedonDt)
                    .HasPrecision(3)
                    .HasColumnName("testattendedon_dt");

                entity.Property(e => e.ValiditymonthsId).HasColumnName("validitymonths_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLChecklistfortestvalidities)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("wma_l_checklistfortestvalidity_checklist_id_fkey");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLChecklistfortestvalidities)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("wma_l_checklistfortestvalidity_worker_id_fkey");
            });

            modelBuilder.Entity<WmaLChecklistfortestvalidityhistory>(entity =>
            {
                entity.HasKey(e => e.TestvalidityhistoryId)
                    .HasName("wma_l_checklistfortestvalidityhistory_pkey");

                entity.ToTable("wma_l_checklistfortestvalidityhistory");

                entity.Property(e => e.TestvalidityhistoryId)
                    .HasColumnName("testvalidityhistory_id")
                    .HasDefaultValueSql("nextval('wma_l_checklistfortestvalidityhistory_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.TestattendedonDt)
                    .HasPrecision(3)
                    .HasColumnName("testattendedon_dt");

                entity.Property(e => e.TestvalidityId).HasColumnName("testvalidity_id");

                entity.Property(e => e.ValiditymonthsId).HasColumnName("validitymonths_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaLChecklistquesresponsetypemap>(entity =>
            {
                entity.HasKey(e => e.QuesresponsetypemapId)
                    .HasName("pk_wma_l_checklistquesresponsetypemap");

                entity.ToTable("wma_l_checklistquesresponsetypemap");

                entity.Property(e => e.QuesresponsetypemapId)
                    .HasColumnName("quesresponsetypemap_id")
                    .HasDefaultValueSql("nextval('wma_l_checklistquesresponsetypemap_seq'::regclass)");

                entity.Property(e => e.AllowableresponseVc)
                    .IsRequired()
                    .HasColumnName("allowableresponse_vc");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestionsmapId).HasColumnName("checklistquestionsmap_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ResponsetypeId).HasColumnName("responsetype_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLChecklistquesresponsetypemaps)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_checklistquesresponsetypemap_wma_m_checklist");

                entity.HasOne(d => d.Checklistquestionsmap)
                    .WithMany(p => p.WmaLChecklistquesresponsetypemaps)
                    .HasForeignKey(d => d.ChecklistquestionsmapId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_checklistquesresponsetypemap_wma_l_checklistquestionsm");

                entity.HasOne(d => d.Responsetype)
                    .WithMany(p => p.WmaLChecklistquesresponsetypemaps)
                    .HasForeignKey(d => d.ResponsetypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_checklistquesresponsetypemap_wma_m_responsetype");
            });

            modelBuilder.Entity<WmaLChecklistquestiongroupmap>(entity =>
            {
                entity.HasKey(e => e.ChecklistquestiongroupId)
                    .HasName("pk_wma_l_checklistquestiongrpmap");

                entity.ToTable("wma_l_checklistquestiongroupmap");

                entity.Property(e => e.ChecklistquestiongroupId)
                    .HasColumnName("checklistquestiongroup_id")
                    .HasDefaultValueSql("nextval('wma_l_checklistquestiongroupmap_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.ChecklistquestiongroupdescVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("checklistquestiongroupdesc_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IsdefaultBt)
                    .IsRequired()
                    .HasColumnName("isdefault_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.ValidityperiodNb).HasColumnName("validityperiod_nb");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLChecklistquestiongroupmaps)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_checklistquestiongrpmap_wma_m_checklist");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLChecklistquestiongroupmaps)
                    .HasForeignKey(d => d.TradeId)
                    .HasConstraintName("fk_wma_l_checklistquestiongrpmap_wma_m_trades");
            });

            modelBuilder.Entity<WmaLChecklistquestionsmap>(entity =>
            {
                entity.HasKey(e => e.ChecklistquestionsmapId)
                    .HasName("pk_wma_l_checklistquestionsmap");

                entity.ToTable("wma_l_checklistquestionsmap");

                entity.Property(e => e.ChecklistquestionsmapId)
                    .HasColumnName("checklistquestionsmap_id")
                    .HasDefaultValueSql("nextval('wma_l_checklistquestionsmap_seq'::regclass)");

                entity.Property(e => e.ChecklistquestiongrpId).HasColumnName("checklistquestiongrp_id");

                entity.Property(e => e.ChecklistquestionsdescVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("checklistquestionsdesc_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.HasOne(d => d.Checklistquestiongrp)
                    .WithMany(p => p.WmaLChecklistquestionsmaps)
                    .HasForeignKey(d => d.ChecklistquestiongrpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_checklistquestionsmap_wma_l_checklistquestiongrpmap");
            });

            modelBuilder.Entity<WmaLChecklisttraderoleapprovalmap>(entity =>
            {
                entity.HasKey(e => e.TraderoleapprovalmapId)
                    .HasName("pk_wma_l_checklisttraderoleapprovalmap");

                entity.ToTable("wma_l_checklisttraderoleapprovalmap");

                entity.Property(e => e.TraderoleapprovalmapId)
                    .HasColumnName("traderoleapprovalmap_id")
                    .HasDefaultValueSql("nextval('wma_l_checklisttraderoleapprovalmap_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLChecklisttraderoleapprovalmaps)
                    .HasForeignKey(d => d.TradeId)
                    .HasConstraintName("fk_wma_l_checklisttraderoleapprovalmap_wma_m_trades");
            });

            modelBuilder.Entity<WmaLEducationdetail>(entity =>
            {
                entity.HasKey(e => e.EducationdetailId)
                    .HasName("pk_wma_l_educationdetails");

                entity.ToTable("wma_l_educationdetails");

                entity.Property(e => e.EducationdetailId)
                    .HasColumnName("educationdetail_id")
                    .HasDefaultValueSql("nextval('wma_l_educationdetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.EducationboardVc)
                    .HasMaxLength(500)
                    .HasColumnName("educationboard_vc");

                entity.Property(e => e.ExamId).HasColumnName("exam_id");

                entity.Property(e => e.InstitutionnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("institutionname_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.PassingyearNb).HasColumnName("passingyear_nb");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Exam)
                    .WithMany(p => p.WmaLEducationdetails)
                    .HasForeignKey(d => d.ExamId)
                    .HasConstraintName("fk_wma_l_educationdetails_wma_m_exams");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLEducationdetails)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_educationdetails_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLEmailutilizationprojectrolemapping>(entity =>
            {
                entity.HasKey(e => e.EmailutilizationprojectrolemappingId)
                    .HasName("wma_l_emailutilizationprojectrolemapping_pkey");

                entity.ToTable("wma_l_emailutilizationprojectrolemapping");

                entity.Property(e => e.EmailutilizationprojectrolemappingId)
                    .HasColumnName("emailutilizationprojectrolemapping_id")
                    .HasDefaultValueSql("nextval('wma_l_emailutilizationprojectrolemapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.EmailutilizationId).HasColumnName("emailutilization_id");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.OtheremailidsVc).HasColumnName("otheremailids_vc");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RoleId)
                    .HasMaxLength(100)
                    .HasColumnName("role_id");

                entity.HasOne(d => d.Emailutilization)
                    .WithMany(p => p.WmaLEmailutilizationprojectrolemappings)
                    .HasForeignKey(d => d.EmailutilizationId)
                    .HasConstraintName("fk_wma_l_wma_l_emailutilizationprojectrolemapping_wma_m_emailut");
            });

            modelBuilder.Entity<WmaLExperience>(entity =>
            {
                entity.HasKey(e => e.ExperienceId)
                    .HasName("pk_wma_l_experience");

                entity.ToTable("wma_l_experience");

                entity.Property(e => e.ExperienceId)
                    .HasColumnName("experience_id")
                    .HasDefaultValueSql("nextval('wma_l_experience_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ExperiencetypeVc)
                    .HasMaxLength(10)
                    .HasColumnName("experiencetype_vc");

                entity.Property(e => e.GeneralbehaviourVc)
                    .HasMaxLength(200)
                    .HasColumnName("generalbehaviour_vc");

                entity.Property(e => e.Joinremarks)
                    .HasMaxLength(100)
                    .HasColumnName("joinremarks");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.OrgnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("orgname_vc");

                entity.Property(e => e.OrgtypeVc)
                    .HasMaxLength(500)
                    .HasColumnName("orgtype_vc");

                entity.Property(e => e.ProjectcodeVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectcode_vc");

                entity.Property(e => e.ProjectsiteVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectsite_vc");

                entity.Property(e => e.ReleasecommentsVc)
                    .HasMaxLength(200)
                    .HasColumnName("releasecomments_vc");

                entity.Property(e => e.Releaseremarks)
                    .HasMaxLength(100)
                    .HasColumnName("releaseremarks");

                entity.Property(e => e.SalariedorwagedId)
                    .HasMaxLength(25)
                    .HasColumnName("salariedorwaged_id");

                entity.Property(e => e.SerialnumberId).HasColumnName("serialnumber_id");

                entity.Property(e => e.TotalexperienceNb).HasColumnName("totalexperience_nb");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.TradecapabilitiesVc)
                    .HasMaxLength(200)
                    .HasColumnName("tradecapabilities_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkeravailabilityVc)
                    .HasMaxLength(500)
                    .HasColumnName("workeravailability_vc");

                entity.Property(e => e.WorkperiodfromDt)
                    .HasPrecision(3)
                    .HasColumnName("workperiodfrom_dt");

                entity.Property(e => e.WorkperiodtoDt)
                    .HasPrecision(3)
                    .HasColumnName("workperiodto_dt");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLExperiences)
                    .HasForeignKey(d => d.TradeId)
                    .HasConstraintName("fk_wma_l_experience_wma_m_trades");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLExperiences)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_experience_wma_l_experience");
            });

            modelBuilder.Entity<WmaLGangGangdivisionmapping>(entity =>
            {
                entity.HasKey(e => e.GangdivisionId)
                    .HasName("pk__wma_l_gang_gangdivisionmapping");

                entity.ToTable("wma_l_gang_gangdivisionmapping");

                entity.Property(e => e.GangdivisionId)
                    .HasColumnName("gangdivision_id")
                    .HasDefaultValueSql("nextval('wma_l_gang_gangdivisionmapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DivisionId).HasColumnName("division_id");

                entity.Property(e => e.GangId).HasColumnName("gang_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SubdivisionId).HasColumnName("subdivision_id");

                entity.Property(e => e.YardId).HasColumnName("yard_id");
            });

            modelBuilder.Entity<WmaLGangWorkergangmapping>(entity =>
            {
                entity.HasKey(e => e.WorkergangmappingId)
                    .HasName("pk__wma_l_gang_workergangmapping");

                entity.ToTable("wma_l_gang_workergangmapping");

                entity.Property(e => e.WorkergangmappingId)
                    .HasColumnName("workergangmapping_id")
                    .HasDefaultValueSql("nextval('wma_l_gang_workergangmapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.GangId).HasColumnName("gang_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IsleadBt).HasColumnName("islead_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaLGenericmessage>(entity =>
            {
                entity.ToTable("wma_l_genericmessages");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_l_genericmessages_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Functionality)
                    .HasMaxLength(255)
                    .HasColumnName("functionality");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Message)
                    .HasMaxLength(500)
                    .HasColumnName("message");

                entity.Property(e => e.Messagetype)
                    .HasMaxLength(255)
                    .HasColumnName("messagetype");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");
            });

            modelBuilder.Entity<WmaLLabourcolonyWorkerroommapping>(entity =>
            {
                entity.HasKey(e => e.WorkerroommappingId)
                    .HasName("wma_l_labourcolony_workerroommapping_pkey");

                entity.ToTable("wma_l_labourcolony_workerroommapping");

                entity.Property(e => e.WorkerroommappingId)
                    .HasColumnName("workerroommapping_id")
                    .HasDefaultValueSql("nextval('wma_l_labourcolony_workerroommapping_seq'::regclass)");

                entity.Property(e => e.AllocatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("allocatedon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DeallocatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("deallocatedon_dt");

                entity.Property(e => e.HasalertBt).HasColumnName("hasalert_bt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RoomId).HasColumnName("room_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");
            });

            modelBuilder.Entity<WmaLLabourcolonyWorkerroommappinghistory>(entity =>
            {
                entity.HasKey(e => e.WorkerroommappinghistoryId)
                    .HasName("wma_l_labourcolony_workerroommappinghistory_pkey");

                entity.ToTable("wma_l_labourcolony_workerroommappinghistory");

                entity.Property(e => e.WorkerroommappinghistoryId)
                    .HasColumnName("workerroommappinghistory_id")
                    .HasDefaultValueSql("nextval('wma_l_labourcolony_workerroommappinghistory_seq'::regclass)");

                entity.Property(e => e.AllocatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("allocatedon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DeallocatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("deallocatedon_dt");

                entity.Property(e => e.HasalertBt).HasColumnName("hasalert_bt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RoomId).HasColumnName("room_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.WorkerroommappingId).HasColumnName("workerroommapping_id");
            });

            modelBuilder.Entity<WmaLMenumapping>(entity =>
            {
                entity.HasKey(e => e.MenumappingId)
                    .HasName("pk_wma_l_menumapping");

                entity.ToTable("wma_l_menumapping");

                entity.Property(e => e.MenumappingId)
                    .HasColumnName("menumapping_id")
                    .HasDefaultValueSql("nextval('wma_l_menumapping_seq'::regclass)");

                entity.Property(e => e.ActionnameVc)
                    .HasMaxLength(250)
                    .HasColumnName("actionname_vc");

                entity.Property(e => e.ControllernameVc)
                    .HasMaxLength(250)
                    .HasColumnName("controllername_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ImagepathVc).HasColumnName("imagepath_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MainmenuId).HasColumnName("mainmenu_id");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.OrderbyId).HasColumnName("orderby_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.SubmenuId).HasColumnName("submenu_id");

                entity.HasOne(d => d.Mainmenu)
                    .WithMany(p => p.WmaLMenumappings)
                    .HasForeignKey(d => d.MainmenuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_menumapping_wma_m_mainmenu");
            });

            modelBuilder.Entity<WmaLMobileloginOtp>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wma_l_mobilelogin_otp");

                entity.Property(e => e.DateTime)
                    .HasPrecision(3)
                    .HasColumnName("date_time");

                entity.Property(e => e.Loginuserid).HasColumnName("loginuserid");

                entity.Property(e => e.Otp).HasColumnName("otp");

                entity.Property(e => e.Runningid)
                    .HasColumnName("runningid")
                    .HasDefaultValueSql("nextval('wma_l_mobilelogin_otp_seq'::regclass)");

                entity.Property(e => e.SmsaknId).HasColumnName("smsakn_id");

                entity.Property(e => e.Smsuserid).HasColumnName("smsuserid");
            });

            modelBuilder.Entity<WmaLObservationmapping>(entity =>
            {
                entity.HasKey(e => e.ObservationmappingId)
                    .HasName("pk__wma_l_observationmapping__a498aa44ce1cd541");

                entity.ToTable("wma_l_observationmapping");

                entity.Property(e => e.ObservationmappingId)
                    .HasColumnName("observationmapping_id")
                    .HasDefaultValueSql("nextval('wma_l_observationmapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ObservationcategoryId).HasColumnName("observationcategory_id");

                entity.Property(e => e.ObservationsubcategoryId).HasColumnName("observationsubcategory_id");

                entity.HasOne(d => d.Observationcategory)
                    .WithMany(p => p.WmaLObservationmappings)
                    .HasForeignKey(d => d.ObservationcategoryId)
                    .HasConstraintName("wma_l_observationmapping_observationcategory_id_fkey");

                entity.HasOne(d => d.Observationsubcategory)
                    .WithMany(p => p.WmaLObservationmappings)
                    .HasForeignKey(d => d.ObservationsubcategoryId)
                    .HasConstraintName("wma_l_observationmapping_observationsubcategory_id_fkey");
            });

            modelBuilder.Entity<WmaLProjectMedicalperiodicchecklistmapping>(entity =>
            {
                entity.HasKey(e => e.ProjectMedichecklistmappingid)
                    .HasName("wma_l_project_medicalperiodicchecklistmapping_pkey");

                entity.ToTable("wma_l_project_medicalperiodicchecklistmapping");

                entity.Property(e => e.ProjectMedichecklistmappingid)
                    .HasColumnName("project_medichecklistmappingid")
                    .HasDefaultValueSql("nextval('wma_l_project_medicalperiodicchecklistmapping_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectMedicalperiodicchecklistmappings)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_l_project_medicalperiodicchecklistmapping_checklist_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectMedicalperiodicchecklistmappings)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_l_project_medicalperiodicchecklistmapping_project_id_fkey");
            });

            modelBuilder.Entity<WmaLProjectattachment>(entity =>
            {
                entity.HasKey(e => e.ProjectattachmentId)
                    .HasName("pk_wma_l_projectattachments");

                entity.ToTable("wma_l_projectattachments");

                entity.Property(e => e.ProjectattachmentId)
                    .HasColumnName("projectattachment_id")
                    .HasDefaultValueSql("nextval('wma_l_projectattachments_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.LicenseId).HasColumnName("license_id");

                entity.Property(e => e.ModifedbyId).HasColumnName("modifedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ProjectattachmentcategoryVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectattachmentcategory_vc");

                entity.Property(e => e.ProjectattachmentformatVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectattachmentformat_vc");

                entity.Property(e => e.ProjectattachmentnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectattachmentname_vc");

                entity.Property(e => e.ProjectattachmenturlVc)
                    .HasMaxLength(500)
                    .HasColumnName("projectattachmenturl_vc");

                entity.HasOne(d => d.License)
                    .WithMany(p => p.WmaLProjectattachments)
                    .HasForeignKey(d => d.LicenseId)
                    .HasConstraintName("fk_wma_l_projectattachments_wma_m_licensetype");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectattachments)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("fk_wma_l_projectattachments_wma_m_projects");
            });

            modelBuilder.Entity<WmaLProjectchecklistmap>(entity =>
            {
                entity.HasKey(e => e.ProjectchecklistmapId)
                    .HasName("pk_wma_l_projectchecklistmap");

                entity.ToTable("wma_l_projectchecklistmap");

                entity.Property(e => e.ProjectchecklistmapId)
                    .HasColumnName("projectchecklistmap_id")
                    .HasDefaultValueSql("nextval('wma_l_projectchecklistmap_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectchecklistmaps)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectchecklistmap_wma_m_checklist");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectchecklistmaps)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectchecklistmap_wma_m_projects");
            });

            modelBuilder.Entity<WmaLProjectfeaturemapping>(entity =>
            {
                entity.HasKey(e => e.ProjectfeaturemappingId)
                    .HasName("pk__wma_l_projectfeaturemapping");

                entity.ToTable("wma_l_projectfeaturemapping");

                entity.Property(e => e.ProjectfeaturemappingId)
                    .HasColumnName("projectfeaturemapping_id")
                    .HasDefaultValueSql("nextval('wma_l_projectfeaturemapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FeatureId).HasColumnName("feature_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ValidfromDt)
                    .HasPrecision(3)
                    .HasColumnName("validfrom_dt");

                entity.Property(e => e.ValidtillDt)
                    .HasPrecision(3)
                    .HasColumnName("validtill_dt");
            });

            modelBuilder.Entity<WmaLProjectrlsworkflowmap>(entity =>
            {
                entity.HasKey(e => e.ProjectworkflowmapId)
                    .HasName("pk_wma_l_projectrlsworkflowmap_1");

                entity.ToTable("wma_l_projectrlsworkflowmap");

                entity.Property(e => e.ProjectworkflowmapId)
                    .HasColumnName("projectworkflowmap_id")
                    .HasDefaultValueSql("nextval('wma_l_projectrlsworkflowmap_seq'::regclass)");

                entity.Property(e => e.ApprovalroleId).HasColumnName("approvalrole_id");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SortorderNb).HasColumnName("sortorder_nb");

                entity.Property(e => e.WorkflowstageVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("workflowstage_vc");

                entity.HasOne(d => d.Approvalrole)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaps)
                    .HasForeignKey(d => d.ApprovalroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmap_wma_m_roles");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaps)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmap_wma_m_checklist");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaps)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmap_wma_m_projects");
            });

            modelBuilder.Entity<WmaLProjectrlsworkflowmaptest1>(entity =>
            {
                entity.HasKey(e => e.ProjectworkflowmapId)
                    .HasName("pk_wma_l_projectrlsworkflowmaptest1t_1");

                entity.ToTable("wma_l_projectrlsworkflowmaptest1");

                entity.Property(e => e.ProjectworkflowmapId)
                    .HasColumnName("projectworkflowmap_id")
                    .HasDefaultValueSql("nextval('wma_l_projectrlsworkflowmaptest1_seq'::regclass)");

                entity.Property(e => e.ApprovalroleId).HasColumnName("approvalrole_id");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SortorderNb).HasColumnName("sortorder_nb");

                entity.Property(e => e.WorkflowstageVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("workflowstage_vc");

                entity.HasOne(d => d.Approvalrole)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaptest1s)
                    .HasForeignKey(d => d.ApprovalroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmaptest1_wma_m_roles");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaptest1s)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmaptest1_wma_m_checklist");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectrlsworkflowmaptest1s)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectrlsworkflowmaptest1_wma_m_projects");
            });

            modelBuilder.Entity<WmaLProjectscompoundgroupmapping>(entity =>
            {
                entity.HasKey(e => e.Sno)
                    .HasName("wma_l_projectscompoundgroupmapping_pkey");

                entity.ToTable("wma_l_projectscompoundgroupmapping");

                entity.Property(e => e.Sno)
                    .HasColumnName("sno")
                    .HasDefaultValueSql("nextval('wma_l_projectscompoundgroupmapping_seq'::regclass)");

                entity.Property(e => e.Compundgroupid).HasColumnName("compundgroupid");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.Projectid).HasColumnName("projectid");
            });

            modelBuilder.Entity<WmaLProjectvincensemapping>(entity =>
            {
                entity.HasKey(e => e.ProjectvincensemappingId)
                    .HasName("pk__wma_l_projectvincenseappmapping__a498aa44ce1cd541");

                entity.ToTable("wma_l_projectvincensemapping");

                entity.Property(e => e.ProjectvincensemappingId)
                    .HasColumnName("projectvincensemapping_id")
                    .HasDefaultValueSql("nextval('wma_l_projectvincensemapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.PasswordVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("password_vc");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.UsernameVc)
                    .HasMaxLength(50)
                    .HasColumnName("username_vc");
            });

            modelBuilder.Entity<WmaLProjectworkerevaluationchecklistmapping>(entity =>
            {
                entity.HasKey(e => e.Projectworkerevalutionmappingid)
                    .HasName("wma_l_projectworkerevaluationchecklistmapping_pkey");

                entity.ToTable("wma_l_projectworkerevaluationchecklistmapping");

                entity.Property(e => e.Projectworkerevalutionmappingid)
                    .HasColumnName("projectworkerevalutionmappingid")
                    .HasDefaultValueSql("nextval('wma_l_projectworkerevaluationchecklistmapping_seq'::regclass)");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectworkerevaluationchecklistmappings)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_l_projectworkerevaluationchecklistmapping_checklist_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectworkerevaluationchecklistmappings)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_l_projectworkerevaluationchecklistmapping_project_id_fkey");
            });

            modelBuilder.Entity<WmaLProjectworkflowmap>(entity =>
            {
                entity.HasKey(e => e.ProjectworkflowmapId)
                    .HasName("pk_wma_l_projectworkflowmap_1");

                entity.ToTable("wma_l_projectworkflowmap");

                entity.Property(e => e.ProjectworkflowmapId)
                    .HasColumnName("projectworkflowmap_id")
                    .HasDefaultValueSql("nextval('wma_l_projectworkflowmap_seq'::regclass)");

                entity.Property(e => e.ApprovalroleId).HasColumnName("approvalrole_id");

                entity.Property(e => e.ChecklistId).HasColumnName("checklist_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SortorderNb).HasColumnName("sortorder_nb");

                entity.Property(e => e.WorkflowstageVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("workflowstage_vc");

                entity.HasOne(d => d.Approvalrole)
                    .WithMany(p => p.WmaLProjectworkflowmaps)
                    .HasForeignKey(d => d.ApprovalroleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectworkflowmap_wma_m_roles");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.WmaLProjectworkflowmaps)
                    .HasForeignKey(d => d.ChecklistId)
                    .HasConstraintName("fk_wma_l_projectworkflowmap_wma_m_checklist");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLProjectworkflowmaps)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_projectworkflowmap_wma_m_projects");
            });

            modelBuilder.Entity<WmaLQuestiongrouptrademap>(entity =>
            {
                entity.HasKey(e => e.QuestiongrouptrademapId)
                    .HasName("pk_wma_l_questiongrouptrademap");

                entity.ToTable("wma_l_questiongrouptrademap");

                entity.Property(e => e.QuestiongrouptrademapId)
                    .HasColumnName("questiongrouptrademap_id")
                    .HasDefaultValueSql("nextval('wma_l_questiongrouptrademap_seq'::regclass)");

                entity.Property(e => e.ChecklistquestiongroupId).HasColumnName("checklistquestiongroup_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.HasOne(d => d.Checklistquestiongroup)
                    .WithMany(p => p.WmaLQuestiongrouptrademaps)
                    .HasForeignKey(d => d.ChecklistquestiongroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_questiongrouptrademap_wma_l_checklistquestiongroupmap");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLQuestiongrouptrademaps)
                    .HasForeignKey(d => d.TradeId)
                    .HasConstraintName("fk_wma_l_questiongrouptrademap_wma_m_trades");
            });

            modelBuilder.Entity<WmaLRoletradegroupmapping>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wma_l_roletradegroupmapping");

                entity.Property(e => e.CreatedbyId)
                    .HasPrecision(3)
                    .HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.RoleTradegrpId)
                    .HasColumnName("role_tradegrp_id")
                    .HasDefaultValueSql("nextval('wma_l_roletradegroupmapping_seq'::regclass)");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.HasOne(d => d.Role)
                    .WithMany()
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("wma_l_roletradegroupmapping_role_id_fkey");

                entity.HasOne(d => d.Tradegroup)
                    .WithMany()
                    .HasForeignKey(d => d.TradegroupId)
                    .HasConstraintName("wma_l_roletradegroupmapping_tradegroup_id_fkey");
            });

            modelBuilder.Entity<WmaLTraProjecttrainingattachment>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingattachmentId)
                    .HasName("wma_l_tra_projecttrainingattachments_pkey");

                entity.ToTable("wma_l_tra_projecttrainingattachments");

                entity.Property(e => e.ProjecttrainingattachmentId)
                    .HasColumnName("projecttrainingattachment_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_projecttrainingattachments_seq'::regclass)");

                entity.Property(e => e.AttachmentName)
                    .HasMaxLength(75)
                    .HasColumnName("attachment_name");

                entity.Property(e => e.AttachmentType)
                    .HasMaxLength(50)
                    .HasColumnName("attachment_type");

                entity.Property(e => e.AttachmentUrl).HasColumnName("attachment_url");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");

                entity.HasOne(d => d.Projecttraining)
                    .WithMany(p => p.WmaLTraProjecttrainingattachments)
                    .HasForeignKey(d => d.ProjecttrainingId)
                    .HasConstraintName("fk_wma_l_tra_projecttrainingattachments_wma_f_tra_projecttraini");
            });

            modelBuilder.Entity<WmaLTraProjecttrainingattendance>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingattendanceId)
                    .HasName("wma_l_tra_projecttrainingattendance_pkey");

                entity.ToTable("wma_l_tra_projecttrainingattendance");

                entity.Property(e => e.ProjecttrainingattendanceId)
                    .HasColumnName("projecttrainingattendance_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_projecttrainingattendance_seq'::regclass)");

                entity.Property(e => e.AttendancesubmittedDt)
                    .HasPrecision(3)
                    .HasColumnName("attendancesubmitted_dt");

                entity.Property(e => e.AwsfacerecognitiontransactionId).HasColumnName("awsfacerecognitiontransaction_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ErrormessageVc).HasColumnName("errormessage_vc");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");

                entity.Property(e => e.TrainingattendancetypeVc)
                    .HasMaxLength(10)
                    .HasColumnName("trainingattendancetype_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Projecttraining)
                    .WithMany(p => p.WmaLTraProjecttrainingattendances)
                    .HasForeignKey(d => d.ProjecttrainingId)
                    .HasConstraintName("fk_wma_l_tra_projecttrainingattendance_wma_f_tra_projecttrainin");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLTraProjecttrainingattendances)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("fk_wma_l_tra_projecttrainingattendance_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLTraProjecttrainingconcernedusersmapping>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingconcernedusermapId)
                    .HasName("wma_l_tra_projecttrainingconcernedusersmapping_pkey");

                entity.ToTable("wma_l_tra_projecttrainingconcernedusersmapping");

                entity.Property(e => e.ProjecttrainingconcernedusermapId)
                    .HasColumnName("projecttrainingconcernedusermap_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_projecttrainingconcernedusersmapping_seq'::regclass)");

                entity.Property(e => e.ConcerneduserId).HasColumnName("concerneduser_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");

                entity.HasOne(d => d.Projecttraining)
                    .WithMany(p => p.WmaLTraProjecttrainingconcernedusersmappings)
                    .HasForeignKey(d => d.ProjecttrainingId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_tra_projecttrainingconcernedusersmapping_wma_f_tra_pro");
            });

            modelBuilder.Entity<WmaLTraProjecttrainingfacultymapping>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingfacultymappingId)
                    .HasName("wma_l_tra_projecttrainingfacultymapping_pkey");

                entity.ToTable("wma_l_tra_projecttrainingfacultymapping");

                entity.Property(e => e.ProjecttrainingfacultymappingId)
                    .HasColumnName("projecttrainingfacultymapping_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_projecttrainingfacultymapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FacultydesignationVc)
                    .HasMaxLength(50)
                    .HasColumnName("facultydesignation_vc");

                entity.Property(e => e.FacultyemailidVc)
                    .HasMaxLength(75)
                    .HasColumnName("facultyemailid_vc");

                entity.Property(e => e.FacultynameVc)
                    .HasMaxLength(100)
                    .HasColumnName("facultyname_vc");

                entity.Property(e => e.FacultyorganizationVc)
                    .HasMaxLength(100)
                    .HasColumnName("facultyorganization_vc");

                entity.Property(e => e.IsexternalBt).HasColumnName("isexternal_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");
            });

            modelBuilder.Entity<WmaLTraProjecttrainingsubcontractormapping>(entity =>
            {
                entity.HasKey(e => e.ProjecttrainingsubcontractormapId)
                    .HasName("wma_l_tra_projecttrainingsubcontractormapping_pkey");

                entity.ToTable("wma_l_tra_projecttrainingsubcontractormapping");

                entity.Property(e => e.ProjecttrainingsubcontractormapId)
                    .HasColumnName("projecttrainingsubcontractormap_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_projecttrainingsubcontractormapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjecttrainingId).HasColumnName("projecttraining_id");

                entity.Property(e => e.SubcontractornameVc)
                    .HasMaxLength(500)
                    .HasColumnName("subcontractorname_vc");

                entity.HasOne(d => d.Projecttraining)
                    .WithMany(p => p.WmaLTraProjecttrainingsubcontractormappings)
                    .HasForeignKey(d => d.ProjecttrainingId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_tra_projecttrainingsubcontractormapping_wma_f_tra_proj");
            });

            modelBuilder.Entity<WmaLTraTrainingcategoyrolemapping>(entity =>
            {
                entity.HasKey(e => e.TrainingcategoyrolemapId)
                    .HasName("wma_l_tra_trainingcategoyrolemapping_pkey");

                entity.ToTable("wma_l_tra_trainingcategoyrolemapping");

                entity.Property(e => e.TrainingcategoyrolemapId)
                    .HasColumnName("trainingcategoyrolemap_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_trainingcategoyrolemapping_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.TrainingcategoryId).HasColumnName("trainingcategory_id");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLTraTrainingcategoyrolemappings)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_tra_trainingcategoyrolemapping_wma_m_roles");

                entity.HasOne(d => d.Trainingcategory)
                    .WithMany(p => p.WmaLTraTrainingcategoyrolemappings)
                    .HasForeignKey(d => d.TrainingcategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_tra_trainingcategoyrolemapping_wma_m_tra_trainingcateg");
            });

            modelBuilder.Entity<WmaLTraTrainingtrademap>(entity =>
            {
                entity.HasKey(e => e.TrainingtrademapId)
                    .HasName("wma_l_tra_trainingtrademap_pkey");

                entity.ToTable("wma_l_tra_trainingtrademap");

                entity.Property(e => e.TrainingtrademapId)
                    .HasColumnName("trainingtrademap_id")
                    .HasDefaultValueSql("nextval('wma_l_tra_trainingtrademap_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.TrainingId).HasColumnName("training_id");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLTraTrainingtrademaps)
                    .HasForeignKey(d => d.TradeId)
                    .HasConstraintName("fk_wma_l_tra_trainingtrademap_wma_m_trades");

                entity.HasOne(d => d.Training)
                    .WithMany(p => p.WmaLTraTrainingtrademaps)
                    .HasForeignKey(d => d.TrainingId)
                    .HasConstraintName("fk_wma_l_tra_trainingtrademap_wma_f_tra_training");
            });

            modelBuilder.Entity<WmaLUseradminrolemap>(entity =>
            {
                entity.HasKey(e => e.UseradminrolemapId)
                    .HasName("pk__wma_l_us__6e42b089df45b776");

                entity.ToTable("wma_l_useradminrolemap");

                entity.Property(e => e.UseradminrolemapId)
                    .HasColumnName("useradminrolemap_id")
                    .HasDefaultValueSql("nextval('wma_l_useradminrolemap_seq'::regclass)");

                entity.Property(e => e.CreatdonDt)
                    .HasPrecision(3)
                    .HasColumnName("creatdon_dt");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLUseradminrolemaps)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("fk__wma_l_use__role___7a280247");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLUseradminrolemaps)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("fk__wma_l_use__user___7933de0e");
            });

            modelBuilder.Entity<WmaLUserprojectrolemap>(entity =>
            {
                entity.HasKey(e => e.UserprojectrolemapId)
                    .HasName("pk_wma_l_userprojectrolemap");

                entity.ToTable("wma_l_userprojectrolemap");

                entity.Property(e => e.UserprojectrolemapId)
                    .HasColumnName("userprojectrolemap_id")
                    .HasDefaultValueSql("nextval('wma_l_userprojectrolemap_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLUserprojectrolemaps)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_userprojectrolemap_wma_m_projects");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLUserprojectrolemaps)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_userprojectrolemap_wma_m_roles");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLUserprojectrolemaps)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_userprojectrolemap_wma_m_user");
            });

            modelBuilder.Entity<WmaLUsertradeapprovermap>(entity =>
            {
                entity.HasKey(e => e.UsertradeapprovermapId)
                    .HasName("pk_wma_l_usertradeapprovermap");

                entity.ToTable("wma_l_usertradeapprovermap");

                entity.Property(e => e.UsertradeapprovermapId)
                    .HasColumnName("usertradeapprovermap_id")
                    .HasDefaultValueSql("nextval('wma_l_usertradeapprovermap_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.Property(e => e.UserprojectrolemapId).HasColumnName("userprojectrolemap_id");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLUsertradeapprovermaps)
                    .HasForeignKey(d => d.TradeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_usertradeapprovermap_wma_m_trades");

                entity.HasOne(d => d.Tradegroup)
                    .WithMany(p => p.WmaLUsertradeapprovermaps)
                    .HasForeignKey(d => d.TradegroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_usertradeapprovermap_wma_m_tradegroup");

                entity.HasOne(d => d.Userprojectrolemap)
                    .WithMany(p => p.WmaLUsertradeapprovermaps)
                    .HasForeignKey(d => d.UserprojectrolemapId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_usertradeapprovermap_wma_l_userprojectrolemap");
            });

            modelBuilder.Entity<WmaLUsertreemap>(entity =>
            {
                entity.HasKey(e => e.UsertreemapId)
                    .HasName("pk_wma_l_usertreemap");

                entity.ToTable("wma_l_usertreemap");

                entity.Property(e => e.UsertreemapId)
                    .HasColumnName("usertreemap_id")
                    .HasDefaultValueSql("nextval('wma_l_usertreemap_seq'::regclass)");

                entity.Property(e => e.BuId).HasColumnName("bu_id");

                entity.Property(e => e.ClusterId).HasColumnName("cluster_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IssuperadminBt).HasColumnName("issuperadmin_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.SbgId).HasColumnName("sbg_id");

                entity.Property(e => e.SegmentId).HasColumnName("segment_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.Bu)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.BuId)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_bu");

                entity.HasOne(d => d.Cluster)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.ClusterId)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_cluster");

                entity.HasOne(d => d.Ic)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.IcId)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_ic");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_roles");

                entity.HasOne(d => d.Sbg)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.SbgId)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_sbg");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.WmaLUsertreemaps)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_usertreemap_wma_m_user");
            });

            modelBuilder.Entity<WmaLWageWorkerwageprocessarrearmapping>(entity =>
            {
                entity.HasKey(e => e.Wageprocessingarrearmappingid)
                    .HasName("pk_wma_l_wage_workerwageprocessarrearmapping");

                entity.ToTable("wma_l_wage_workerwageprocessarrearmapping");

                entity.Property(e => e.Wageprocessingarrearmappingid)
                    .HasColumnName("wageprocessingarrearmappingid")
                    .HasDefaultValueSql("nextval('wma_l_wage_workerwageprocessarrearmapping_seq'::regclass)");

                entity.Property(e => e.Arrearid).HasColumnName("arrearid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Workerwageprocessid).HasColumnName("workerwageprocessid");
            });

            modelBuilder.Entity<WmaLWageWorkerwageprocessed>(entity =>
            {
                entity.HasKey(e => e.Workerwageprocessedid)
                    .HasName("pk_wma_l_wage_workerwageprocessed");

                entity.ToTable("wma_l_wage_workerwageprocessed");

                entity.Property(e => e.Workerwageprocessedid)
                    .HasColumnName("workerwageprocessedid")
                    .HasDefaultValueSql("nextval('wma_l_wage_workerwageprocessed_seq'::regclass)");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Bm).HasColumnName("bm");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Dateofpayment)
                    .HasPrecision(3)
                    .HasColumnName("dateofpayment");

                entity.Property(e => e.Enddate)
                    .HasPrecision(3)
                    .HasColumnName("enddate");

                entity.Property(e => e.Esci)
                    .HasPrecision(10, 2)
                    .HasColumnName("esci");

                entity.Property(e => e.Fr).HasColumnName("fr");

                entity.Property(e => e.Incometax)
                    .HasPrecision(10, 2)
                    .HasColumnName("incometax");

                entity.Property(e => e.Insurance)
                    .HasPrecision(10, 2)
                    .HasColumnName("insurance");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.Netpayment)
                    .HasPrecision(10, 2)
                    .HasColumnName("netpayment");

                entity.Property(e => e.Other)
                    .HasPrecision(10, 2)
                    .HasColumnName("other");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Pfdeduction)
                    .HasPrecision(10, 2)
                    .HasColumnName("pfdeduction");

                entity.Property(e => e.Pfemployercontribute)
                    .HasPrecision(10, 2)
                    .HasColumnName("pfemployercontribute");

                entity.Property(e => e.Qr).HasColumnName("qr");

                entity.Property(e => e.Recommendedwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("recommendedwage");

                entity.Property(e => e.Recoveries)
                    .HasPrecision(10, 2)
                    .HasColumnName("recoveries");

                entity.Property(e => e.Society)
                    .HasPrecision(10, 2)
                    .HasColumnName("society");

                entity.Property(e => e.Startdate)
                    .HasPrecision(3)
                    .HasColumnName("startdate");

                entity.Property(e => e.Totalarrear)
                    .HasPrecision(10, 2)
                    .HasColumnName("totalarrear");

                entity.Property(e => e.Totalbasicwage).HasColumnName("totalbasicwage");

                entity.Property(e => e.Totaldeductions)
                    .HasPrecision(10, 2)
                    .HasColumnName("totaldeductions");

                entity.Property(e => e.Totalearnings)
                    .HasPrecision(10, 2)
                    .HasColumnName("totalearnings");

                entity.Property(e => e.Totalot)
                    .HasPrecision(10, 2)
                    .HasColumnName("totalot");

                entity.Property(e => e.Totalothours).HasColumnName("totalothours");

                entity.Property(e => e.Totalworkingdays).HasColumnName("totalworkingdays");

                entity.Property(e => e.Vendorcode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("vendorcode");

                entity.Property(e => e.Workerwagemappingid).HasColumnName("workerwagemappingid");

                entity.Property(e => e.Workerwageprocessid).HasColumnName("workerwageprocessid");
            });

            modelBuilder.Entity<WmaLWageZonemapping>(entity =>
            {
                entity.HasKey(e => e.Zonemappingid)
                    .HasName("wma_l_wage_zonemapping_pkey");

                entity.ToTable("wma_l_wage_zonemapping");

                entity.Property(e => e.Zonemappingid)
                    .HasColumnName("zonemappingid")
                    .HasDefaultValueSql("nextval('wma_l_wage_zonemapping_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Stateid).HasColumnName("stateid");

                entity.Property(e => e.Typeofgovernmentid).HasColumnName("typeofgovernmentid");

                entity.Property(e => e.Zoneid).HasColumnName("zoneid");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.WmaLWageZonemappings)
                    .HasForeignKey(d => d.Stateid)
                    .HasConstraintName("fk_wma_l_wage_zonemapping_wma_m_state");

                entity.HasOne(d => d.Zonemapping)
                    .WithOne(p => p.InverseZonemapping)
                    .HasForeignKey<WmaLWageZonemapping>(d => d.Zonemappingid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_wage_zonemapping_wma_l_wage_zonemapping");
            });

            modelBuilder.Entity<WmaLWorkerbankdetail>(entity =>
            {
                entity.HasKey(e => e.BankdetailId)
                    .HasName("pk_wma_l_workerbankdetails");

                entity.ToTable("wma_l_workerbankdetails");

                entity.Property(e => e.BankdetailId)
                    .HasColumnName("bankdetail_id")
                    .HasDefaultValueSql("nextval('wma_l_workerbankdetails_seq'::regclass)");

                entity.Property(e => e.AccountholdernameVc)
                    .HasMaxLength(500)
                    .HasColumnName("accountholdername_vc");

                entity.Property(e => e.AccounttypeVc)
                    .HasMaxLength(30)
                    .HasColumnName("accounttype_vc");

                entity.Property(e => e.BankaccountnoNb).HasColumnName("bankaccountno_nb");

                entity.Property(e => e.BankaccountnoVc)
                    .HasMaxLength(50)
                    .HasColumnName("bankaccountno_vc");

                entity.Property(e => e.BanknameVc)
                    .HasMaxLength(500)
                    .HasColumnName("bankname_vc");

                entity.Property(e => e.BankregisteredemailVc)
                    .HasMaxLength(500)
                    .HasColumnName("bankregisteredemail_vc");

                entity.Property(e => e.BranchaddrVc)
                    .HasMaxLength(500)
                    .HasColumnName("branchaddr_vc");

                entity.Property(e => e.BranchnameVc)
                    .HasMaxLength(500)
                    .HasColumnName("branchname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.EsiVc)
                    .HasMaxLength(50)
                    .HasColumnName("esi_vc");

                entity.Property(e => e.IbanNb).HasColumnName("iban_nb");

                entity.Property(e => e.IfsccodeVc)
                    .HasMaxLength(500)
                    .HasColumnName("ifsccode_vc");

                entity.Property(e => e.IsactiveBt)
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MicrNb).HasColumnName("micr_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.PfnumberVc)
                    .HasMaxLength(50)
                    .HasColumnName("pfnumber_vc");

                entity.Property(e => e.UannameVc)
                    .HasMaxLength(500)
                    .HasColumnName("uanname_vc");

                entity.Property(e => e.UannoNb).HasColumnName("uanno_nb");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLWorkerbankdetails)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerbankdetails_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLWorkerkyc>(entity =>
            {
                entity.HasKey(e => e.WorkerkycId)
                    .HasName("pk_wma_l_workerkyc");

                entity.ToTable("wma_l_workerkyc");

                entity.Property(e => e.WorkerkycId)
                    .HasColumnName("workerkyc_id")
                    .HasDefaultValueSql("nextval('wma_l_workerkyc_seq'::regclass)");

                entity.Property(e => e.BirthcertificateVc)
                    .HasMaxLength(50)
                    .HasColumnName("birthcertificate_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.DlNoVc)
                    .HasMaxLength(500)
                    .HasColumnName("dl_no_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.NationalpopulationregVc)
                    .HasMaxLength(500)
                    .HasColumnName("nationalpopulationreg_vc");

                entity.Property(e => e.NidNoVc)
                    .HasMaxLength(50)
                    .HasColumnName("nid_no_vc");

                entity.Property(e => e.PanNoVc)
                    .HasMaxLength(50)
                    .HasColumnName("pan_no_vc");

                entity.Property(e => e.PassportnoVc)
                    .HasMaxLength(50)
                    .HasColumnName("passportno_vc");

                entity.Property(e => e.PassportvalidityDt)
                    .HasPrecision(3)
                    .HasColumnName("passportvalidity_dt");

                entity.Property(e => e.RationcardnoVc)
                    .HasMaxLength(50)
                    .HasColumnName("rationcardno_vc");

                entity.Property(e => e.VoteridVc)
                    .HasMaxLength(50)
                    .HasColumnName("voterid_vc");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLWorkerkycs)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerkyc_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLWorkerkycdocument>(entity =>
            {
                entity.HasKey(e => e.KycId)
                    .HasName("pk_wma_l_workerkycdocuments");

                entity.ToTable("wma_l_workerkycdocuments");

                entity.Property(e => e.KycId)
                    .HasColumnName("kyc_id")
                    .HasDefaultValueSql("nextval('wma_l_workerkycdocuments_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ExpiryonDt)
                    .HasPrecision(3)
                    .HasColumnName("expiryon_dt");

                entity.Property(e => e.IdproofId).HasColumnName("idproof_id");

                entity.Property(e => e.IdproofvalueVc)
                    .HasMaxLength(100)
                    .HasColumnName("idproofvalue_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IssuedonDt)
                    .HasPrecision(3)
                    .HasColumnName("issuedon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Idproof)
                    .WithMany(p => p.WmaLWorkerkycdocuments)
                    .HasForeignKey(d => d.IdproofId)
                    .HasConstraintName("fk_wma_l_workerkycdocuments_wma_m_idproof");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLWorkerkycdocuments)
                    .HasForeignKey(d => d.WorkerId)
                    .HasConstraintName("fk_wma_l_workerkycdocuments_wma_l_workerkycdocuments");
            });

            modelBuilder.Entity<WmaLWorkerprojecttradedetail>(entity =>
            {
                entity.HasKey(e => e.TradedetailsId)
                    .HasName("pk_wma_l_workerprojecttradedetails");

                entity.ToTable("wma_l_workerprojecttradedetails");

                entity.Property(e => e.TradedetailsId)
                    .HasColumnName("tradedetails_id")
                    .HasDefaultValueSql("nextval('wma_l_workerprojecttradedetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.FinalapproverId).HasColumnName("finalapprover_id");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SkillcategoryId).HasColumnName("skillcategory_id");

                entity.Property(e => e.SkilllevelId).HasColumnName("skilllevel_id");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.TradeapproverId).HasColumnName("tradeapprover_id");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.Property(e => e.TradesubgroupId).HasColumnName("tradesubgroup_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerprojecttradedetails_wma_m_projects");

                entity.HasOne(d => d.Skillcategory)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.SkillcategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerprojecttradedetails_wma_m_skillcategories");

                entity.HasOne(d => d.Skilllevel)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.SkilllevelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerprojecttradedetails_wma_m_skilllevels");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.TradeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerprojecttradedetails_wma_m_trades");

                entity.HasOne(d => d.Tradeapprover)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.TradeapproverId)
                    .HasConstraintName("fk__wma_l_wor__trade__5aa469f6");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLWorkerprojecttradedetails)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workerprojecttradedetails_wma_l_workerprojecttradedeta");
            });

            modelBuilder.Entity<WmaLWorkerprojecttradedetailshistory>(entity =>
            {
                entity.HasKey(e => e.TradedetailhistoryId)
                    .HasName("pk_wma_l_workmenprojecttradedetailshistory");

                entity.ToTable("wma_l_workerprojecttradedetailshistory");

                entity.Property(e => e.TradedetailhistoryId)
                    .HasColumnName("tradedetailhistory_id")
                    .HasDefaultValueSql("nextval('wma_l_workerprojecttradedetailshistory_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.FinalapproverId).HasColumnName("finalapprover_id");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.SkillcategoryId).HasColumnName("skillcategory_id");

                entity.Property(e => e.SkilllevelId).HasColumnName("skilllevel_id");

                entity.Property(e => e.TradeId).HasColumnName("trade_id");

                entity.Property(e => e.TradeapproverId).HasColumnName("tradeapprover_id");

                entity.Property(e => e.TradedetailsId).HasColumnName("tradedetails_id");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.Property(e => e.TradesubgroupId).HasColumnName("tradesubgroup_id");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_m_projects");

                entity.HasOne(d => d.Skillcategory)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.SkillcategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_m_skillcategorie");

                entity.HasOne(d => d.Skilllevel)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.SkilllevelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_m_skilllevels");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.TradeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_m_trades");

                entity.HasOne(d => d.Tradedetails)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.TradedetailsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_l_workerprojectt");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaLWorkerprojecttradedetailshistories)
                    .HasForeignKey(d => d.WorkerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_l_workmenprojecttradedetailshistory_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaLWorkerzonemapping>(entity =>
            {
                entity.HasKey(e => e.Workerzonemappingid)
                    .HasName("wma_l_workerzonemapping_pkey");

                entity.ToTable("wma_l_workerzonemapping");

                entity.Property(e => e.Workerzonemappingid).HasColumnName("workerzonemappingid");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt).HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt).HasColumnName("modifiedon_dt");

                entity.Property(e => e.WorkerId).HasColumnName("worker_id");

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");
            });

            modelBuilder.Entity<WmaMActivity>(entity =>
            {
                entity.HasKey(e => e.ActivityId)
                    .HasName("wma_m_activity_pkey");

                entity.ToTable("wma_m_activity");

                entity.Property(e => e.ActivityId)
                    .HasColumnName("activity_id")
                    .HasDefaultValueSql("nextval('wma_m_activity_seq'::regclass)");

                entity.Property(e => e.ActivityCode)
                    .HasMaxLength(10)
                    .HasColumnName("activity_code");

                entity.Property(e => e.ActivityVc)
                    .HasMaxLength(500)
                    .HasColumnName("activity_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");
            });

            modelBuilder.Entity<WmaMApiconfigdetail>(entity =>
            {
                entity.HasKey(e => e.ApiconfigdetailsId)
                    .HasName("pk_wma_m_apiconfigdetails");

                entity.ToTable("wma_m_apiconfigdetails");

                entity.Property(e => e.ApiconfigdetailsId)
                    .HasColumnName("apiconfigdetails_id")
                    .HasDefaultValueSql("nextval('wma_m_apiconfigdetails_seq'::regclass)");

                entity.Property(e => e.ApiVendorcodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("api_vendorcode_vc");

                entity.Property(e => e.ApicompanycodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("apicompanycode_vc");

                entity.Property(e => e.ApikeyVc)
                    .HasMaxLength(50)
                    .HasColumnName("apikey_vc");

                entity.Property(e => e.ApipasswordVc)
                    .HasMaxLength(50)
                    .HasColumnName("apipassword_vc");

                entity.Property(e => e.ApiurlVc)
                    .HasMaxLength(300)
                    .HasColumnName("apiurl_vc");

                entity.Property(e => e.ApiusernameVc)
                    .HasMaxLength(50)
                    .HasColumnName("apiusername_vc");

                entity.Property(e => e.ApplicationId).HasColumnName("application_id");

                entity.Property(e => e.ClientidVc)
                    .HasMaxLength(10)
                    .HasColumnName("clientid_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DtcodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("dtcode_vc");

                entity.Property(e => e.EnvironmentIpAddressVc)
                    .HasMaxLength(50)
                    .HasColumnName("environment_ip_address_vc");

                entity.Property(e => e.EnvironmentVc)
                    .HasMaxLength(500)
                    .HasColumnName("environment_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SecretkeyVc)
                    .HasMaxLength(50)
                    .HasColumnName("secretkey_vc");
            });

            modelBuilder.Entity<WmaMApkversionlog>(entity =>
            {
                entity.HasKey(e => e.VersionId)
                    .HasName("wma_m_apkversionlog_pkey");

                entity.ToTable("wma_m_apkversionlog");

                entity.Property(e => e.VersionId)
                    .HasColumnName("version_id")
                    .HasDefaultValueSql("nextval('wma_m_apkversionlog_seq'::regclass)");

                entity.Property(e => e.AppcenterurlVc)
                    .HasMaxLength(500)
                    .HasColumnName("appcenterurl_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.PlatformtypeVc)
                    .HasMaxLength(20)
                    .HasColumnName("platformtype_vc");

                entity.Property(e => e.Version).HasColumnName("version");

                entity.Property(e => e.VersionDate)
                    .HasPrecision(3)
                    .HasColumnName("version_date");
            });

            modelBuilder.Entity<WmaMAwscompanymap>(entity =>
            {
                entity.ToTable("wma_m_awscompanymap");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_m_awscompanymap_seq'::regclass)");

                entity.Property(e => e.Companycode)
                    .HasMaxLength(100)
                    .HasColumnName("companycode");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .HasColumnName("description");

                entity.Property(e => e.Isbucketcreated).HasColumnName("isbucketcreated");
            });

            modelBuilder.Entity<WmaMBonustype>(entity =>
            {
                entity.ToTable("wma_m_bonustype");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Bonustype)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("bonustype");
            });

            modelBuilder.Entity<WmaMBu>(entity =>
            {
                entity.HasKey(e => e.BuId)
                    .HasName("pk__wma_m_bu__37048814a4f8b1de");

                entity.ToTable("wma_m_bu");

                entity.HasIndex(e => new { e.SbgId, e.BunameVc }, "uq_wma_m_bu_buname_vc_sbg_id")
                    .IsUnique();

                entity.Property(e => e.BuId)
                    .HasColumnName("bu_id")
                    .HasDefaultValueSql("nextval('wma_m_bu_seq'::regclass)");

                entity.Property(e => e.BucodeVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("bucode_vc");

                entity.Property(e => e.BunameVc)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("buname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SbgId).HasColumnName("sbg_id");

                entity.HasOne(d => d.Sbg)
                    .WithMany(p => p.WmaMBus)
                    .HasForeignKey(d => d.SbgId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk__wma_m_bu__sbg_id__01142ba1");
            });

            modelBuilder.Entity<WmaMCertificatetype>(entity =>
            {
                entity.HasKey(e => e.CertificatetypeId)
                    .HasName("pk_wma_m_certificatetype");

                entity.ToTable("wma_m_certificatetype");

                entity.Property(e => e.CertificatetypeId)
                    .HasColumnName("certificatetype_id")
                    .HasDefaultValueSql("nextval('wma_m_certificatetype_seq'::regclass)");

                entity.Property(e => e.Certificatetypename)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("certificatetypename");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMChecklist>(entity =>
            {
                entity.HasKey(e => e.ChecklistId)
                    .HasName("pk_wma_m_checklist");

                entity.ToTable("wma_m_checklist");

                entity.Property(e => e.ChecklistId)
                    .HasColumnName("checklist_id")
                    .HasDefaultValueSql("nextval('wma_m_checklist_seq'::regclass)");

                entity.Property(e => e.AssignedtoroleId).HasColumnName("assignedtorole_id");

                entity.Property(e => e.ChecklistCategoryid).HasColumnName("checklist_categoryid");

                entity.Property(e => e.ChecklistclonedfromId).HasColumnName("checklistclonedfrom_id");

                entity.Property(e => e.ChecklistcodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("checklistcode_vc");

                entity.Property(e => e.ChecklistnameVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("checklistname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Ismedicalchecklist).HasColumnName("ismedicalchecklist");

                entity.Property(e => e.IsrankedchecklistBt).HasColumnName("isrankedchecklist_bt");

                entity.Property(e => e.IsspecialchecklistBt).HasColumnName("isspecialchecklist_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMChecklisttypeCategory>(entity =>
            {
                entity.HasKey(e => e.ChecklistCategoryid)
                    .HasName("wma_m_checklisttype_category_pkey");

                entity.ToTable("wma_m_checklisttype_category");

                entity.Property(e => e.ChecklistCategoryid)
                    .HasColumnName("checklist_categoryid")
                    .HasDefaultValueSql("nextval('wma_m_checklisttype_category_seq'::regclass)");

                entity.Property(e => e.CategoryCodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("category_code_vc");

                entity.Property(e => e.ChecklistCategorytype)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("checklist_categorytype");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt).HasColumnName("modifiedon_dt");
            });

            modelBuilder.Entity<WmaMCity>(entity =>
            {
                entity.HasKey(e => e.CityId)
                    .HasName("pk_wma_m_city");

                entity.ToTable("wma_m_city");

                entity.Property(e => e.CityId)
                    .HasColumnName("city_id")
                    .HasDefaultValueSql("nextval('wma_m_city_seq'::regclass)");

                entity.Property(e => e.CityVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("city_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.StateId).HasColumnName("state_id");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.WmaMCities)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_city_wma_m_state");
            });

            modelBuilder.Entity<WmaMCluster>(entity =>
            {
                entity.HasKey(e => e.ClusterId)
                    .HasName("pk__wma_m_cl__ed3e338c09f8414c");

                entity.ToTable("wma_m_cluster");

                entity.Property(e => e.ClusterId)
                    .HasColumnName("cluster_id")
                    .HasDefaultValueSql("nextval('wma_m_cluster_seq'::regclass)");

                entity.Property(e => e.ClustercodeVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("clustercode_vc");

                entity.Property(e => e.ClusternameVc)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("clustername_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SegmentId).HasColumnName("segment_id");
            });

            modelBuilder.Entity<WmaMCompoundgroup>(entity =>
            {
                entity.HasKey(e => e.Compundgroupid)
                    .HasName("wma_m_compoundgroups_pkey");

                entity.ToTable("wma_m_compoundgroups");

                entity.Property(e => e.Compundgroupid)
                    .HasColumnName("compundgroupid")
                    .HasDefaultValueSql("nextval('wma_m_compoundgroups_seq'::regclass)");

                entity.Property(e => e.Compoundgroupname)
                    .HasMaxLength(50)
                    .HasColumnName("compoundgroupname");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.HasOne(d => d.Compundgroup)
                    .WithOne(p => p.InverseCompundgroup)
                    .HasForeignKey<WmaMCompoundgroup>(d => d.Compundgroupid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("wma_m_compoundgroups_compundgroupid_fkey");
            });

            modelBuilder.Entity<WmaMCountry>(entity =>
            {
                entity.HasKey(e => e.CountryId)
                    .HasName("pk_wma_m_country");

                entity.ToTable("wma_m_country");

                entity.Property(e => e.CountryId)
                    .HasColumnName("country_id")
                    .HasDefaultValueSql("nextval('wma_m_country_seq'::regclass)");

                entity.Property(e => e.CountryVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("country_vc");

                entity.Property(e => e.CountrycodeVc)
                    .HasMaxLength(5)
                    .HasColumnName("countrycode_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IswageenabledBt).HasColumnName("iswageenabled_bt");

                entity.Property(e => e.MobilevalidationVc)
                    .HasMaxLength(100)
                    .HasColumnName("mobilevalidation_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Pincodevalidation)
                    .HasMaxLength(200)
                    .HasColumnName("pincodevalidation");

                entity.Property(e => e.Residentidproof).HasColumnName("residentidproof");
            });

            modelBuilder.Entity<WmaMCoviddose>(entity =>
            {
                entity.HasKey(e => e.CoviddoseId)
                    .HasName("pk__wma_m_co__9009335e7bca9fa8");

                entity.ToTable("wma_m_coviddose");

                entity.Property(e => e.CoviddoseId)
                    .HasColumnName("coviddose_id")
                    .HasDefaultValueSql("nextval('wma_m_coviddose_seq'::regclass)");

                entity.Property(e => e.CoviddosenameVc)
                    .HasMaxLength(100)
                    .HasColumnName("coviddosename_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");
            });

            modelBuilder.Entity<WmaMCovidstatus>(entity =>
            {
                entity.HasKey(e => e.Covidstatusid)
                    .HasName("pk_wma_m_covidstatus_1");

                entity.ToTable("wma_m_covidstatus");

                entity.Property(e => e.Covidstatusid)
                    .ValueGeneratedNever()
                    .HasColumnName("covidstatusid");

                entity.Property(e => e.Covidstatus)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("covidstatus");

                entity.Property(e => e.Isactive).HasColumnName("isactive");
            });

            modelBuilder.Entity<WmaMDay>(entity =>
            {
                entity.HasKey(e => e.Dayid)
                    .HasName("wma_m_days_pkey");

                entity.ToTable("wma_m_days");

                entity.Property(e => e.Dayid)
                    .HasColumnName("dayid")
                    .HasDefaultValueSql("nextval('wma_m_days_seq'::regclass)");

                entity.Property(e => e.Day).HasColumnName("day");

                entity.Property(e => e.Daysrefname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("daysrefname");
            });

            modelBuilder.Entity<WmaMDistrict>(entity =>
            {
                entity.HasKey(e => e.DistrictId)
                    .HasName("pk_wma_m_district");

                entity.ToTable("wma_m_district");

                entity.Property(e => e.DistrictId)
                    .HasColumnName("district_id")
                    .HasDefaultValueSql("nextval('wma_m_district_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.DistrictCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("district_code");

                entity.Property(e => e.DistrictVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("district_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.StateId).HasColumnName("state_id");
            });

            modelBuilder.Entity<WmaMEmailutilization>(entity =>
            {
                entity.HasKey(e => e.EmailutilizationId)
                    .HasName("wma_m_emailutilization_pkey");

                entity.ToTable("wma_m_emailutilization");

                entity.Property(e => e.EmailutilizationId)
                    .HasColumnName("emailutilization_id")
                    .HasDefaultValueSql("nextval('wma_m_emailutilization_seq'::regclass)");

                entity.Property(e => e.AccessrolelevelId).HasColumnName("accessrolelevel_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.EmailutilizationVc)
                    .HasMaxLength(500)
                    .HasColumnName("emailutilization_vc");
            });

            modelBuilder.Entity<WmaMEmploymenttype>(entity =>
            {
                entity.HasKey(e => e.EmploymenttypeId)
                    .HasName("pk_wma_m_employmenttype");

                entity.ToTable("wma_m_employmenttype");

                entity.Property(e => e.EmploymenttypeId)
                    .HasColumnName("employmenttype_id")
                    .HasDefaultValueSql("nextval('wma_m_employmenttype_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.EmploymentcodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("employmentcode_vc");

                entity.Property(e => e.EmploymenttypedescVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("employmenttypedesc_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMExam>(entity =>
            {
                entity.HasKey(e => e.ExamId)
                    .HasName("pk_wma_m_exams");

                entity.ToTable("wma_m_exams");

                entity.Property(e => e.ExamId)
                    .HasColumnName("exam_id")
                    .HasDefaultValueSql("nextval('wma_m_exams_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ExamVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("exam_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMFamilydetail>(entity =>
            {
                entity.HasKey(e => e.Familyid)
                    .HasName("pk_wma_m_familydetails");

                entity.ToTable("wma_m_familydetails");

                entity.Property(e => e.Familyid)
                    .HasColumnName("familyid")
                    .HasDefaultValueSql("nextval('wma_m_familydetails_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.RelationTypeid).HasColumnName("relation_typeid");

                entity.Property(e => e.Remarls).HasColumnName("remarls");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaMFamilydetails)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_familydetails_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaMFeature>(entity =>
            {
                entity.HasKey(e => e.FeatureId)
                    .HasName("pk__wma_m_features");

                entity.ToTable("wma_m_features");

                entity.Property(e => e.FeatureId)
                    .HasColumnName("feature_id")
                    .HasDefaultValueSql("nextval('wma_m_features_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FeaturecodeVc)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("featurecode_vc");

                entity.Property(e => e.FeaturedescVc)
                    .HasMaxLength(200)
                    .HasColumnName("featuredesc_vc");

                entity.Property(e => e.Featurename)
                    .HasMaxLength(50)
                    .HasColumnName("featurename");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IsaddonfeatureBt).HasColumnName("isaddonfeature_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");
            });

            modelBuilder.Entity<WmaMGangGang>(entity =>
            {
                entity.HasKey(e => e.GangId)
                    .HasName("pk__wma_m_gang_gangs");

                entity.ToTable("wma_m_gang_gangs");

                entity.Property(e => e.GangId)
                    .HasColumnName("gang_id")
                    .HasDefaultValueSql("nextval('wma_m_gang_gangs_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.GangdescriptionVc)
                    .HasMaxLength(50)
                    .HasColumnName("gangdescription_vc");

                entity.Property(e => e.GangnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("gangname_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");
            });

            modelBuilder.Entity<WmaMGangProjectdivision>(entity =>
            {
                entity.HasKey(e => e.ProjectdivisionId)
                    .HasName("pk__wma_m_gang_projectdivision");

                entity.ToTable("wma_m_gang_projectdivision");

                entity.Property(e => e.ProjectdivisionId)
                    .HasColumnName("projectdivision_id")
                    .HasDefaultValueSql("nextval('wma_m_gang_projectdivision_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DivisiondescriptionVc)
                    .HasMaxLength(500)
                    .HasColumnName("divisiondescription_vc");

                entity.Property(e => e.DivisionnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("divisionname_vc");

                entity.Property(e => e.Isactve).HasColumnName("isactve");

                entity.Property(e => e.Maxworkdone).HasColumnName("maxworkdone");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");
            });

            modelBuilder.Entity<WmaMGangSubdivision>(entity =>
            {
                entity.HasKey(e => e.SubdivisionId)
                    .HasName("pk__wma_m_gang_subdivision");

                entity.ToTable("wma_m_gang_subdivision");

                entity.Property(e => e.SubdivisionId)
                    .HasColumnName("subdivision_id")
                    .HasDefaultValueSql("nextval('wma_m_gang_subdivision_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DivisionId).HasColumnName("division_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SubdivisiondescriptionVc)
                    .HasMaxLength(500)
                    .HasColumnName("subdivisiondescription_vc");

                entity.Property(e => e.Subdivisionloe).HasColumnName("subdivisionloe");

                entity.Property(e => e.SubdivisionnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("subdivisionname_vc");
            });

            modelBuilder.Entity<WmaMGeospatialstatus>(entity =>
            {
                entity.HasKey(e => e.Geospatialstatusid)
                    .HasName("pk_wma_m_geospatialstatus");

                entity.ToTable("wma_m_geospatialstatus");

                entity.Property(e => e.Geospatialstatusid)
                    .ValueGeneratedNever()
                    .HasColumnName("geospatialstatusid");

                entity.Property(e => e.Geospatialstatusvalue)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("geospatialstatusvalue");
            });

            modelBuilder.Entity<WmaMGovermenttype>(entity =>
            {
                entity.HasKey(e => e.Typeofgovermentid)
                    .HasName("wma_m_govermenttype_pkey");

                entity.ToTable("wma_m_govermenttype");

                entity.Property(e => e.Typeofgovermentid)
                    .HasColumnName("typeofgovermentid")
                    .HasDefaultValueSql("nextval('wma_m_govermenttype_seq'::regclass)");

                entity.Property(e => e.Countryid).HasColumnName("countryid");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Typeofgoverment)
                    .HasMaxLength(255)
                    .HasColumnName("typeofgoverment");

                entity.HasOne(d => d.TypeofgovermentNavigation)
                    .WithOne(p => p.InverseTypeofgovermentNavigation)
                    .HasForeignKey<WmaMGovermenttype>(d => d.Typeofgovermentid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_govermenttype_wma_m_govermenttype");
            });

            modelBuilder.Entity<WmaMIc>(entity =>
            {
                entity.HasKey(e => e.IcId)
                    .HasName("pk__wma_m_ic__a498aa44ce1cd541");

                entity.ToTable("wma_m_ic");

                entity.HasIndex(e => e.IcnameVc, "uq__wma_m_ic__193256df3f8f5aec")
                    .IsUnique();

                entity.Property(e => e.IcId)
                    .HasColumnName("ic_id")
                    .HasDefaultValueSql("nextval('wma_m_ic_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.EipcompanycodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("eipcompanycode_vc");

                entity.Property(e => e.IccodeVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("iccode_vc");

                entity.Property(e => e.IcnameVc)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("icname_vc");

                entity.Property(e => e.IcshortnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("icshortname_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMIdproof>(entity =>
            {
                entity.HasKey(e => e.IdproofId)
                    .HasName("pk_wma_m_idproof");

                entity.ToTable("wma_m_idproof");

                entity.Property(e => e.IdproofId)
                    .HasColumnName("idproof_id")
                    .HasDefaultValueSql("nextval('wma_m_idproof_seq'::regclass)");

                entity.Property(e => e.CountryId).HasColumnName("country_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.DemographicflagBt).HasColumnName("demographicflag_bt");

                entity.Property(e => e.HasexpiryonBt).HasColumnName("hasexpiryon_bt");

                entity.Property(e => e.HasissuedonBt).HasColumnName("hasissuedon_bt");

                entity.Property(e => e.IdproofcodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("idproofcode_vc");

                entity.Property(e => e.IdproofnameVc)
                    .HasMaxLength(200)
                    .HasColumnName("idproofname_vc");

                entity.Property(e => e.IdvalidationVc)
                    .HasMaxLength(200)
                    .HasColumnName("idvalidation_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IsrequiredkycBt).HasColumnName("isrequiredkyc_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.WmaMIdproofs)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("fk_wma_m_idproof_wma_m_country");
            });

            modelBuilder.Entity<WmaMLabourcolonyBuilding>(entity =>
            {
                entity.HasKey(e => e.BuildingId)
                    .HasName("wma_m_labourcolony_buildings_pkey");

                entity.ToTable("wma_m_labourcolony_buildings");

                entity.Property(e => e.BuildingId)
                    .HasColumnName("building_id")
                    .HasDefaultValueSql("nextval('wma_m_labourcolony_buildings_seq'::regclass)");

                entity.Property(e => e.BuildingnameVc)
                    .HasMaxLength(100)
                    .HasColumnName("buildingname_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.WmaMLabourcolonyBuildings)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("fk_wma_m_labourcolony_buildings_wma_m_projects");
            });

            modelBuilder.Entity<WmaMLabourcolonyFloor>(entity =>
            {
                entity.HasKey(e => e.FloorId)
                    .HasName("wma_m_labourcolony_floors_pkey");

                entity.ToTable("wma_m_labourcolony_floors");

                entity.Property(e => e.FloorId)
                    .HasColumnName("floor_id")
                    .HasDefaultValueSql("nextval('wma_m_labourcolony_floors_seq'::regclass)");

                entity.Property(e => e.BuildingId).HasColumnName("building_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FloornameVc)
                    .HasMaxLength(50)
                    .HasColumnName("floorname_vc");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");
            });

            modelBuilder.Entity<WmaMLabourcolonyRoom>(entity =>
            {
                entity.HasKey(e => e.RoomId)
                    .HasName("wma_m_labourcolony_rooms_pkey");

                entity.ToTable("wma_m_labourcolony_rooms");

                entity.Property(e => e.RoomId)
                    .HasColumnName("room_id")
                    .HasDefaultValueSql("nextval('wma_m_labourcolony_rooms_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.FloorId).HasColumnName("floor_id");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RoomcapactiyNb).HasColumnName("roomcapactiy_nb");

                entity.Property(e => e.RoomnameVc)
                    .HasMaxLength(50)
                    .HasColumnName("roomname_vc");
            });

            modelBuilder.Entity<WmaMLanguage>(entity =>
            {
                entity.HasKey(e => e.LanguageId)
                    .HasName("pk_wma_m_languages");

                entity.ToTable("wma_m_languages");

                entity.Property(e => e.LanguageId)
                    .HasColumnName("language_id")
                    .HasDefaultValueSql("nextval('wma_m_languages_seq'::regclass)");

                entity.Property(e => e.CountryId).HasColumnName("country_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.LanguageVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("language_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMLeavetype>(entity =>
            {
                entity.ToTable("wma_m_leavetype");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Leavecode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .HasColumnName("leavecode")
                    .IsFixedLength(true);

                entity.Property(e => e.Leavename)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("leavename");
            });

            modelBuilder.Entity<WmaMLicensetype>(entity =>
            {
                entity.HasKey(e => e.LicensetypeId)
                    .HasName("pk_wma_m_licensetype");

                entity.ToTable("wma_m_licensetype");

                entity.Property(e => e.LicensetypeId)
                    .HasColumnName("licensetype_id")
                    .HasDefaultValueSql("nextval('wma_m_licensetype_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.LicensetypeVc)
                    .HasMaxLength(200)
                    .HasColumnName("licensetype_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");
            });

            modelBuilder.Entity<WmaMMainmenu>(entity =>
            {
                entity.HasKey(e => e.MainmenuId)
                    .HasName("pk_wma_m_mainmenu");

                entity.ToTable("wma_m_mainmenu");

                entity.Property(e => e.MainmenuId)
                    .HasColumnName("mainmenu_id")
                    .HasDefaultValueSql("nextval('wma_m_mainmenu_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MainmenucodeVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("mainmenucode_vc");

                entity.Property(e => e.MainmenunameVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("mainmenuname_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMMaritalstatus>(entity =>
            {
                entity.HasKey(e => e.MaritalstatusId)
                    .HasName("pk_wma_m_maritalstatus");

                entity.ToTable("wma_m_maritalstatus");

                entity.Property(e => e.MaritalstatusId)
                    .HasColumnName("maritalstatus_id")
                    .HasDefaultValueSql("nextval('wma_m_maritalstatus_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MaritalstatusVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("maritalstatus_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMNoticeboardcategory>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("pk_wma_m_noticeboardcategory");

                entity.ToTable("wma_m_noticeboardcategory");

                entity.Property(e => e.CategoryId)
                    .HasColumnName("category_id")
                    .HasDefaultValueSql("nextval('wma_m_noticeboardcategory_seq'::regclass)");

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("category_name");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Imagename)
                    .HasMaxLength(100)
                    .HasColumnName("imagename");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");
            });

            modelBuilder.Entity<WmaMNoticeboardsubcategory>(entity =>
            {
                entity.HasKey(e => e.SubcategoryId)
                    .HasName("pk_wma_m_noticeboardsubcategory");

                entity.ToTable("wma_m_noticeboardsubcategory");

                entity.Property(e => e.SubcategoryId)
                    .HasColumnName("subcategory_id")
                    .HasDefaultValueSql("nextval('wma_m_noticeboardsubcategory_seq'::regclass)");

                entity.Property(e => e.CategoryId).HasColumnName("category_id");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Imagename)
                    .HasMaxLength(100)
                    .HasColumnName("imagename");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.SubcategoryName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("subcategory_name");
            });

            modelBuilder.Entity<WmaMObservationcategory>(entity =>
            {
                entity.HasKey(e => e.ObservationcategoryId)
                    .HasName("pk__wma_m_observationcategory__a498aa44ce1cd541");

                entity.ToTable("wma_m_observationcategory");

                entity.Property(e => e.ObservationcategoryId)
                    .HasColumnName("observationcategory_id")
                    .HasDefaultValueSql("nextval('wma_m_observationcategory_seq'::regclass)");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("code");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .HasColumnName("description");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMObservationsubcategory>(entity =>
            {
                entity.HasKey(e => e.ObservationsubcategoryId)
                    .HasName("pk__wma_m_observationsubcategory__a498aa44ce1cd541");

                entity.ToTable("wma_m_observationsubcategory");

                entity.Property(e => e.ObservationsubcategoryId)
                    .HasColumnName("observationsubcategory_id")
                    .HasDefaultValueSql("nextval('wma_m_observationsubcategory_seq'::regclass)");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("code");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .HasColumnName("description");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");
            });

            modelBuilder.Entity<WmaMProject>(entity =>
            {
                entity.HasKey(e => e.ProjectId)
                    .HasName("pk__wma_m_pr__1cb92fe3f7e65da2");

                entity.ToTable("wma_m_projects");

                entity.HasIndex(e => e.ProjectcodeVc, "uq__wma_m_pr__de744d5b745bbd0f")
                    .IsUnique();

                entity.Property(e => e.ProjectId)
                    .HasColumnName("project_id")
                    .HasDefaultValueSql("nextval('wma_m_projects_seq'::regclass)");

                entity.Property(e => e.BuId).HasColumnName("bu_id");

                entity.Property(e => e.Caninductworker)
                    .HasColumnName("caninductworker")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ClusterId).HasColumnName("cluster_id");

                entity.Property(e => e.CompanycodeId).HasColumnName("companycode_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Employerwithaddress)
                    .HasMaxLength(250)
                    .HasColumnName("employerwithaddress");

                entity.Property(e => e.Establishment)
                    .HasMaxLength(250)
                    .HasColumnName("establishment");

                entity.Property(e => e.Govermenttypeid).HasColumnName("govermenttypeid");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IsautoreleaseBt).HasColumnName("isautorelease_bt");

                entity.Property(e => e.IsdefaultprojectBt).HasColumnName("isdefaultproject_bt");

                entity.Property(e => e.Islongabsencedaysreq).HasColumnName("islongabsencedaysreq");

                entity.Property(e => e.Ismainproject).HasColumnName("ismainproject");

                entity.Property(e => e.Iswagemoduleenabled).HasColumnName("iswagemoduleenabled");

                entity.Property(e => e.JobcityVc)
                    .HasMaxLength(250)
                    .HasColumnName("jobcity_vc");

                entity.Property(e => e.JobcountryId).HasColumnName("jobcountry_id");

                entity.Property(e => e.JoboriginlocationVc)
                    .HasMaxLength(25)
                    .HasColumnName("joboriginlocation_vc");

                entity.Property(e => e.JobpincodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("jobpincode_vc");

                entity.Property(e => e.JobstateVc)
                    .HasMaxLength(250)
                    .HasColumnName("jobstate_vc");

                entity.Property(e => e.Lastsyncedon)
                    .HasPrecision(3)
                    .HasColumnName("lastsyncedon");

                entity.Property(e => e.Lastsyncedon1)
                    .HasPrecision(3)
                    .HasColumnName("lastsyncedon1")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Lastsyncedremarks).HasColumnName("lastsyncedremarks");

                entity.Property(e => e.Longabsencedays).HasColumnName("longabsencedays");

                entity.Property(e => e.Mainprojectid).HasColumnName("mainprojectid");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectcodeVc)
                    .IsRequired()
                    .HasMaxLength(15)
                    .HasColumnName("projectcode_vc");

                entity.Property(e => e.ProjectdescriptionVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("projectdescription_vc");

                entity.Property(e => e.SbgId).HasColumnName("sbg_id");

                entity.Property(e => e.Sectionid).HasColumnName("sectionid");

                entity.Property(e => e.SegmentId).HasColumnName("segment_id");

                entity.Property(e => e.SerialnumberinitNb).HasColumnName("serialnumberinit_nb");

                entity.Property(e => e.Zonemappingid).HasColumnName("zonemappingid");

                entity.HasOne(d => d.Bu)
                    .WithMany(p => p.WmaMProjects)
                    .HasForeignKey(d => d.BuId)
                    .HasConstraintName("fk_wma_m_projects_wma_m_bu");

                entity.HasOne(d => d.Cluster)
                    .WithMany(p => p.WmaMProjects)
                    .HasForeignKey(d => d.ClusterId)
                    .HasConstraintName("fk_wma_m_projects_wma_m_cluster");

                entity.HasOne(d => d.Ic)
                    .WithMany(p => p.WmaMProjects)
                    .HasForeignKey(d => d.IcId)
                    .HasConstraintName("fk_wma_m_projects_wma_m_ic");

                entity.HasOne(d => d.Sbg)
                    .WithMany(p => p.WmaMProjects)
                    .HasForeignKey(d => d.SbgId)
                    .HasConstraintName("fk_wma_m_projects_wma_m_sbg");
            });

            modelBuilder.Entity<WmaMRanking>(entity =>
            {
                entity.HasKey(e => e.RankingId)
                    .HasName("wma_m_ranking_pkey");

                entity.ToTable("wma_m_ranking");

                entity.Property(e => e.RankingId)
                    .HasColumnName("ranking_id")
                    .HasDefaultValueSql("nextval('wma_m_ranking_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.RankId).HasColumnName("rank_id");
            });

            modelBuilder.Entity<WmaMReferredbydetail>(entity =>
            {
                entity.HasKey(e => e.Referredid)
                    .HasName("pk_wma_m_referredbydetails");

                entity.ToTable("wma_m_referredbydetails");

                entity.Property(e => e.Referredid)
                    .HasColumnName("referredid")
                    .HasDefaultValueSql("nextval('wma_m_referredbydetails_seq'::regclass)");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.ReferredbyDate)
                    .HasPrecision(3)
                    .HasColumnName("referredby_date");

                entity.Property(e => e.ReferredbyEmailid)
                    .IsRequired()
                    .HasColumnName("referredby_emailid");

                entity.Property(e => e.ReferredbyName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("referredby_name");

                entity.Property(e => e.Workerid).HasColumnName("workerid");

                entity.HasOne(d => d.Worker)
                    .WithMany(p => p.WmaMReferredbydetails)
                    .HasForeignKey(d => d.Workerid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_referredbydetails_wma_f_workerdata");
            });

            modelBuilder.Entity<WmaMRegularisationtype>(entity =>
            {
                entity.HasKey(e => e.Regularisationtypeid)
                    .HasName("pk_wma_m_regularisationtype");

                entity.ToTable("wma_m_regularisationtype");

                entity.Property(e => e.Regularisationtypeid)
                    .ValueGeneratedNever()
                    .HasColumnName("regularisationtypeid");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Regularisationtypename)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("regularisationtypename");
            });

            modelBuilder.Entity<WmaMRelationtype>(entity =>
            {
                entity.HasKey(e => e.Relationtypeid)
                    .HasName("pk_wma_m_relationtype");

                entity.ToTable("wma_m_relationtype");

                entity.Property(e => e.Relationtypeid)
                    .ValueGeneratedNever()
                    .HasColumnName("relationtypeid");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.Relationtype)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("relationtype");
            });

            modelBuilder.Entity<WmaMReleasecomment>(entity =>
            {
                entity.HasKey(e => e.ReleasecommentsId)
                    .HasName("wma_m_releasecomments_pkey");

                entity.ToTable("wma_m_releasecomments");

                entity.Property(e => e.ReleasecommentsId)
                    .HasColumnName("releasecomments_id")
                    .HasDefaultValueSql("nextval('wma_m_releasecomments_seq'::regclass)");

                entity.Property(e => e.ReleasenameVc)
                    .HasMaxLength(200)
                    .HasColumnName("releasename_vc");
            });

            modelBuilder.Entity<WmaMResponsetype>(entity =>
            {
                entity.HasKey(e => e.ResponsetypeId)
                    .HasName("pk_wma_m_responsetype");

                entity.ToTable("wma_m_responsetype");

                entity.Property(e => e.ResponsetypeId)
                    .HasColumnName("responsetype_id")
                    .HasDefaultValueSql("nextval('wma_m_responsetype_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ResponsetypedescVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("responsetypedesc_vc");
            });

            modelBuilder.Entity<WmaMRisklevel>(entity =>
            {
                entity.HasKey(e => e.Risklevelid)
                    .HasName("pk_wma_m_risklevel");

                entity.ToTable("wma_m_risklevel");

                entity.Property(e => e.Risklevelid)
                    .ValueGeneratedNever()
                    .HasColumnName("risklevelid");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Risklevel)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("risklevel");
            });

            modelBuilder.Entity<WmaMRole>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("pk__wma_m_ro__d80ab4bb1a102779");

                entity.ToTable("wma_m_roles");

                entity.Property(e => e.RoleId)
                    .HasColumnName("role_id")
                    .HasDefaultValueSql("nextval('wma_m_roles_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.HasmobileaccessBt).HasColumnName("hasmobileaccess_bt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.IsadminroleBt).HasColumnName("isadminrole_bt");

                entity.Property(e => e.IstradegrplevelaccessBt).HasColumnName("istradegrplevelaccess_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RolecodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("rolecode_vc");

                entity.Property(e => e.RolenameVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("rolename_vc");
            });

            modelBuilder.Entity<WmaMSbg>(entity =>
            {
                entity.HasKey(e => e.SbgId)
                    .HasName("pk__wma_m_sb__820b2644a48b4b6a");

                entity.ToTable("wma_m_sbg");

                entity.HasIndex(e => new { e.SbgnameVc, e.IcId }, "uq_wma_m_sbg_sbgname_vc_ic_id")
                    .IsUnique();

                entity.Property(e => e.SbgId)
                    .HasColumnName("sbg_id")
                    .HasDefaultValueSql("nextval('wma_m_sbg_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IcId).HasColumnName("ic_id");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SbgcodeVc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("sbgcode_vc");

                entity.Property(e => e.SbgnameVc)
                    .IsRequired()
                    .HasMaxLength(150)
                    .HasColumnName("sbgname_vc");

                entity.HasOne(d => d.Ic)
                    .WithMany(p => p.WmaMSbgs)
                    .HasForeignKey(d => d.IcId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk__wma_m_sbg__ic_id__7a672e12");
            });

            modelBuilder.Entity<WmaMSection>(entity =>
            {
                entity.HasKey(e => e.SectionId)
                    .HasName("wma_m_sections_pkey");

                entity.ToTable("wma_m_sections");

                entity.Property(e => e.SectionId)
                    .HasColumnName("section_id")
                    .HasDefaultValueSql("nextval('wma_m_sections_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.Sectioncode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("sectioncode");

                entity.Property(e => e.Sectionname)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("sectionname");
            });

            modelBuilder.Entity<WmaMSectionsubproject>(entity =>
            {
                entity.HasKey(e => e.SectionsubprojectidId)
                    .HasName("wma_m_sectionsubproject_pkey");

                entity.ToTable("wma_m_sectionsubproject");

                entity.Property(e => e.SectionsubprojectidId)
                    .HasColumnName("sectionsubprojectid_id")
                    .HasDefaultValueSql("nextval('wma_m_sectionsubproject_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.Masterprojectid).HasColumnName("masterprojectid");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SectionidId).HasColumnName("sectionid_id");

                entity.Property(e => e.Subprojectid).HasColumnName("subprojectid");
            });

            modelBuilder.Entity<WmaMSegment>(entity =>
            {
                entity.HasKey(e => e.SegmentId)
                    .HasName("wma_m_segment_pkey");

                entity.ToTable("wma_m_segment");

                entity.Property(e => e.SegmentId)
                    .HasColumnName("segment_id")
                    .HasDefaultValueSql("nextval('wma_m_segment_seq'::regclass)");

                entity.Property(e => e.BuId).HasColumnName("bu_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SegmentcodeVc)
                    .HasMaxLength(50)
                    .HasColumnName("segmentcode_vc");

                entity.Property(e => e.SegmentnameVc)
                    .HasMaxLength(200)
                    .HasColumnName("segmentname_vc");
            });

            modelBuilder.Entity<WmaMSelfdeclarationquestion>(entity =>
            {
                entity.HasKey(e => e.Sdqid)
                    .HasName("pk_wma_m_selfdeclarationquestions");

                entity.ToTable("wma_m_selfdeclarationquestions");

                entity.Property(e => e.Sdqid)
                    .ValueGeneratedNever()
                    .HasColumnName("sdqid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Header)
                    .HasMaxLength(50)
                    .HasColumnName("header");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isdatereq).HasColumnName("isdatereq");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Options)
                    .HasMaxLength(50)
                    .HasColumnName("options");

                entity.Property(e => e.Optiontype)
                    .HasMaxLength(10)
                    .HasColumnName("optiontype");

                entity.Property(e => e.Sdq)
                    .IsRequired()
                    .HasColumnName("sdq");

                entity.Property(e => e.Subheader)
                    .HasMaxLength(500)
                    .HasColumnName("subheader");
            });

            modelBuilder.Entity<WmaMSkill>(entity =>
            {
                entity.HasKey(e => e.SkillId)
                    .HasName("pk_wma_m_skill");

                entity.ToTable("wma_m_skill");

                entity.Property(e => e.SkillId)
                    .HasColumnName("skill_id")
                    .HasDefaultValueSql("nextval('wma_m_skill_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SkilldescriptionVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("skilldescription_vc");
            });

            modelBuilder.Entity<WmaMSkillcategory>(entity =>
            {
                entity.HasKey(e => e.SkillcategoryId)
                    .HasName("pk_wma_m_skillcategories");

                entity.ToTable("wma_m_skillcategories");

                entity.Property(e => e.SkillcategoryId)
                    .HasColumnName("skillcategory_id")
                    .HasDefaultValueSql("nextval('wma_m_skillcategories_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SkillcategoryVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("skillcategory_vc");

                entity.Property(e => e.SkillcategorycodeVc)
                    .HasMaxLength(10)
                    .HasColumnName("skillcategorycode_vc");
            });

            modelBuilder.Entity<WmaMSkilllevel>(entity =>
            {
                entity.HasKey(e => e.SkilllevelId)
                    .HasName("pk_wma_m_skilllevels");

                entity.ToTable("wma_m_skilllevels");

                entity.Property(e => e.SkilllevelId)
                    .HasColumnName("skilllevel_id")
                    .HasDefaultValueSql("nextval('wma_m_skilllevels_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SkilllevelVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("skilllevel_vc");
            });

            modelBuilder.Entity<WmaMState>(entity =>
            {
                entity.HasKey(e => e.StateId)
                    .HasName("pk_wma_m_state");

                entity.ToTable("wma_m_state");

                entity.Property(e => e.StateId)
                    .HasColumnName("state_id")
                    .HasDefaultValueSql("nextval('wma_m_state_seq'::regclass)");

                entity.Property(e => e.CountryId).HasColumnName("country_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.LatitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("latitude_vc");

                entity.Property(e => e.LongitudeVc)
                    .HasMaxLength(30)
                    .HasColumnName("longitude_vc");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.StateVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("state_vc");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.WmaMStates)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_state_wma_m_country");
            });

            modelBuilder.Entity<WmaMStatus>(entity =>
            {
                entity.HasKey(e => e.StatusId)
                    .HasName("pk_wma_m_status");

                entity.ToTable("wma_m_status");

                entity.Property(e => e.StatusId)
                    .HasColumnName("status_id")
                    .HasDefaultValueSql("nextval('wma_m_status_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.StatusVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("status_vc");

                entity.Property(e => e.StatusshortnameVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("statusshortname_vc");
            });

            modelBuilder.Entity<WmaMSubcontractortype>(entity =>
            {
                entity.HasKey(e => e.SctypeId)
                    .HasName("wma_m_subcontractortypes_pkey");

                entity.ToTable("wma_m_subcontractortypes");

                entity.Property(e => e.SctypeId)
                    .HasColumnName("sctype_id")
                    .UseIdentityAlwaysColumn();

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.SccodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("sccode_vc");

                entity.Property(e => e.ScnameVc)
                    .HasMaxLength(100)
                    .HasColumnName("scname_vc");
            });

            modelBuilder.Entity<WmaMSubmenu>(entity =>
            {
                entity.HasKey(e => e.SubmenuId)
                    .HasName("pk_wma_m_submenu");

                entity.ToTable("wma_m_submenu");

                entity.Property(e => e.SubmenuId)
                    .HasColumnName("submenu_id")
                    .HasDefaultValueSql("nextval('wma_m_submenu_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SubmenucodeVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("submenucode_vc");

                entity.Property(e => e.SubmenunameVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("submenuname_vc");
            });

            modelBuilder.Entity<WmaMSubprojectjoineip>(entity =>
            {
                entity.HasKey(e => e.Subprojectjoineipid)
                    .HasName("pk_wma_m_subprojectjoineip");

                entity.ToTable("wma_m_subprojectjoineip");

                entity.Property(e => e.Subprojectjoineipid)
                    .HasColumnName("subprojectjoineipid")
                    .HasDefaultValueSql("nextval('wma_m_subprojectjoineip_seq'::regclass)");

                entity.Property(e => e.Isalreadyjoinedeip).HasColumnName("isalreadyjoinedeip");

                entity.Property(e => e.Subprojectid).HasColumnName("subprojectid");

                entity.Property(e => e.Workerid).HasColumnName("workerid");
            });

            modelBuilder.Entity<WmaMThirdpartyuser>(entity =>
            {
                entity.HasKey(e => e.CuserId)
                    .HasName("wma_m_thirdpartyusers_pkey");

                entity.ToTable("wma_m_thirdpartyusers");

                entity.Property(e => e.CuserId)
                    .HasColumnName("cuser_id")
                    .HasDefaultValueSql("nextval('wma_m_thirdpartyusers_seq'::regclass)");

                entity.Property(e => e.CompanycodeVc)
                    .HasMaxLength(255)
                    .HasColumnName("companycode_vc");

                entity.Property(e => e.CompanynameVc)
                    .HasMaxLength(255)
                    .HasColumnName("companyname_vc");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.PasswordVc).HasColumnName("password_vc");

                entity.Property(e => e.UsernameVc)
                    .HasMaxLength(255)
                    .HasColumnName("username_vc");
            });

            modelBuilder.Entity<WmaMTokenmanager>(entity =>
            {
                entity.HasKey(e => e.TokenmanagerId)
                    .HasName("wma_m_tokenmanager_pkey");

                entity.ToTable("wma_m_tokenmanager");

                entity.Property(e => e.TokenmanagerId)
                    .HasColumnName("tokenmanager_id")
                    .HasDefaultValueSql("nextval('wma_m_tokenmanager_seq'::regclass)");

                entity.Property(e => e.CreatedonDt)
                    .HasColumnType("date")
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.TokenVc).HasColumnName("token_vc");
            });

            modelBuilder.Entity<WmaMTraTrainingcategory>(entity =>
            {
                entity.HasKey(e => e.TrainingcategoryId)
                    .HasName("wma_m_tra_trainingcategory_pkey");

                entity.ToTable("wma_m_tra_trainingcategory");

                entity.Property(e => e.TrainingcategoryId)
                    .HasColumnName("trainingcategory_id")
                    .HasDefaultValueSql("nextval('wma_m_tra_trainingcategory_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.TrainingcategoryVc)
                    .HasMaxLength(50)
                    .HasColumnName("trainingcategory_vc");
            });

            modelBuilder.Entity<WmaMTraTrainingmode>(entity =>
            {
                entity.HasKey(e => e.TrainingmodeId)
                    .HasName("wma_m_tra_trainingmodes_pkey");

                entity.ToTable("wma_m_tra_trainingmodes");

                entity.Property(e => e.TrainingmodeId)
                    .HasColumnName("trainingmode_id")
                    .HasDefaultValueSql("nextval('wma_m_tra_trainingmodes_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.TrainingmodeVc)
                    .HasMaxLength(30)
                    .HasColumnName("trainingmode_vc");
            });

            modelBuilder.Entity<WmaMTraTrainingtype>(entity =>
            {
                entity.HasKey(e => e.TrainingtypeId)
                    .HasName("wma_m_tra_trainingtypes_pkey");

                entity.ToTable("wma_m_tra_trainingtypes");

                entity.Property(e => e.TrainingtypeId)
                    .HasColumnName("trainingtype_id")
                    .HasDefaultValueSql("nextval('wma_m_tra_trainingtypes_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.TrainingtypeVc)
                    .HasMaxLength(30)
                    .HasColumnName("trainingtype_vc");
            });

            modelBuilder.Entity<WmaMTrade>(entity =>
            {
                entity.HasKey(e => e.TradeId)
                    .HasName("pk_wma_m_trades");

                entity.ToTable("wma_m_trades");

                entity.Property(e => e.TradeId)
                    .HasColumnName("trade_id")
                    .HasDefaultValueSql("nextval('wma_m_trades_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.SkillmasterId).HasColumnName("skillmaster_id");

                entity.Property(e => e.TradeVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("trade_vc");

                entity.Property(e => e.TradecategoryId).HasColumnName("tradecategory_id");

                entity.Property(e => e.TradecodeVc)
                    .HasMaxLength(15)
                    .HasColumnName("tradecode_vc");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.Property(e => e.TradesubgroupId).HasColumnName("tradesubgroup_id");
            });

            modelBuilder.Entity<WmaMTradegroup>(entity =>
            {
                entity.HasKey(e => e.TradegroupId)
                    .HasName("pk_wma_m_tradegroup");

                entity.ToTable("wma_m_tradegroup");

                entity.Property(e => e.TradegroupId)
                    .HasColumnName("tradegroup_id")
                    .HasDefaultValueSql("nextval('wma_m_tradegroup_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.TradegroupVc)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasColumnName("tradegroup_vc");

                entity.Property(e => e.TradegroupcodeVc)
                    .HasMaxLength(20)
                    .HasColumnName("tradegroupcode_vc");
            });

            modelBuilder.Entity<WmaMTradesubgroup>(entity =>
            {
                entity.HasKey(e => e.TradesubgroupId)
                    .HasName("pk_wma_m_tradesubgroup");

                entity.ToTable("wma_m_tradesubgroup");

                entity.Property(e => e.TradesubgroupId)
                    .HasColumnName("tradesubgroup_id")
                    .HasDefaultValueSql("nextval('wma_m_tradesubgroup_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt");

                entity.Property(e => e.TradegroupId).HasColumnName("tradegroup_id");

                entity.Property(e => e.TradesubgroupVc)
                    .HasMaxLength(250)
                    .HasColumnName("tradesubgroup_vc");

                entity.HasOne(d => d.Tradegroup)
                    .WithMany(p => p.WmaMTradesubgroups)
                    .HasForeignKey(d => d.TradegroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_tradesubgroup_wma_m_tradegroup");
            });

            modelBuilder.Entity<WmaMTraining>(entity =>
            {
                entity.HasKey(e => e.TrainingId)
                    .HasName("pk_wma_m_training");

                entity.ToTable("wma_m_training");

                entity.Property(e => e.TrainingId)
                    .HasColumnName("training_id")
                    .HasDefaultValueSql("nextval('wma_m_training_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.TrainingVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("training_vc");
            });

            modelBuilder.Entity<WmaMUanmaster>(entity =>
            {
                entity.HasKey(e => e.UanmasterId)
                    .HasName("pk_wma_m_uanmaster");

                entity.ToTable("wma_m_uanmaster");

                entity.Property(e => e.UanmasterId)
                    .HasColumnName("uanmaster_id")
                    .HasDefaultValueSql("nextval('wma_m_uanmaster_seq'::regclass)");

                entity.Property(e => e.AadharnumberNb).HasColumnName("aadharnumber_nb");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.DobDt)
                    .HasPrecision(3)
                    .HasColumnName("dob_dt");

                entity.Property(e => e.DojDt)
                    .HasPrecision(3)
                    .HasColumnName("doj_dt");

                entity.Property(e => e.FathernameorhusbandnameVc)
                    .HasMaxLength(255)
                    .HasColumnName("fathernameorhusbandname_vc");

                entity.Property(e => e.GenderVc)
                    .HasMaxLength(20)
                    .HasColumnName("gender_vc");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MaritalstatusVc)
                    .HasMaxLength(255)
                    .HasColumnName("maritalstatus_vc");

                entity.Property(e => e.MemberidNb).HasColumnName("memberid_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.RelationVc)
                    .HasMaxLength(255)
                    .HasColumnName("relation_vc");

                entity.Property(e => e.UanNb).HasColumnName("uan_nb");

                entity.Property(e => e.UannameVc)
                    .HasMaxLength(255)
                    .HasColumnName("uanname_vc");
            });

            modelBuilder.Entity<WmaMUser>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("pk__wma_m_us__206d919008f2ae0b");

                entity.ToTable("wma_m_user");

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id")
                    .HasDefaultValueSql("nextval('wma_m_user_seq'::regclass)");

                entity.Property(e => e.ClientipVc)
                    .HasMaxLength(50)
                    .HasColumnName("clientip_vc");

                entity.Property(e => e.CountrycodeVc)
                    .HasMaxLength(100)
                    .HasColumnName("countrycode_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.CustomaccesstokenVc)
                    .HasMaxLength(500)
                    .HasColumnName("customaccesstoken_vc");

                entity.Property(e => e.EipuserId).HasColumnName("eipuser_id");

                entity.Property(e => e.EmailidVc)
                    .HasMaxLength(150)
                    .HasColumnName("emailid_vc");

                entity.Property(e => e.IsaccountlockedBt)
                    .HasColumnName("isaccountlocked_bt")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IslntemployeeBt)
                    .IsRequired()
                    .HasColumnName("islntemployee_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.LastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("lastlogin_dt");

                entity.Property(e => e.LastresetonDt)
                    .HasPrecision(3)
                    .HasColumnName("lastreseton_dt");

                entity.Property(e => e.LoginnameVc)
                    .HasMaxLength(200)
                    .HasColumnName("loginname_vc");

                entity.Property(e => e.MedicalregidVc)
                    .HasMaxLength(200)
                    .HasColumnName("medicalregid_vc");

                entity.Property(e => e.MobilelastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("mobilelastlogin_dt");

                entity.Property(e => e.MobilenoNb).HasColumnName("mobileno_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.PasswordVc)
                    .HasMaxLength(200)
                    .HasColumnName("password_vc");

                entity.Property(e => e.PasswordvalidityDt)
                    .HasPrecision(3)
                    .HasColumnName("passwordvalidity_dt");

                entity.Property(e => e.PsnoVc)
                    .HasMaxLength(25)
                    .HasColumnName("psno_vc");

                entity.Property(e => e.QuerystringVc)
                    .HasMaxLength(500)
                    .HasColumnName("querystring_vc");

                entity.Property(e => e.QuerystringgeneratedonDt)
                    .HasPrecision(3)
                    .HasColumnName("querystringgeneratedon_dt");

                entity.Property(e => e.ResetattemptNb).HasColumnName("resetattempt_nb");

                entity.Property(e => e.UsernameVc)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("username_vc");

                entity.Property(e => e.WeblastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("weblastlogin_dt");

                entity.Property(e => e.WrongattemptNb)
                    .HasColumnName("wrongattempt_nb")
                    .HasDefaultValueSql("0");
            });

            modelBuilder.Entity<WmaMUserhistory>(entity =>
            {
                entity.HasKey(e => e.HistoryId)
                    .HasName("pk_wma_m_userhistory");

                entity.ToTable("wma_m_userhistory");

                entity.Property(e => e.HistoryId)
                    .HasColumnName("history_id")
                    .HasDefaultValueSql("nextval('wma_m_userhistory_seq'::regclass)");

                entity.Property(e => e.ClientipVc)
                    .HasMaxLength(50)
                    .HasColumnName("clientip_vc");

                entity.Property(e => e.CountrycodeVc)
                    .HasMaxLength(100)
                    .HasColumnName("countrycode_vc");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.CustomaccesstokenVc)
                    .HasMaxLength(500)
                    .HasColumnName("customaccesstoken_vc");

                entity.Property(e => e.EipuserId).HasColumnName("eipuser_id");

                entity.Property(e => e.EmailidVc)
                    .HasMaxLength(150)
                    .HasColumnName("emailid_vc");

                entity.Property(e => e.IsaccountlockedBt)
                    .HasColumnName("isaccountlocked_bt")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IslntemployeeBt)
                    .IsRequired()
                    .HasColumnName("islntemployee_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.LastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("lastlogin_dt");

                entity.Property(e => e.LastresetonDt)
                    .HasPrecision(3)
                    .HasColumnName("lastreseton_dt");

                entity.Property(e => e.LoginnameVc)
                    .HasMaxLength(200)
                    .HasColumnName("loginname_vc");

                entity.Property(e => e.MedicalregidVc)
                    .HasMaxLength(200)
                    .HasColumnName("medicalregid_vc");

                entity.Property(e => e.MobilelastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("mobilelastlogin_dt");

                entity.Property(e => e.MobilenoNb).HasColumnName("mobileno_nb");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.PasswordVc)
                    .HasMaxLength(200)
                    .HasColumnName("password_vc");

                entity.Property(e => e.PasswordvalidityDt)
                    .HasPrecision(3)
                    .HasColumnName("passwordvalidity_dt");

                entity.Property(e => e.PsnoVc)
                    .HasMaxLength(25)
                    .HasColumnName("psno_vc");

                entity.Property(e => e.QuerystringVc)
                    .HasMaxLength(500)
                    .HasColumnName("querystring_vc");

                entity.Property(e => e.QuerystringgeneratedonDt)
                    .HasPrecision(3)
                    .HasColumnName("querystringgeneratedon_dt");

                entity.Property(e => e.ResetattemptNb).HasColumnName("resetattempt_nb");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.Property(e => e.UsernameVc)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("username_vc");

                entity.Property(e => e.WeblastloginDt)
                    .HasPrecision(3)
                    .HasColumnName("weblastlogin_dt");

                entity.Property(e => e.WrongattemptNb)
                    .HasColumnName("wrongattempt_nb")
                    .HasDefaultValueSql("0");
            });

            modelBuilder.Entity<WmaMWageArreartype>(entity =>
            {
                entity.HasKey(e => e.Arreartypeid)
                    .HasName("wma_m_wage_arreartype_pkey");

                entity.ToTable("wma_m_wage_arreartype");

                entity.Property(e => e.Arreartypeid)
                    .HasColumnName("arreartypeid")
                    .HasDefaultValueSql("nextval('wma_m_wage_arreartype_seq'::regclass)");

                entity.Property(e => e.Arreartype)
                    .HasMaxLength(50)
                    .HasColumnName("arreartype");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");
            });

            modelBuilder.Entity<WmaMWageDeduction>(entity =>
            {
                entity.HasKey(e => e.Deductionid)
                    .HasName("pk__wma_m_wa__e2604c57c36a9046");

                entity.ToTable("wma_m_wage_deduction");

                entity.Property(e => e.Deductionid)
                    .HasColumnName("deductionid")
                    .HasDefaultValueSql("nextval('wma_m_wage_deduction_seq'::regclass)");

                entity.Property(e => e.Countryid).HasColumnName("countryid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Esic)
                    .HasPrecision(4, 2)
                    .HasColumnName("esic");

                entity.Property(e => e.Fromdate)
                    .HasPrecision(3)
                    .HasColumnName("fromdate");

                entity.Property(e => e.Incometax)
                    .HasPrecision(4, 2)
                    .HasColumnName("incometax");

                entity.Property(e => e.Insurance)
                    .HasPrecision(4, 2)
                    .HasColumnName("insurance");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Others)
                    .HasPrecision(4, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Pf)
                    .HasPrecision(4, 2)
                    .HasColumnName("pf");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Recoveries)
                    .HasPrecision(4, 2)
                    .HasColumnName("recoveries");

                entity.Property(e => e.Society)
                    .HasPrecision(4, 2)
                    .HasColumnName("society");

                entity.Property(e => e.Todate)
                    .HasPrecision(3)
                    .HasColumnName("todate");
            });

            modelBuilder.Entity<WmaMWageDeductionhistory>(entity =>
            {
                entity.HasKey(e => e.Deductionhistoryid)
                    .HasName("wma_m_wage_deductionhistory_pkey");

                entity.ToTable("wma_m_wage_deductionhistory");

                entity.Property(e => e.Deductionhistoryid)
                    .HasColumnName("deductionhistoryid")
                    .HasDefaultValueSql("nextval('wma_m_wage_deductionhistory_seq'::regclass)");

                entity.Property(e => e.Countryid).HasColumnName("countryid");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Deductionid).HasColumnName("deductionid");

                entity.Property(e => e.Esic)
                    .HasPrecision(4, 2)
                    .HasColumnName("esic");

                entity.Property(e => e.Fromdate)
                    .HasPrecision(3)
                    .HasColumnName("fromdate");

                entity.Property(e => e.Incometax)
                    .HasPrecision(4, 2)
                    .HasColumnName("incometax");

                entity.Property(e => e.Insurance)
                    .HasPrecision(4, 2)
                    .HasColumnName("insurance");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Migrateddate)
                    .HasPrecision(3)
                    .HasColumnName("migrateddate");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Others)
                    .HasPrecision(4, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Pf)
                    .HasPrecision(4, 2)
                    .HasColumnName("pf");

                entity.Property(e => e.Projectid).HasColumnName("projectid");

                entity.Property(e => e.Recoveries)
                    .HasPrecision(4, 2)
                    .HasColumnName("recoveries");

                entity.Property(e => e.Society)
                    .HasPrecision(4, 2)
                    .HasColumnName("society");

                entity.Property(e => e.Todate)
                    .HasPrecision(3)
                    .HasColumnName("todate");
            });

            modelBuilder.Entity<WmaMWageGovernmenttype>(entity =>
            {
                entity.HasKey(e => e.Typeofgovernmentid)
                    .HasName("wma_m_wage_governmenttype_pkey");

                entity.ToTable("wma_m_wage_governmenttype");

                entity.Property(e => e.Typeofgovernmentid)
                    .HasColumnName("typeofgovernmentid")
                    .HasDefaultValueSql("nextval('wma_m_wage_governmenttype_seq'::regclass)");

                entity.Property(e => e.Countryid).HasColumnName("countryid");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Typeofgovernment)
                    .HasMaxLength(50)
                    .HasColumnName("typeofgovernment");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.WmaMWageGovernmenttypes)
                    .HasForeignKey(d => d.Countryid)
                    .HasConstraintName("fk_wma_m_wage_governmenttype_wma_m_country");
            });

            modelBuilder.Entity<WmaMWageHolidaytypemst>(entity =>
            {
                entity.ToTable("wma_m_wage_holidaytypemst");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_m_wage_holidaytypemst_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createdon)
                    .HasPrecision(3)
                    .HasColumnName("createdon");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifiedon)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon");

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .HasColumnName("type");
            });

            modelBuilder.Entity<WmaMWageMinwage>(entity =>
            {
                entity.HasKey(e => e.Wageid)
                    .HasName("pk__wma_m_wa__6cdf5eaafbdea0d3");

                entity.ToTable("wma_m_wage_minwage");

                entity.Property(e => e.Wageid)
                    .HasColumnName("wageid")
                    .HasDefaultValueSql("nextval('wma_m_wage_minwage_seq'::regclass)");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Natureofworkid).HasColumnName("natureofworkid");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Tradecategoryid).HasColumnName("tradecategoryid");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");

                entity.Property(e => e.Tradelevelid).HasColumnName("tradelevelid");

                entity.Property(e => e.Zonemappingid).HasColumnName("zonemappingid");

                entity.HasOne(d => d.Natureofwork)
                    .WithMany(p => p.WmaMWageMinwages)
                    .HasForeignKey(d => d.Natureofworkid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_wage_minwage_wma_m_wage_natureofwork");

                entity.HasOne(d => d.Tradecategory)
                    .WithMany(p => p.WmaMWageMinwages)
                    .HasForeignKey(d => d.Tradecategoryid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_wage_minwage_wma_m_skillcategories");

                entity.HasOne(d => d.Trade)
                    .WithMany(p => p.WmaMWageMinwages)
                    .HasForeignKey(d => d.Tradeid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_wage_minwage_wma_m_trades");

                entity.HasOne(d => d.Tradelevel)
                    .WithMany(p => p.WmaMWageMinwages)
                    .HasForeignKey(d => d.Tradelevelid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_wma_m_wage_minwage_wma_m_skilllevels");
            });

            modelBuilder.Entity<WmaMWageMinwagehistory>(entity =>
            {
                entity.HasKey(e => e.Wagehistoryid)
                    .HasName("pk__wma_m_wa__9bbb73d7019fecbf");

                entity.ToTable("wma_m_wage_minwagehistory");

                entity.Property(e => e.Wagehistoryid)
                    .HasColumnName("wagehistoryid")
                    .HasDefaultValueSql("nextval('wma_m_wage_minwagehistory_seq'::regclass)");

                entity.Property(e => e.Basicwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("basicwage");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Da)
                    .HasPrecision(10, 2)
                    .HasColumnName("da");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Historycreatedon)
                    .HasPrecision(3)
                    .HasColumnName("historycreatedon");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Others)
                    .HasPrecision(10, 2)
                    .HasColumnName("others");

                entity.Property(e => e.Wageid).HasColumnName("wageid");
            });

            modelBuilder.Entity<WmaMWageNatureofwork>(entity =>
            {
                entity.HasKey(e => e.Natureofworkid)
                    .HasName("wma_m_wage_natureofwork_pkey");

                entity.ToTable("wma_m_wage_natureofwork");

                entity.Property(e => e.Natureofworkid)
                    .HasColumnName("natureofworkid")
                    .HasDefaultValueSql("nextval('wma_m_wage_natureofwork_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Natureofwork)
                    .HasMaxLength(100)
                    .HasColumnName("natureofwork");
            });

            modelBuilder.Entity<WmaMWageSitecomponentMst>(entity =>
            {
                entity.HasKey(e => e.Componentid)
                    .HasName("pk_wma_m_wage_deductiblefromcomponent");

                entity.ToTable("wma_m_wage_sitecomponent_mst");

                entity.Property(e => e.Componentid)
                    .HasColumnName("componentid")
                    .HasDefaultValueSql("nextval('wma_m_wage_sitecomponent_mst_seq'::regclass)");

                entity.Property(e => e.Componentname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("componentname");

                entity.Property(e => e.CreatedBy).HasColumnName("created_by");

                entity.Property(e => e.CreatedOn)
                    .HasPrecision(3)
                    .HasColumnName("created_on");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Isstandardcomponent).HasColumnName("isstandardcomponent");

                entity.Property(e => e.ModifiedOn)
                    .HasPrecision(3)
                    .HasColumnName("modified_on");

                entity.Property(e => e.ModififiedBy).HasColumnName("modifified_by");

                entity.Property(e => e.Projectid).HasColumnName("projectid");
            });

            modelBuilder.Entity<WmaMWageSundayworkingtrademst>(entity =>
            {
                entity.ToTable("wma_m_wage_sundayworkingtrademst");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasDefaultValueSql("nextval('wma_m_wage_sundayworkingtrademst_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Tradeid).HasColumnName("tradeid");
            });

            modelBuilder.Entity<WmaMWageTempminwagehistory>(entity =>
            {
                entity.HasKey(e => e.Wagetemphistoryid)
                    .HasName("pk__wma_m_wa__390a7dfcf973eefd");

                entity.ToTable("wma_m_wage_tempminwagehistory");

                entity.Property(e => e.Wagetemphistoryid)
                    .HasColumnName("wagetemphistoryid")
                    .HasDefaultValueSql("nextval('wma_m_wage_tempminwagehistory_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Effectfrom)
                    .HasPrecision(3)
                    .HasColumnName("effectfrom");

                entity.Property(e => e.Effecttill)
                    .HasPrecision(3)
                    .HasColumnName("effecttill");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Newda)
                    .HasPrecision(10, 2)
                    .HasColumnName("newda");

                entity.Property(e => e.Newothers)
                    .HasPrecision(10, 2)
                    .HasColumnName("newothers");

                entity.Property(e => e.Newwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("newwage");

                entity.Property(e => e.Oldda)
                    .HasPrecision(10, 2)
                    .HasColumnName("oldda");

                entity.Property(e => e.Oldeffectfrom)
                    .HasPrecision(3)
                    .HasColumnName("oldeffectfrom");

                entity.Property(e => e.Oldeffecttill)
                    .HasPrecision(3)
                    .HasColumnName("oldeffecttill");

                entity.Property(e => e.Oldothers)
                    .HasPrecision(10, 2)
                    .HasColumnName("oldothers");

                entity.Property(e => e.Oldwage)
                    .HasPrecision(10, 2)
                    .HasColumnName("oldwage");

                entity.Property(e => e.Wageid).HasColumnName("wageid");

                entity.Property(e => e.Zonemappingid).HasColumnName("zonemappingid");
            });

            modelBuilder.Entity<WmaMWageZone>(entity =>
            {
                entity.HasKey(e => e.Zoneid)
                    .HasName("wma_m_wage_zone_pkey");

                entity.ToTable("wma_m_wage_zone");

                entity.Property(e => e.Zoneid)
                    .HasColumnName("zoneid")
                    .HasDefaultValueSql("nextval('wma_m_wage_zone_seq'::regclass)");

                entity.Property(e => e.Createdby).HasColumnName("createdby");

                entity.Property(e => e.Createddate)
                    .HasPrecision(3)
                    .HasColumnName("createddate");

                entity.Property(e => e.Isactive).HasColumnName("isactive");

                entity.Property(e => e.Modifiedby).HasColumnName("modifiedby");

                entity.Property(e => e.Modifieddate)
                    .HasPrecision(3)
                    .HasColumnName("modifieddate");

                entity.Property(e => e.Zonename)
                    .HasMaxLength(50)
                    .HasColumnName("zonename");
            });

            modelBuilder.Entity<WmaMWorkerdetailsection>(entity =>
            {
                entity.HasKey(e => e.WdsId)
                    .HasName("pk__wma_m_workerdetailsection__a498aa44ce1cd541");

                entity.ToTable("wma_m_workerdetailsection");

                entity.Property(e => e.WdsId)
                    .HasColumnName("wds_id")
                    .HasDefaultValueSql("nextval('wma_m_workerdetailsection_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.Wdscode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("wdscode");

                entity.Property(e => e.Wdsdescription)
                    .HasMaxLength(100)
                    .HasColumnName("wdsdescription");
            });

            modelBuilder.Entity<WmaMWorkershift>(entity =>
            {
                entity.HasKey(e => e.WorkershiftId)
                    .HasName("pk_wma_m_workershift");

                entity.ToTable("wma_m_workershift");

                entity.Property(e => e.WorkershiftId)
                    .HasColumnName("workershift_id")
                    .HasDefaultValueSql("nextval('wma_m_workershift_seq'::regclass)");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt)
                    .HasPrecision(3)
                    .HasColumnName("createdon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.IsactiveBt)
                    .IsRequired()
                    .HasColumnName("isactive_bt")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.MarginendtimeT)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("marginendtime_t");

                entity.Property(e => e.MarginstarttimeT)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("marginstarttime_t");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt)
                    .HasPrecision(3)
                    .HasColumnName("modifiedon_dt")
                    .HasDefaultValueSql("NULL::timestamp without time zone");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ShiftCode)
                    .HasMaxLength(10)
                    .HasColumnName("shift_code");

                entity.Property(e => e.ShiftendtimeT)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("shiftendtime_t");

                entity.Property(e => e.ShiftstarttimeT)
                    .HasColumnType("time(6) without time zone")
                    .HasColumnName("shiftstarttime_t");

                entity.Property(e => e.WorkershiftVc)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("workershift_vc");
            });

            modelBuilder.Entity<WmaMZone>(entity =>
            {
                entity.HasKey(e => e.ZoneId)
                    .HasName("wma_m_zone_pkey");

                entity.ToTable("wma_m_zone");

                entity.HasIndex(e => e.ZonecodeVc, "wma_m_zone_zonecode_vc_key")
                    .IsUnique();

                entity.HasIndex(e => e.ZonedescVc, "wma_m_zone_zonedesc_vc_key")
                    .IsUnique();

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");

                entity.Property(e => e.CreatedbyId).HasColumnName("createdby_id");

                entity.Property(e => e.CreatedonDt).HasColumnName("createdon_dt");

                entity.Property(e => e.IsactiveBt).HasColumnName("isactive_bt");

                entity.Property(e => e.ModifiedbyId).HasColumnName("modifiedby_id");

                entity.Property(e => e.ModifiedonDt).HasColumnName("modifiedon_dt");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ZonecodeVc)
                    .HasMaxLength(100)
                    .HasColumnName("zonecode_vc");

                entity.Property(e => e.ZonedescVc)
                    .HasMaxLength(100)
                    .HasColumnName("zonedesc_vc");

                entity.Property(e => e.ZonetypeId).HasColumnName("zonetype_id");
            });

            modelBuilder.Entity<Wrongempdatum>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("wrongempdata");

                entity.Property(e => e.Eipid).HasColumnName("eipid");

                entity.Property(e => e.RemarksVc)
                    .HasMaxLength(50)
                    .HasColumnName("remarks_vc");
            });

            modelBuilder.HasSequence("kyc_dummydoc_seq");

            modelBuilder.HasSequence("tbltriggertest_seq");

            modelBuilder.HasSequence("testworkflow_seq");

            modelBuilder.HasSequence("wisa_f_airesult_seq");

            modelBuilder.HasSequence("wisa_f_uploadedimagedetails_seq");

            modelBuilder.HasSequence("wisa_l_awslog_seq");

            modelBuilder.HasSequence("wisa_m_worker_seq");

            modelBuilder.HasSequence("wma_f_apirequestresponsedetails_seq");

            modelBuilder.HasSequence("wma_f_appreciation_seq");

            modelBuilder.HasSequence("wma_f_awsfacerecognitiontransaction_seq");

            modelBuilder.HasSequence("wma_f_awsrequestresponsedetail_seq");

            modelBuilder.HasSequence("wma_f_biometricdata_seq");

            modelBuilder.HasSequence("wma_f_biometricdata_temp_seq");

            modelBuilder.HasSequence("wma_f_biometricdatajunkdata_seq");

            modelBuilder.HasSequence("wma_f_biometricfilelog_seq");

            modelBuilder.HasSequence("wma_f_biometricscheduler_seq");

            modelBuilder.HasSequence("wma_f_blacklist_seq");

            modelBuilder.HasSequence("wma_f_checklistquestionsresponse_seq");

            modelBuilder.HasSequence("wma_f_checklistquestionsresponsehistory_seq");

            modelBuilder.HasSequence("wma_f_compliancedetails_seq");

            modelBuilder.HasSequence("wma_f_coviddocumentmap_seq");

            modelBuilder.HasSequence("wma_f_covidvaccinationdetails_seq");

            modelBuilder.HasSequence("wma_f_eipapirequestresponsedetail_seq");

            modelBuilder.HasSequence("wma_f_idexpirycountbyproject_seq");

            modelBuilder.HasSequence("wma_f_logtrace_seq");

            modelBuilder.HasSequence("wma_f_longabsenceworkerid_seq");

            modelBuilder.HasSequence("wma_f_maillog_seq");

            modelBuilder.HasSequence("wma_f_medicalchecklistquestionsresponse_seq");

            modelBuilder.HasSequence("wma_f_medicalchecklistquestionsresponsehistory_seq");

            modelBuilder.HasSequence("wma_f_noticeboarddetail_seq");

            modelBuilder.HasSequence("wma_f_noticeboarddetailhistory_seq");

            modelBuilder.HasSequence("wma_f_noticeboarddocumentsmap_seq");

            modelBuilder.HasSequence("wma_f_noticeboardrolecategorymap_seq");

            modelBuilder.HasSequence("wma_f_rankingchecklistquestionsresponse_seq");

            modelBuilder.HasSequence("wma_f_rankingchecklistquestionsresponsehistory_seq");

            modelBuilder.HasSequence("wma_f_releaserequest_seq");

            modelBuilder.HasSequence("wma_f_releaserequesthistory_seq");

            modelBuilder.HasSequence("wma_f_subcontractorselfdeclaration_seq");

            modelBuilder.HasSequence("wma_f_tra_projecttrainingdetails_seq");

            modelBuilder.HasSequence("wma_f_tra_projecttrainingdetailshistory_seq");

            modelBuilder.HasSequence("wma_f_tra_training_seq");

            modelBuilder.HasSequence("wma_f_wage_arrear_seq");

            modelBuilder.HasSequence("wma_f_wage_arrearprocesslog_seq");

            modelBuilder.HasSequence("wma_f_wage_arrearworkersitelevelcompdetail_seq");

            modelBuilder.HasSequence("wma_f_wage_attendanceregularisation_seq");

            modelBuilder.HasSequence("wma_f_wage_bonusdetail_seq");

            modelBuilder.HasSequence("wma_f_wage_componentsdeductiblefrommap_seq");

            modelBuilder.HasSequence("wma_f_wage_fullandfinalsettlement_seq");

            modelBuilder.HasSequence("wma_f_wage_holidaycalendar_seq");

            modelBuilder.HasSequence("wma_f_wage_otregularisation_seq");

            modelBuilder.HasSequence("wma_f_wage_processedbonusdetail_seq");

            modelBuilder.HasSequence("wma_f_wage_sitelevelcomponents_seq");

            modelBuilder.HasSequence("wma_f_wage_wageprocesslog_seq");

            modelBuilder.HasSequence("wma_f_wage_workersitelevelcompdetail_seq");

            modelBuilder.HasSequence("wma_f_wage_workerwageapproval_seq");

            modelBuilder.HasSequence("wma_f_wage_workerwagemapping_seq");

            modelBuilder.HasSequence("wma_f_wage_workerwagemappinghistory_seq");

            modelBuilder.HasSequence("wma_f_wage_workerwageprocess_seq");

            modelBuilder.HasSequence("wma_f_wagehistory_seq");

            modelBuilder.HasSequence("wma_f_workerattachments_seq");

            modelBuilder.HasSequence("wma_f_workerattendance_seq");

            modelBuilder.HasSequence("wma_f_workercovid19map_seq");

            modelBuilder.HasSequence("wma_f_workercovid19maphistory_seq");

            modelBuilder.HasSequence("wma_f_workerdata_seq");

            modelBuilder.HasSequence("wma_f_workerdatahistory_seq");

            modelBuilder.HasSequence("wma_f_workerjunkattendance_seq");

            modelBuilder.HasSequence("wma_f_workerleaveattachments_seq");

            modelBuilder.HasSequence("wma_f_workerleavebalance_seq");

            modelBuilder.HasSequence("wma_f_workerleavebalancehistory_seq");

            modelBuilder.HasSequence("wma_f_workerleavedetail_seq");

            modelBuilder.HasSequence("wma_f_workerobservationdetails_seq");

            modelBuilder.HasSequence("wma_f_workerranking_seq");

            modelBuilder.HasSequence("wma_f_workerrankinghistory_seq");

            modelBuilder.HasSequence("wma_f_workerselfdeclarationmap_seq");

            modelBuilder.HasSequence("wma_f_workerselfdeclarationmaphistory_seq");

            modelBuilder.HasSequence("wma_f_workertravellinghistory_seq");

            modelBuilder.HasSequence("wma_f_workervitals_seq");

            modelBuilder.HasSequence("wma_f_workervitalshistroy_seq");

            modelBuilder.HasSequence("wma_f_workflow_seq");

            modelBuilder.HasSequence("wma_f_workflowhistory_seq");

            modelBuilder.HasSequence("wma_l_activityprojectrolemapping_seq");

            modelBuilder.HasSequence("wma_l_adminuserprojectlevelaccess_seq");

            modelBuilder.HasSequence("wma_l_adminuserprojectlevelaccesshistory_seq");

            modelBuilder.HasSequence("wma_l_certificationdetails_seq");

            modelBuilder.HasSequence("wma_l_checklistfortestvalidity_seq");

            modelBuilder.HasSequence("wma_l_checklistfortestvalidityhistory_seq");

            modelBuilder.HasSequence("wma_l_checklistquesresponsetypemap_seq");

            modelBuilder.HasSequence("wma_l_checklistquestiongroupmap_seq");

            modelBuilder.HasSequence("wma_l_checklistquestionsmap_seq");

            modelBuilder.HasSequence("wma_l_checklisttraderoleapprovalmap_seq");

            modelBuilder.HasSequence("wma_l_educationdetails_seq");

            modelBuilder.HasSequence("wma_l_emailutilizationprojectrolemapping_seq");

            modelBuilder.HasSequence("wma_l_experience_seq");

            modelBuilder.HasSequence("wma_l_gang_gangdivisionmapping_seq");

            modelBuilder.HasSequence("wma_l_gang_workergangmapping_seq");

            modelBuilder.HasSequence("wma_l_genericmessages_seq");

            modelBuilder.HasSequence("wma_l_labourcolony_workerroommapping_seq");

            modelBuilder.HasSequence("wma_l_labourcolony_workerroommappinghistory_seq");

            modelBuilder.HasSequence("wma_l_menumapping_seq");

            modelBuilder.HasSequence("wma_l_mobilelogin_otp_seq");

            modelBuilder.HasSequence("wma_l_observationmapping_seq");

            modelBuilder.HasSequence("wma_l_project_medicalperiodicchecklistmapping_seq");

            modelBuilder.HasSequence("wma_l_projectattachments_seq");

            modelBuilder.HasSequence("wma_l_projectchecklistmap_seq");

            modelBuilder.HasSequence("wma_l_projectfeaturemapping_seq");

            modelBuilder.HasSequence("wma_l_projectrlsworkflowmap_seq");

            modelBuilder.HasSequence("wma_l_projectrlsworkflowmaptest1_seq");

            modelBuilder.HasSequence("wma_l_projectscompoundgroupmapping_seq");

            modelBuilder.HasSequence("wma_l_projectvincensemapping_seq");

            modelBuilder.HasSequence("wma_l_projectworkerevaluationchecklistmapping_seq");

            modelBuilder.HasSequence("wma_l_projectworkflowmap_seq");

            modelBuilder.HasSequence("wma_l_questiongrouptrademap_seq");

            modelBuilder.HasSequence("wma_l_roletradegroupmapping_seq");

            modelBuilder.HasSequence("wma_l_tra_projecttrainingattachments_seq");

            modelBuilder.HasSequence("wma_l_tra_projecttrainingattendance_seq");

            modelBuilder.HasSequence("wma_l_tra_projecttrainingconcernedusersmapping_seq");

            modelBuilder.HasSequence("wma_l_tra_projecttrainingfacultymapping_seq");

            modelBuilder.HasSequence("wma_l_tra_projecttrainingsubcontractormapping_seq");

            modelBuilder.HasSequence("wma_l_tra_trainingcategoyrolemapping_seq");

            modelBuilder.HasSequence("wma_l_tra_trainingtrademap_seq");

            modelBuilder.HasSequence("wma_l_useradminrolemap_seq");

            modelBuilder.HasSequence("wma_l_userprojectrolemap_seq");

            modelBuilder.HasSequence("wma_l_usertradeapprovermap_seq");

            modelBuilder.HasSequence("wma_l_usertreemap_seq");

            modelBuilder.HasSequence("wma_l_wage_workerwageprocessarrearmapping_seq");

            modelBuilder.HasSequence("wma_l_wage_workerwageprocessed_seq");

            modelBuilder.HasSequence("wma_l_wage_zonemapping_seq");

            modelBuilder.HasSequence("wma_l_workerbankdetails_seq");

            modelBuilder.HasSequence("wma_l_workerkyc_seq");

            modelBuilder.HasSequence("wma_l_workerkycdocuments_seq");

            modelBuilder.HasSequence("wma_l_workerprojecttradedetails_seq");

            modelBuilder.HasSequence("wma_l_workerprojecttradedetailshistory_seq");

            modelBuilder.HasSequence("wma_m_activity_seq");

            modelBuilder.HasSequence("wma_m_apiconfigdetails_seq");

            modelBuilder.HasSequence("wma_m_apkversionlog_seq");

            modelBuilder.HasSequence("wma_m_awscompanymap_seq");

            modelBuilder.HasSequence("wma_m_bu_seq");

            modelBuilder.HasSequence("wma_m_certificatetype_seq");

            modelBuilder.HasSequence("wma_m_checklist_seq");

            modelBuilder.HasSequence("wma_m_checklisttype_category_seq");

            modelBuilder.HasSequence("wma_m_city_seq");

            modelBuilder.HasSequence("wma_m_cluster_seq");

            modelBuilder.HasSequence("wma_m_compoundgroups_seq");

            modelBuilder.HasSequence("wma_m_country_seq");

            modelBuilder.HasSequence("wma_m_coviddose_seq");

            modelBuilder.HasSequence("wma_m_days_seq");

            modelBuilder.HasSequence("wma_m_district_seq");

            modelBuilder.HasSequence("wma_m_emailutilization_seq");

            modelBuilder.HasSequence("wma_m_employmenttype_seq");

            modelBuilder.HasSequence("wma_m_exams_seq");

            modelBuilder.HasSequence("wma_m_familydetails_seq");

            modelBuilder.HasSequence("wma_m_features_seq");

            modelBuilder.HasSequence("wma_m_gang_gangs_seq");

            modelBuilder.HasSequence("wma_m_gang_projectdivision_seq");

            modelBuilder.HasSequence("wma_m_gang_subdivision_seq");

            modelBuilder.HasSequence("wma_m_govermenttype_seq");

            modelBuilder.HasSequence("wma_m_ic_seq");

            modelBuilder.HasSequence("wma_m_idproof_seq");

            modelBuilder.HasSequence("wma_m_labourcolony_buildings_seq");

            modelBuilder.HasSequence("wma_m_labourcolony_floors_seq");

            modelBuilder.HasSequence("wma_m_labourcolony_rooms_seq");

            modelBuilder.HasSequence("wma_m_languages_seq");

            modelBuilder.HasSequence("wma_m_licensetype_seq");

            modelBuilder.HasSequence("wma_m_mainmenu_seq");

            modelBuilder.HasSequence("wma_m_maritalstatus_seq");

            modelBuilder.HasSequence("wma_m_noticeboardcategory_seq");

            modelBuilder.HasSequence("wma_m_noticeboardsubcategory_seq");

            modelBuilder.HasSequence("wma_m_observationcategory_seq");

            modelBuilder.HasSequence("wma_m_observationsubcategory_seq");

            modelBuilder.HasSequence("wma_m_projects_seq");

            modelBuilder.HasSequence("wma_m_ranking_seq");

            modelBuilder.HasSequence("wma_m_referredbydetails_seq");

            modelBuilder.HasSequence("wma_m_releasecomments_seq");

            modelBuilder.HasSequence("wma_m_responsetype_seq");

            modelBuilder.HasSequence("wma_m_roles_seq");

            modelBuilder.HasSequence("wma_m_sbg_seq");

            modelBuilder.HasSequence("wma_m_sections_seq");

            modelBuilder.HasSequence("wma_m_sectionsubproject_seq");

            modelBuilder.HasSequence("wma_m_segment_seq");

            modelBuilder.HasSequence("wma_m_skill_seq");

            modelBuilder.HasSequence("wma_m_skillcategories_seq");

            modelBuilder.HasSequence("wma_m_skilllevels_seq");

            modelBuilder.HasSequence("wma_m_state_seq");

            modelBuilder.HasSequence("wma_m_status_seq");

            modelBuilder.HasSequence("wma_m_submenu_seq");

            modelBuilder.HasSequence("wma_m_subprojectjoineip_seq");

            modelBuilder.HasSequence("wma_m_thirdpartyusers_seq");

            modelBuilder.HasSequence("wma_m_tokenmanager_seq");

            modelBuilder.HasSequence("wma_m_tra_trainingcategory_seq");

            modelBuilder.HasSequence("wma_m_tra_trainingmodes_seq");

            modelBuilder.HasSequence("wma_m_tra_trainingtypes_seq");

            modelBuilder.HasSequence("wma_m_tradegroup_seq");

            modelBuilder.HasSequence("wma_m_trades_seq");

            modelBuilder.HasSequence("wma_m_tradesubgroup_seq");

            modelBuilder.HasSequence("wma_m_training_seq");

            modelBuilder.HasSequence("wma_m_uanmaster_seq");

            modelBuilder.HasSequence("wma_m_user_seq");

            modelBuilder.HasSequence("wma_m_userhistory_seq");

            modelBuilder.HasSequence("wma_m_wage_arreartype_seq");

            modelBuilder.HasSequence("wma_m_wage_deduction_seq");

            modelBuilder.HasSequence("wma_m_wage_deductionhistory_seq");

            modelBuilder.HasSequence("wma_m_wage_governmenttype_seq");

            modelBuilder.HasSequence("wma_m_wage_holidaytypemst_seq");

            modelBuilder.HasSequence("wma_m_wage_minwage_seq");

            modelBuilder.HasSequence("wma_m_wage_minwagehistory_seq");

            modelBuilder.HasSequence("wma_m_wage_natureofwork_seq");

            modelBuilder.HasSequence("wma_m_wage_sitecomponent_mst_seq");

            modelBuilder.HasSequence("wma_m_wage_sundayworkingtrademst_seq");

            modelBuilder.HasSequence("wma_m_wage_tempminwagehistory_seq");

            modelBuilder.HasSequence("wma_m_wage_zone_seq");

            modelBuilder.HasSequence("wma_m_workerdetailsection_seq");

            modelBuilder.HasSequence("wma_m_workershift_seq");

            modelBuilder.HasSequence("wma_m_zone_seq");

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
