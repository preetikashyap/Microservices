﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkerleaveattachment
    {
        public long Attachmentid { get; set; }
        public string Workerattachmentname { get; set; }
        public string Workerattachmenturl { get; set; }
        public string Workerattachmentformat { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }
        public bool Isactive { get; set; }
    }
}
