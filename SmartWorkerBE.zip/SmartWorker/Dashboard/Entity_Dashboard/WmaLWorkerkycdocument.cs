﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWorkerkycdocument
    {
        public int KycId { get; set; }
        public long? WorkerId { get; set; }
        public int? IdproofId { get; set; }
        public string IdproofvalueVc { get; set; }
        public DateTime? IssuedonDt { get; set; }
        public DateTime? ExpiryonDt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? IsactiveBt { get; set; }

        public virtual WmaMIdproof Idproof { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
