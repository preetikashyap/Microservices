﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMAwscompanymap
    {
        public long Id { get; set; }
        public string Companycode { get; set; }
        public string Description { get; set; }
        public bool? Isbucketcreated { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createdon { get; set; }
    }
}
