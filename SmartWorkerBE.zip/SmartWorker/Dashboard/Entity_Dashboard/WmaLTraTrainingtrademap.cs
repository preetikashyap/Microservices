﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLTraTrainingtrademap
    {
        public int TrainingtrademapId { get; set; }
        public int? TradeId { get; set; }
        public int? TrainingId { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual WmaMTrade Trade { get; set; }
        public virtual WmaFTraTraining Training { get; set; }
    }
}
