﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFBiometricdatum
    {
        public int BiometricdataId { get; set; }
        public string JobcodeVc { get; set; }
        public int? MachineId { get; set; }
        public DateTime? PunchedonDt { get; set; }
        public long? EipId { get; set; }
        public string PunchingtypeVc { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? BiometricfilelogId { get; set; }
        public string OrginaltextVc { get; set; }
        public string ErrordataVc { get; set; }
        public bool? AttendancestatusBt { get; set; }

        public virtual WmaFBiometricfilelog Biometricfilelog { get; set; }
    }
}
