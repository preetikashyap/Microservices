﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMIc
    {
        public WmaMIc()
        {
            WmaLUsertreemaps = new HashSet<WmaLUsertreemap>();
            WmaMProjects = new HashSet<WmaMProject>();
            WmaMSbgs = new HashSet<WmaMSbg>();
        }

        public int IcId { get; set; }
        public string IccodeVc { get; set; }
        public string IcshortnameVc { get; set; }
        public string IcnameVc { get; set; }
        public string EipcompanycodeVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
        public virtual ICollection<WmaMProject> WmaMProjects { get; set; }
        public virtual ICollection<WmaMSbg> WmaMSbgs { get; set; }
    }
}
