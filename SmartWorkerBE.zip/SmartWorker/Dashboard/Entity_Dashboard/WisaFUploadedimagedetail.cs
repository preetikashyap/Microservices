﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WisaFUploadedimagedetail
    {
        public long TransactionId { get; set; }
        public string Uid { get; set; }
        public DateTime? UploaddatetimeDt { get; set; }
        public string UploadedimageVc { get; set; }
        public int? StatusBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
