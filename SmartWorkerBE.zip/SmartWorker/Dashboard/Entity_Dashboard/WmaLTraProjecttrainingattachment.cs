﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLTraProjecttrainingattachment
    {
        public long ProjecttrainingattachmentId { get; set; }
        public string AttachmentName { get; set; }
        public string AttachmentType { get; set; }
        public string AttachmentUrl { get; set; }
        public long? ProjecttrainingId { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual WmaFTraProjecttrainingdetail Projecttraining { get; set; }
    }
}
