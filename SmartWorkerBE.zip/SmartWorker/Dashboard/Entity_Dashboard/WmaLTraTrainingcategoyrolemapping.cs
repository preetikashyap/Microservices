﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLTraTrainingcategoyrolemapping
    {
        public long TrainingcategoyrolemapId { get; set; }
        public long RoleId { get; set; }
        public int TrainingcategoryId { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMRole Role { get; set; }
        public virtual WmaMTraTrainingcategory Trainingcategory { get; set; }
    }
}
