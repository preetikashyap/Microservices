﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWageComponentsdeductiblefrommap
    {
        public long Id { get; set; }
        public long CompTxnId { get; set; }
        public int Componentid { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }

        public virtual WmaFWageSitelevelcomponent CompTxn { get; set; }
        public virtual WmaMWageSitecomponentMst Component { get; set; }
    }
}
