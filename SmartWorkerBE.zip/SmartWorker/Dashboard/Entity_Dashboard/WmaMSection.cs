﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMSection
    {
        public int SectionId { get; set; }
        public int? ProjectId { get; set; }
        public string Sectioncode { get; set; }
        public string Sectionname { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
