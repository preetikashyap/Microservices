﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkertravellinghistory
    {
        public long Workertravelhistoryid { get; set; }
        public long Workerid { get; set; }
        public int Stateid { get; set; }
        public int Districtid { get; set; }
        public DateTime? Date { get; set; }
        public int? Geospatialstatusid { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public virtual WmaMGeospatialstatus Geospatialstatus { get; set; }
        public virtual WmaMState State { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
