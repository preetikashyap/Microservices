﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFAppreciation
    {
        public int WorkerappreciationId { get; set; }
        public long? WorkerId { get; set; }
        public int? AppreciationcategoryId { get; set; }
        public int? AppreciationsubcategoryId { get; set; }
        public string AppreciationdescriptionVc { get; set; }
        public DateTime? AppreciatingonDt { get; set; }
        public int? AppreciatedbyId { get; set; }
        public bool? IsactieBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? ProjectId { get; set; }

        public virtual WmaMObservationcategory Appreciationcategory { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
