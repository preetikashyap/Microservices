﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMEmploymenttype
    {
        public WmaMEmploymenttype()
        {
            WmaFWorkerdata = new HashSet<WmaFWorkerdatum>();
        }

        public int EmploymenttypeId { get; set; }
        public string EmploymenttypedescVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string EmploymentcodeVc { get; set; }

        public virtual ICollection<WmaFWorkerdatum> WmaFWorkerdata { get; set; }
    }
}
