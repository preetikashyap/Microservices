﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWorkerkyc
    {
        public long WorkerkycId { get; set; }
        public long WorkerId { get; set; }
        public string PanNoVc { get; set; }
        public string DlNoVc { get; set; }
        public string RationcardnoVc { get; set; }
        public string VoteridVc { get; set; }
        public string PassportnoVc { get; set; }
        public DateTime? PassportvalidityDt { get; set; }
        public string NationalpopulationregVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string NidNoVc { get; set; }
        public string BirthcertificateVc { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
