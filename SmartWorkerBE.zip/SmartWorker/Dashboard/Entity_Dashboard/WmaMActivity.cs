﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMActivity
    {
        public WmaMActivity()
        {
            WmaLActivityprojectrolemappings = new HashSet<WmaLActivityprojectrolemapping>();
        }

        public int ActivityId { get; set; }
        public string ActivityVc { get; set; }
        public string ActivityCode { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }

        public virtual ICollection<WmaLActivityprojectrolemapping> WmaLActivityprojectrolemappings { get; set; }
    }
}
