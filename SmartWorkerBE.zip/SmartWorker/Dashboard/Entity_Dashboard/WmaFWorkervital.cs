﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkervital
    {
        public long WorkervitalsId { get; set; }
        public long WorkerId { get; set; }
        public string TimeVc { get; set; }
        public string DateVc { get; set; }
        public string PulseVc { get; set; }
        public string Spo2Vc { get; set; }
        public string RrVc { get; set; }
        public string SkintempVc { get; set; }
        public string SystolicVc { get; set; }
        public string DiastolicVc { get; set; }
        public string SugarVc { get; set; }
        public string WeightVc { get; set; }
        public string HeightVc { get; set; }
        public string BmiVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
