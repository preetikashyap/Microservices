﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class SmFFrservicelog
    {
        public long FrtransId { get; set; }
        public string Classname { get; set; }
        public string Methodname { get; set; }
        public int? Linenumber { get; set; }
        public string Servicename { get; set; }
        public string Errormsg { get; set; }
        public int? ErrcreatedbyId { get; set; }
        public DateTime? ErrorcreatedDt { get; set; }
    }
}
