﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWorkerselfdeclarationmaphistory
    {
        public long Historyid { get; set; }
        public long Workerselfdeclarationid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public int Sdqid { get; set; }
        public string Value { get; set; }
        public DateTime? Onsetdate { get; set; }
        public string Remarks { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
