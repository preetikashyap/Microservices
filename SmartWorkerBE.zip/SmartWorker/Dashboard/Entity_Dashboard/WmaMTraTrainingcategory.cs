﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMTraTrainingcategory
    {
        public WmaMTraTrainingcategory()
        {
            WmaFTraTrainings = new HashSet<WmaFTraTraining>();
            WmaLTraTrainingcategoyrolemappings = new HashSet<WmaLTraTrainingcategoyrolemapping>();
        }

        public int TrainingcategoryId { get; set; }
        public string TrainingcategoryVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual ICollection<WmaFTraTraining> WmaFTraTrainings { get; set; }
        public virtual ICollection<WmaLTraTrainingcategoyrolemapping> WmaLTraTrainingcategoyrolemappings { get; set; }
    }
}
