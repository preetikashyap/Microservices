﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WisaMWorker
    {
        public long WorkerrunningId { get; set; }
        public long? WisaId { get; set; }
        public string WorkernameVc { get; set; }
        public string WorkerimageVc { get; set; }
        public string FaceidVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
