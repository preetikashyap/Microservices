﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFCoviddocumentmap
    {
        public long Id { get; set; }
        public long Workercovid19detailsid { get; set; }
        public long WorkerId { get; set; }
        public long? WorkerattachmentId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }

        public virtual WmaFWorkerattachment Workerattachment { get; set; }
    }
}
