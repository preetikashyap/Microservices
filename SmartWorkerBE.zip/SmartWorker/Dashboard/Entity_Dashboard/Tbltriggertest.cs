﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class Tbltriggertest
    {
        public int Pkid { get; set; }
        public DateTime? Orderapprovaldatetime { get; set; }
        public string Orderstatus { get; set; }
    }
}
