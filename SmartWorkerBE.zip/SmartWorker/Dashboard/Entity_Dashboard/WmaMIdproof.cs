﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMIdproof
    {
        public WmaMIdproof()
        {
            WmaLWorkerkycdocuments = new HashSet<WmaLWorkerkycdocument>();
        }

        public int IdproofId { get; set; }
        public string IdproofnameVc { get; set; }
        public int? CountryId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string IdvalidationVc { get; set; }
        public bool? DemographicflagBt { get; set; }
        public bool? HasissuedonBt { get; set; }
        public bool? HasexpiryonBt { get; set; }
        public bool? IsrequiredkycBt { get; set; }
        public string IdproofcodeVc { get; set; }

        public virtual WmaMCountry Country { get; set; }
        public virtual ICollection<WmaLWorkerkycdocument> WmaLWorkerkycdocuments { get; set; }
    }
}
