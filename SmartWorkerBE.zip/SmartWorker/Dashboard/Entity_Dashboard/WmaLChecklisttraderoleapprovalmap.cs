﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLChecklisttraderoleapprovalmap
    {
        public long TraderoleapprovalmapId { get; set; }
        public long ChecklistId { get; set; }
        public int? TradeId { get; set; }
        public long? RoleId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMTrade Trade { get; set; }
    }
}
