﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFNoticeboarddocumentsmap
    {
        public long Id { get; set; }
        public long Noticeboardid { get; set; }
        public int Documentid { get; set; }
        public double Revision { get; set; }
        public bool Isactive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public virtual WmaLProjectattachment Document { get; set; }
        public virtual WmaFNoticeboarddetail Noticeboard { get; set; }
    }
}
