﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMApkversionlog
    {
        public int VersionId { get; set; }
        public double? Version { get; set; }
        public DateTime? VersionDate { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string PlatformtypeVc { get; set; }
        public string AppcenterurlVc { get; set; }
    }
}
