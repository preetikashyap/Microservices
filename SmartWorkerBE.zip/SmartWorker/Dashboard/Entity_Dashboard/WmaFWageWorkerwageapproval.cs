﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFWageWorkerwageapproval
    {
        public long Workerwageapprovalid { get; set; }
        public long? Workerid { get; set; }
        public int? Projectid { get; set; }
        public decimal? Requestingwage { get; set; }
        public bool? Isapproved { get; set; }
        public long? Approvedby { get; set; }
        public DateTime? Approvedon { get; set; }
        public bool? Isactive { get; set; }
        public string Remark { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createdon { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public long? Workerwagemappingid { get; set; }
    }
}
