﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWageWorkerwageprocessed
    {
        public long Workerwageprocessedid { get; set; }
        public long Workerwageprocessid { get; set; }
        public long Workerwagemappingid { get; set; }
        public string Vendorcode { get; set; }
        public DateTime Startdate { get; set; }
        public DateTime Enddate { get; set; }
        public int Totalworkingdays { get; set; }
        public int Fr { get; set; }
        public int Qr { get; set; }
        public int Bm { get; set; }
        public decimal Basicwage { get; set; }
        public decimal Da { get; set; }
        public decimal Other { get; set; }
        public decimal? Recommendedwage { get; set; }
        public double Totalbasicwage { get; set; }
        public int Totalothours { get; set; }
        public decimal Totalot { get; set; }
        public decimal Totalarrear { get; set; }
        public decimal? Totalearnings { get; set; }
        public decimal? Pfdeduction { get; set; }
        public decimal? Esci { get; set; }
        public decimal? Society { get; set; }
        public decimal? Incometax { get; set; }
        public decimal? Insurance { get; set; }
        public decimal? Others { get; set; }
        public decimal? Recoveries { get; set; }
        public decimal Totaldeductions { get; set; }
        public decimal Netpayment { get; set; }
        public decimal Pfemployercontribute { get; set; }
        public DateTime Dateofpayment { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }
    }
}
