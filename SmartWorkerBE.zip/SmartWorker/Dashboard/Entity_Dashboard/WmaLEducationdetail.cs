﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLEducationdetail
    {
        public long EducationdetailId { get; set; }
        public long WorkerId { get; set; }
        public int? ExamId { get; set; }
        public int? PassingyearNb { get; set; }
        public string InstitutionnameVc { get; set; }
        public string EducationboardVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMExam Exam { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
