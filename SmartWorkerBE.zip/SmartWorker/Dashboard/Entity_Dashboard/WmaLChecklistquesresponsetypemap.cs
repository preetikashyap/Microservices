﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLChecklistquesresponsetypemap
    {
        public long QuesresponsetypemapId { get; set; }
        public long ChecklistquestionsmapId { get; set; }
        public int ResponsetypeId { get; set; }
        public string AllowableresponseVc { get; set; }
        public long ChecklistId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMChecklist Checklist { get; set; }
        public virtual WmaLChecklistquestionsmap Checklistquestionsmap { get; set; }
        public virtual WmaMResponsetype Responsetype { get; set; }
    }
}
