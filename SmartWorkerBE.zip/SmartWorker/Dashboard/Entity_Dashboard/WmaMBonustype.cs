﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMBonustype
    {
        public WmaMBonustype()
        {
            WmaFWageBonusdetails = new HashSet<WmaFWageBonusdetail>();
        }

        public int Id { get; set; }
        public string Bonustype { get; set; }

        public virtual ICollection<WmaFWageBonusdetail> WmaFWageBonusdetails { get; set; }
    }
}
