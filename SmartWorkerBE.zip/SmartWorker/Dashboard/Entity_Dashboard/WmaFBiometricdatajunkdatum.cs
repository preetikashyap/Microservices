﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFBiometricdatajunkdatum
    {
        public int BiojunkdataId { get; set; }
        public string JunkdataVc { get; set; }
        public long? BiometricfilelogId { get; set; }

        public virtual WmaFBiometricfilelog Biometricfilelog { get; set; }
    }
}
