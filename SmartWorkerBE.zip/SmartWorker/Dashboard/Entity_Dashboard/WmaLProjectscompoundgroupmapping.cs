﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLProjectscompoundgroupmapping
    {
        public long Sno { get; set; }
        public long? Compundgroupid { get; set; }
        public long? Projectid { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public long? CreatedbyId { get; set; }
    }
}
