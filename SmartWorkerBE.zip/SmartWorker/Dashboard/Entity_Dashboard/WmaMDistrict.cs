﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMDistrict
    {
        public int DistrictId { get; set; }
        public string DistrictVc { get; set; }
        public string DistrictCode { get; set; }
        public int StateId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
