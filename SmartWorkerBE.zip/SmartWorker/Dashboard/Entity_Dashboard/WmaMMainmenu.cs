﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMMainmenu
    {
        public WmaMMainmenu()
        {
            WmaLMenumappings = new HashSet<WmaLMenumapping>();
        }

        public int MainmenuId { get; set; }
        public string MainmenucodeVc { get; set; }
        public string MainmenunameVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLMenumapping> WmaLMenumappings { get; set; }
    }
}
