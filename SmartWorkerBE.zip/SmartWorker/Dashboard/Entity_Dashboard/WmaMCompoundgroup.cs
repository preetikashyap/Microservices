﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMCompoundgroup
    {
        public long Compundgroupid { get; set; }
        public string Compoundgroupname { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMCompoundgroup Compundgroup { get; set; }
        public virtual WmaMCompoundgroup InverseCompundgroup { get; set; }
    }
}
