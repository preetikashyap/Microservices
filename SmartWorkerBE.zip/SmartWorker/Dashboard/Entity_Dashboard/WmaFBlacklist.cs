﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaFBlacklist
    {
        public int BlacklistId { get; set; }
        public long WorkerId { get; set; }
        public string ReasonVc { get; set; }
        public long? BlackedfromprojectId { get; set; }
        public string IcadmincommentsVc { get; set; }
        public string BlacklistattachmentnameVc { get; set; }
        public string BlacklistattachmenturlVc { get; set; }
        public string BlaklistattachmentformatVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? ApprovedbyId { get; set; }
        public DateTime? ApprovedonDt { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
