﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMTraTrainingmode
    {
        public int TrainingmodeId { get; set; }
        public string TrainingmodeVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
    }
}
