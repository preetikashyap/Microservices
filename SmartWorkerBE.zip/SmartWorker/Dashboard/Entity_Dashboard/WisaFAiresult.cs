﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WisaFAiresult
    {
        public long Id { get; set; }
        public long? TransactionId { get; set; }
        public long? WorkerrunningId { get; set; }
        public decimal? MatchpercentNb { get; set; }
        public string UploadedimageVc { get; set; }
        public string ReferenceimageVc { get; set; }
        public int? StatusBt { get; set; }
        public string RemarksVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
