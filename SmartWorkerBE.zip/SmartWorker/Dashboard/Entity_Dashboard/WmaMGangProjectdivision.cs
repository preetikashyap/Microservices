﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMGangProjectdivision
    {
        public long ProjectdivisionId { get; set; }
        public string DivisionnameVc { get; set; }
        public string DivisiondescriptionVc { get; set; }
        public long? ProjectId { get; set; }
        public bool? Isactve { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public double? Maxworkdone { get; set; }
    }
}
