﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLActivityprojectrolemapping
    {
        public int ActivitymappingId { get; set; }
        public int ActivityId { get; set; }
        public int ProjectId { get; set; }
        public long RoleId { get; set; }
        public long UserId { get; set; }
        public DateTime ActivitydateDt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }

        public virtual WmaMActivity Activity { get; set; }
        public virtual WmaMUser User { get; set; }
    }
}
