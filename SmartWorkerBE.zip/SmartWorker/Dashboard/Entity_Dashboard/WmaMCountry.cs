﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMCountry
    {
        public WmaMCountry()
        {
            WmaFWorkerdata = new HashSet<WmaFWorkerdatum>();
            WmaMIdproofs = new HashSet<WmaMIdproof>();
            WmaMStates = new HashSet<WmaMState>();
            WmaMWageGovernmenttypes = new HashSet<WmaMWageGovernmenttype>();
        }

        public int CountryId { get; set; }
        public string CountryVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string CountrycodeVc { get; set; }
        public string Pincodevalidation { get; set; }
        public string MobilevalidationVc { get; set; }
        public int? Residentidproof { get; set; }
        public bool? IswageenabledBt { get; set; }

        public virtual ICollection<WmaFWorkerdatum> WmaFWorkerdata { get; set; }
        public virtual ICollection<WmaMIdproof> WmaMIdproofs { get; set; }
        public virtual ICollection<WmaMState> WmaMStates { get; set; }
        public virtual ICollection<WmaMWageGovernmenttype> WmaMWageGovernmenttypes { get; set; }
    }
}
