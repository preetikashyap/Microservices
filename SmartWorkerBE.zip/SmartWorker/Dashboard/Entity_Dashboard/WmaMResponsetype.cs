﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaMResponsetype
    {
        public WmaMResponsetype()
        {
            WmaLChecklistquesresponsetypemaps = new HashSet<WmaLChecklistquesresponsetypemap>();
        }

        public int ResponsetypeId { get; set; }
        public string ResponsetypedescVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLChecklistquesresponsetypemap> WmaLChecklistquesresponsetypemaps { get; set; }
    }
}
