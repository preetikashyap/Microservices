﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLUsertreemap
    {
        public long UsertreemapId { get; set; }
        public long UserId { get; set; }
        public long RoleId { get; set; }
        public bool IssuperadminBt { get; set; }
        public int? IcId { get; set; }
        public int? SbgId { get; set; }
        public int? BuId { get; set; }
        public int? ClusterId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? SegmentId { get; set; }

        public virtual WmaMBu Bu { get; set; }
        public virtual WmaMCluster Cluster { get; set; }
        public virtual WmaMIc Ic { get; set; }
        public virtual WmaMRole Role { get; set; }
        public virtual WmaMSbg Sbg { get; set; }
        public virtual WmaMUser User { get; set; }
    }
}
