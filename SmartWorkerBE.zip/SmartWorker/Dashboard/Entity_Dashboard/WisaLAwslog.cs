﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WisaLAwslog
    {
        public long AwslogId { get; set; }
        public string TransactionVc { get; set; }
        public string OperationVc { get; set; }
        public int NooftimesId { get; set; }
        public string ImageVc { get; set; }
        public int? InitiatedbyId { get; set; }
        public DateTime InitiatedonDt { get; set; }
        public string Companycode { get; set; }
        public string Iccode { get; set; }
    }
}
