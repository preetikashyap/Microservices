﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Dashboard.Entity_Dashboard
{
    public partial class WmaLWageWorkerwageprocessarrearmapping
    {
        public long Wageprocessingarrearmappingid { get; set; }
        public long Workerwageprocessid { get; set; }
        public long Arrearid { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }
    }
}
