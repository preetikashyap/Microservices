﻿using Dashboard.Das_Model.Zone;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Das_Model.DTO
{
    public class ZoneWorkerCount
    {
        public int? TotalWorkerCount { get; set; }
        public List<ZonesWorker> Zonesworkercounts { get; set; }
    }
}
