﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Das_Model.Zone
{
    public class ZoneWorkerModel
    {
        public int? projectId { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }

    }
}
