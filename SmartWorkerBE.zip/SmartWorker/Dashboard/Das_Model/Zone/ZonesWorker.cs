﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Das_Model.Zone
{
    public class ZonesWorker
    {
        public string ProjectName { get; set; }

        public string ZoneName { get; set; }
        public int WorkerCount { get; set; }
        public string Dates { get; set; }
        public string Times { get; set; }

    }
}
