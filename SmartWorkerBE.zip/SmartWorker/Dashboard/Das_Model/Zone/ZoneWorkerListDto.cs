﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Das_Model.Zone
{
    public class ZoneWorkerListDto
    {

        public string ProjectName { get; set; }
        public int WorkerId { get; set; }

        public string WorkerName { get; set; }

        //  public string Date { get; set; }

        public string ZoneName { get; set; }

        public string InTime { get; set; }
        public string OutTime { get; set; }

        public string Createddate { get; set; }

    }
}
