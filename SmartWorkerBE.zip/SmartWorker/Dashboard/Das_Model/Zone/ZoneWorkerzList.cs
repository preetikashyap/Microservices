﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Das_Model.Zone
{
    public class ZoneWorkerzList
    {
        public string ProjectName { get; set; }
        public int WorkerId { get; set; }

        public string WorkerName { get; set; }

        public string Date { get; set; }

        public List<ZoneInAndOut> ZoneInOut { get; set; }
    }

    public class ZoneInAndOut
    {

        public string ZoneName { get; set; }
        public string InTime { get; set; }
        public string OutTime { get; set; }

    }

}
