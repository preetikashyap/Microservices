﻿using Dashboard.Das_Model.Zone;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.DAL.ZoneDAL
{
    public interface IWorkerZoneDAL
    {
        Task<List<ZonesWorker>> GetZonesWorkerDetails(ZoneWorkerModel zoneWorkerModel);
        Task<List<ZoneWorkerListDto>> GetZonesWorkerList(ZoneDetails zoneWorkerModel);
        
    }
}
