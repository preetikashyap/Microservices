﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Dashboard.Entity_Dashboard;
using Dashboard.Das_Model.Zone;

namespace Dashboard.DAL.ZoneDAL
{
    public class WorkerZoneDAL : IWorkerZoneDAL
    {
        private SmartWorker_DbContext _smartWorker_DbContext;

        public WorkerZoneDAL(SmartWorker_DbContext smartWorker_DbContext)
        {
            _smartWorker_DbContext = smartWorker_DbContext;
        }


        #region Getting Zone Total worker count and zone based worker count
        public async Task<List<ZonesWorker>> GetZonesWorkerDetails(ZoneWorkerModel zoneWorkerModel)
        {
            List<ZonesWorker> localWorkerData = new List<ZonesWorker>();
            try
            {


                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    localWorkerData = await _smartWorker_DbContext.ZonesWorkers.
                     FromSqlRaw("select * from sm_sp_getzoneworkerscounts(@ProjectId,@dates_val,@times_val)",
                    new NpgsqlParameter("Projectid", zoneWorkerModel.projectId),
                    new NpgsqlParameter("dates_val", zoneWorkerModel.Date),
                    new NpgsqlParameter("times_val", zoneWorkerModel.Time)).ToListAsync();

                }


            }
            catch (Exception ex)
            {
            }
            return localWorkerData;
        }
        #endregion


        #region Gettign Zone based worker list
        public async Task<List<ZoneWorkerListDto>> GetZonesWorkerList(ZoneDetails _zoneDetails)
        {
            List<ZoneWorkerListDto> zoneWorkerzLists = new List<ZoneWorkerListDto>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    zoneWorkerzLists = await _smartWorker_DbContext.ZoneWorkerListDto.FromSqlRaw(
                       "select * from sm_sp_getzoneworkerslist(@ProjectId,@ZoneId,@dates,@times)",
                   new NpgsqlParameter("Projectid", _zoneDetails.ProjectId),
                   new NpgsqlParameter("Zoneid", _zoneDetails.ZoneId),
                   new NpgsqlParameter("dates", _zoneDetails.Date),
                   new NpgsqlParameter("times", _zoneDetails.Time)).ToListAsync();


                }


            }
            catch (Exception ex)
            {
            }
            return zoneWorkerzLists;
        }

        #endregion
    }
}
