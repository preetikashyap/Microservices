﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dashboard.DAL.ZoneDAL;
using Dashboard.Das_Model.DTO;
using Dashboard.Das_Model.Zone;

namespace Dashboard.BL.ZoneBAL
{
    public class WorkerZoneDetails : IWorkerZoneDetails
    {

        private IWorkerZoneDAL _WorkerZoneDAL;

        public WorkerZoneDetails(IWorkerZoneDAL workerZoneDAL)
        {
            _WorkerZoneDAL = workerZoneDAL;

        }

        #region Getting Zone Total worker count and Zone Based worker count
        public async Task<ZoneWorkerCount> GetZonesWorkerDetails(ZoneWorkerModel zoneWorkerModel)
        {
            ZoneWorkerCount _zoneWorkerCount = new();
            List<ZonesWorker> _lstzonesWorker = new();

            int TotalWorkercount = 0;
            try
            {
                List<ZonesWorker> _lstzonesWorkerresult = await _WorkerZoneDAL.GetZonesWorkerDetails(zoneWorkerModel);

                foreach (var val in _lstzonesWorkerresult.ToList())
                {
                    ZonesWorker _zonesWorker = new ZonesWorker
                    {
                        ProjectName = val.ProjectName,
                        ZoneName = val.ZoneName,
                        WorkerCount = val.WorkerCount,
                        Dates = val.Dates,
                        Times = val.Times

                    };

                    _lstzonesWorker.Add(_zonesWorker);
                    TotalWorkercount += val.WorkerCount;
                }
                _zoneWorkerCount.Zonesworkercounts = _lstzonesWorker;
                _zoneWorkerCount.TotalWorkerCount = TotalWorkercount;

            }

            catch (Exception Ex)
            {

            }

            return _zoneWorkerCount;
        }
        #endregion

        #region Getting Zone Based worker List
        public async Task<List<ZoneWorkerzList>> GetZonesWorkerList(ZoneDetails zoneDetails)
        {

            ZoneWorkerzList zoneWorkerzList = new ZoneWorkerzList();
            List<ZoneWorkerzList> lstzoneWorkerzList = new List<ZoneWorkerzList>();

            ZoneInAndOut zoneInAndOut = new ZoneInAndOut();
            try
            {
                List<ZoneWorkerListDto> _lstzonesWorker = await _WorkerZoneDAL.GetZonesWorkerList(zoneDetails);
                List<int> WorkerId = _lstzonesWorker.Select(w => w.WorkerId).Distinct().ToList();



                foreach (var workId in WorkerId)
                {
                    List<ZoneInAndOut> _lstzoneInAndOut = new List<ZoneInAndOut>();
                    ZoneInAndOut _zoneInAndOut;

                    int findworkId = 0;
                    foreach (var val in _lstzonesWorker.Where(w => w.WorkerId == workId).AsEnumerable())
                    {
                        _zoneInAndOut = new ZoneInAndOut();
                        if (findworkId != val.WorkerId)
                        {
                            zoneWorkerzList.ProjectName = val.ProjectName;
                            zoneWorkerzList.WorkerId = val.WorkerId;
                            zoneWorkerzList.WorkerName = val.WorkerName;
                            zoneWorkerzList.Date = val.Createddate;

                            findworkId = val.WorkerId;
                        }

                        _zoneInAndOut.ZoneName = val.ZoneName;
                        _zoneInAndOut.InTime = val.InTime;
                        _zoneInAndOut.OutTime = val.OutTime;


                        _lstzoneInAndOut.Add(_zoneInAndOut);

                    }
                    zoneWorkerzList.ZoneInOut = _lstzoneInAndOut;

                    lstzoneWorkerzList.Add(zoneWorkerzList);

                }
            }

            catch (Exception Ex)
            {

            }
            return lstzoneWorkerzList;
        }
        #endregion
    }
}
