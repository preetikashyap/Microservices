﻿using Dashboard.Das_Model.DTO;
using Dashboard.Das_Model.Zone;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Dashboard.BL.ZoneBAL
{
    public interface IWorkerZoneDetails
    {
        Task<ZoneWorkerCount> GetZonesWorkerDetails(ZoneWorkerModel zoneWorkerModel);

        Task<List<ZoneWorkerzList>> GetZonesWorkerList(ZoneDetails zoneWorkerzList);
        
    }
}
