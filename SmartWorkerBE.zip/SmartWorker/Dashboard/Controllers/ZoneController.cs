﻿using Dashboard.BL.ZoneBAL;
using Dashboard.Das_Model.DTO;
using Dashboard.Das_Model.Zone;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WokerEnrolment.Utilities;

namespace Dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ZoneController : ControllerBase
    {

        IWorkerZoneDetails _workerZoneDetails;
        public ZoneController(IWorkerZoneDetails workerZoneDetails)
        {
            _workerZoneDetails = workerZoneDetails;
        }

        #region Get Zones Worker Count
        [HttpGet]
        [Route("GetZonesWorkerCount")]
        public async Task<ActionResult> GetZonesWorkersDetails(ZoneWorkerModel zoneWorkerModel)
        {

            ReturnResult returnResult = new();
            try
            {
                if (ModelValidation.ZoneWorkerVlidation(zoneWorkerModel, out APIValidation _apiValidation))
                {

                    ZoneWorkerCount _zoneWorkerCount = await _workerZoneDetails.GetZonesWorkerDetails(zoneWorkerModel);
                    if (_zoneWorkerCount != null)
                    {

                        APIInfo _aPIInfo = new()
                        {
                            statusCode = "0001",
                            status = "Success",
                            message = "Success (With O/P list)."
                        };

                        returnResult.API_Info = _aPIInfo;
                        returnResult.Zone_Info = _zoneWorkerCount;
                    }
                    else
                    {
                        APIValidation _aPIdata = new()
                        {
                            Status = "Failure",
                            ErrorCode = "005",
                            ErrorDescription = "Zones worker details Not Found."
                        };

                        returnResult.API_Info = _aPIdata;
                        returnResult.Zone_Info = null;

                    }
                }
                else
                {
                    returnResult.API_Info = _apiValidation;
                    returnResult.Zone_Info = null;
                }
                return Ok(returnResult);
            }
            catch (Exception ex)
            {
                return NotFound(new NotFoundError("Zone's Workers is Not Found"));
            }



        }

        #endregion

        [HttpGet]
        [Route("GetZonesWorker")]
        public async Task<ActionResult> GetZonesWorkers(ZoneDetails zoneDetails)
        {

            ZoneWorkerResult returnResult = new();
            try
            {

                if (ModelValidation.ZoneValidation(zoneDetails, out APIValidation _apiValidation))
                {

                    List<ZoneWorkerzList> _lstzoneWorker = await _workerZoneDetails.GetZonesWorkerList(zoneDetails);
                    if (_lstzoneWorker != null)
                    {

                        APIInfo _aPIInfo = new()
                        {
                            statusCode = "0001",
                            status = "Success",
                            message = "Success (With O/P list)."
                        };
                        returnResult.API_Info = _aPIInfo;
                        returnResult.Worker_Info = _lstzoneWorker;
                    }
                    else
                    {
                        APIValidation _aPIdata = new()
                        {
                            Status = "Failure",
                            ErrorCode = "007",
                            ErrorDescription = "Worker details Not Found in Zone"
                        };

                        returnResult.API_Info = _aPIdata;
                        returnResult.Worker_Info = null;

                    }
                }
                else
                {
                    returnResult.API_Info = _apiValidation;
                    returnResult.Worker_Info = null;
                }
                return Ok(returnResult);
            }
            catch (Exception ex)
            {
                return NotFound(new NotFoundError("Zone's Workers is Not Found"));
            }



        }

    }
}
