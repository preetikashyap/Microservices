﻿using Dashboard.Model_Dashboard;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dashboard.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {


        [HttpGet]
        [Route("GetWorkerDemographicsGraphData")]
        public async Task<IActionResult> GetWorkerDemographicsGraphData(int val)
        {
            WorkerDemographics model = new WorkerDemographics();
            List<LocationDetails> ld = new List<LocationDetails>();
            if (val == 1)
            {
                model.InductionCount = 18463;
                model.OnBoardedCount = 510187;
                model.ReleasedCount = 520266;
                model.AvailableToday = 450687;

                ld.Add(new LocationDetails { StateName = "Andaman and Nicobar Islands", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Andhra Pradesh", WorkerCount = 12809 });
                ld.Add(new LocationDetails { StateName = "Arunachal Pradesh", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Assam", WorkerCount = 4764 });
                ld.Add(new LocationDetails { StateName = "Bihar", WorkerCount = 8589 });
                ld.Add(new LocationDetails { StateName = "Chandigarh", WorkerCount = 580 });
                ld.Add(new LocationDetails { StateName = "Chhattisgarh", WorkerCount = 5359 });
                ld.Add(new LocationDetails { StateName = "Dadra and Nagar Haveli and Daman and Diu", WorkerCount = 80 });
                ld.Add(new LocationDetails { StateName = "Daman and Diu", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Delhi", WorkerCount = 32834 });
                ld.Add(new LocationDetails { StateName = "Goa", WorkerCount = 893 });
                ld.Add(new LocationDetails { StateName = "Gujarat", WorkerCount = 36503 });
                ld.Add(new LocationDetails { StateName = "Haryana", WorkerCount = 13435 });
                ld.Add(new LocationDetails { StateName = "Himachal Pradesh", WorkerCount = 77 });
                ld.Add(new LocationDetails { StateName = "Jammu and Kashmir", WorkerCount = 1448 });
                ld.Add(new LocationDetails { StateName = "Jharkhand", WorkerCount = 15830 });
                ld.Add(new LocationDetails { StateName = "Karnataka", WorkerCount = 35252 });
                ld.Add(new LocationDetails { StateName = "Kerala", WorkerCount = 2828 });
                ld.Add(new LocationDetails { StateName = "Ladakh", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Lakshadweep", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Madhya Pradesh", WorkerCount = 49853 });
                ld.Add(new LocationDetails { StateName = "Maharashtra", WorkerCount = 76689 });
                ld.Add(new LocationDetails { StateName = "Manipur", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Meghalaya", WorkerCount = 573 });
                ld.Add(new LocationDetails { StateName = "Mizoram", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Nagaland", WorkerCount = 0 });
                ld.Add(new LocationDetails { StateName = "Odisha", WorkerCount = 43997 });
                ld.Add(new LocationDetails { StateName = "Puducherry", WorkerCount = 1555 });
                ld.Add(new LocationDetails { StateName = "Punjab", WorkerCount = 1623 });
                ld.Add(new LocationDetails { StateName = "Rajasthan", WorkerCount = 38339 });
                ld.Add(new LocationDetails { StateName = "Sikkim", WorkerCount = 94 });
                ld.Add(new LocationDetails { StateName = "Tamil Nadu", WorkerCount = 41609 });
                ld.Add(new LocationDetails { StateName = "Telangana", WorkerCount = 19174 });
                ld.Add(new LocationDetails { StateName = "Tripura", WorkerCount = 606 });
                ld.Add(new LocationDetails { StateName = "Uttar Pradesh", WorkerCount = 35243 });
                ld.Add(new LocationDetails { StateName = "Uttarakhand", WorkerCount = 1833 });
                ld.Add(new LocationDetails { StateName = "West Bengal", WorkerCount = 29530 });
                model.LocationDetailsList = ld;
            }
            if (val == 2)
            {
                model.InductionCount = 18463;
                model.OnBoardedCount = 510187;
                model.ReleasedCount = 520266;
                model.AvailableToday = 450687;

                ld.Add(new LocationDetails { StateName = "Andaman and Nicobar Islands", WorkerCount = 20 });
                ld.Add(new LocationDetails { StateName = "Andhra Pradesh", WorkerCount = 4869 });
                ld.Add(new LocationDetails { StateName = "Arunachal Pradesh", WorkerCount = 41 });
                ld.Add(new LocationDetails { StateName = "Assam", WorkerCount = 5886 });
                ld.Add(new LocationDetails { StateName = "Bihar", WorkerCount = 89142 });
                ld.Add(new LocationDetails { StateName = "Chandigarh", WorkerCount = 244 });
                ld.Add(new LocationDetails { StateName = "Chhattisgarh", WorkerCount = 4237 });
                ld.Add(new LocationDetails { StateName = "Dadra and Nagar Haveli and Daman and Diu", WorkerCount = 39 });
                ld.Add(new LocationDetails { StateName = "Daman and Diu", WorkerCount = 12 });
                ld.Add(new LocationDetails { StateName = "Delhi", WorkerCount = 3357 });
                ld.Add(new LocationDetails { StateName = "Goa", WorkerCount = 46 });
                ld.Add(new LocationDetails { StateName = "Gujarat", WorkerCount = 6514 });
                ld.Add(new LocationDetails { StateName = "Haryana", WorkerCount = 1897 });
                ld.Add(new LocationDetails { StateName = "Himachal Pradesh", WorkerCount = 512 });
                ld.Add(new LocationDetails { StateName = "Jammu and Kashmir", WorkerCount = 1045 });
                ld.Add(new LocationDetails { StateName = "Jharkhand", WorkerCount = 79044 });
                ld.Add(new LocationDetails { StateName = "Karnataka", WorkerCount = 6491 });
                ld.Add(new LocationDetails { StateName = "Kerala", WorkerCount = 1019 });
                ld.Add(new LocationDetails { StateName = "Ladakh", WorkerCount = 10 });
                ld.Add(new LocationDetails { StateName = "Lakshadweep", WorkerCount = 16 });
                ld.Add(new LocationDetails { StateName = "Madhya Pradesh", WorkerCount = 37009 });
                ld.Add(new LocationDetails { StateName = "Maharashtra", WorkerCount = 14169 });
                ld.Add(new LocationDetails { StateName = "Manipur", WorkerCount = 19 });
                ld.Add(new LocationDetails { StateName = "Meghalaya", WorkerCount = 118 });
                ld.Add(new LocationDetails { StateName = "Mizoram", WorkerCount = 5 });
                ld.Add(new LocationDetails { StateName = "Nagaland", WorkerCount = 34 });
                ld.Add(new LocationDetails { StateName = "Odisha", WorkerCount = 36597 });
                ld.Add(new LocationDetails { StateName = "Puducherry", WorkerCount = 203 });
                ld.Add(new LocationDetails { StateName = "Punjab", WorkerCount = 3632 });
                ld.Add(new LocationDetails { StateName = "Rajasthan", WorkerCount = 24224 });
                ld.Add(new LocationDetails { StateName = "Sikkim", WorkerCount = 16 });
                ld.Add(new LocationDetails { StateName = "Tamil Nadu", WorkerCount = 14392 });
                ld.Add(new LocationDetails { StateName = "Telangana", WorkerCount = 2579 });
                ld.Add(new LocationDetails { StateName = "Tripura", WorkerCount = 162 });
                ld.Add(new LocationDetails { StateName = "Uttar Pradesh", WorkerCount = 88907 });
                ld.Add(new LocationDetails { StateName = "Uttarakhand", WorkerCount = 1148 });
                ld.Add(new LocationDetails { StateName = "West Bengal", WorkerCount = 82532 });
                model.LocationDetailsList = ld;
            }
            return Ok(model);
        }

        [HttpGet]
        [Route("GetWorkerAvailability")]
        public async Task<IActionResult> GetWorkerAvailability()
        {
            CommonRM<List<ZoneDetailsWithSkils>> Response = new CommonRM<List<ZoneDetailsWithSkils>>();
            List<ZoneDetailsWithSkils> LIstzoneDetailsWithSkils = new List<ZoneDetailsWithSkils>();
            ZoneDetailsWithSkils zoneDetailsWithSkils = new ZoneDetailsWithSkils();
            Response.code = "200";
            Response.message = "Data Retrieval Successful";
            Response.status = "Success";
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 1", HighlySkilled = 10, Skilled = 130, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 2", HighlySkilled = 530, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 3", HighlySkilled = 20, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 4", HighlySkilled = 530, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 5", HighlySkilled = 520, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 6", HighlySkilled = 550, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 7", HighlySkilled = 530, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 8", HighlySkilled = 520, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 9", HighlySkilled = 500, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 10", HighlySkilled = 580, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 12", HighlySkilled = 510, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 13", HighlySkilled = 520, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            LIstzoneDetailsWithSkils.Add(new ZoneDetailsWithSkils { ZoneName = "Zone 14", HighlySkilled = 510, Skilled = 10, SemiSkilled = 30, UnSkilled = 90, ActualHrs = 100, PlannedHrs = 10 });
            Response.data = LIstzoneDetailsWithSkils;
            try
            {
                return Ok(Response);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("WorkerAttendanceSummary")]
        public async Task<IActionResult> GetWorkerAttendanceSummary()
        {
            CommonRM<List<WorkerAttendanceDetails>> Response = new CommonRM<List<WorkerAttendanceDetails>>();
            List<WorkerAttendanceDetails> ListofWorkerAttendance = new List<WorkerAttendanceDetails>();
            WorkerAttendanceDetails workerAttendance = new WorkerAttendanceDetails();
            try
            {
                Response.code = "200";
                Response.message = "Data Retrieval Successful";
                Response.status = "Success";
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 01", LateEntry = 10, Present = 20, Absent = 12, LeftEarly = 40, ZoneViolation = 8 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 02", LateEntry = 30, Present = 120, Absent = 112, LeftEarly = 140, ZoneViolation = 18 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 03", LateEntry = 50, Present = 220, Absent = 212, LeftEarly = 540, ZoneViolation = 28 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 04", LateEntry = 40, Present = 320, Absent = 312, LeftEarly = 740, ZoneViolation = 48 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 05", LateEntry = 30, Present = 420, Absent = 412, LeftEarly = 640, ZoneViolation = 68 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 06", LateEntry = 90, Present = 520, Absent = 412, LeftEarly = 540, ZoneViolation = 78 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 07", LateEntry = 110, Present = 620, Absent = 512, LeftEarly = 340, ZoneViolation = 88 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 08", LateEntry = 120, Present = 720, Absent = 612, LeftEarly = 440, ZoneViolation = 78 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 09", LateEntry = 130, Present = 720, Absent = 162, LeftEarly = 440, ZoneViolation = 48 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 10", LateEntry = 140, Present = 820, Absent = 162, LeftEarly = 540, ZoneViolation = 28 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 11", LateEntry = 150, Present = 720, Absent = 172, LeftEarly = 640, ZoneViolation = 58 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 12", LateEntry = 160, Present = 420, Absent = 182, LeftEarly = 440, ZoneViolation = 48 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 13", LateEntry = 170, Present = 420, Absent = 182, LeftEarly = 540, ZoneViolation = 68 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 14", LateEntry = 180, Present = 620, Absent = 192, LeftEarly = 640, ZoneViolation = 88 });
                ListofWorkerAttendance.Add(new WorkerAttendanceDetails { Date = "Nov 15", LateEntry = 190, Present = 120, Absent = 162, LeftEarly = 540, ZoneViolation = 98 });


                Response.data = ListofWorkerAttendance;
                return Ok(Response);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
