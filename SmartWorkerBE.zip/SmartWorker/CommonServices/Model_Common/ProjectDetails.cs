﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class ProjectDetails
    {
        public int Project_ID { get; set; }
        public string ProjectDescription_VC { get; set; }
    }
}
