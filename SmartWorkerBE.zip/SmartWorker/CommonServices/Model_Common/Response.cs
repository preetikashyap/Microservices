﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class Response
    {
        public string status { get; set; }
        public string message { get; set; }
        public object data { get; set; }


        public Response(int status_, string message_, object data_ = null)
        {
            status = status_ == 0 ? "Failure" : "Success";
            message = message_;
            data = data_;
        }
    }
}
