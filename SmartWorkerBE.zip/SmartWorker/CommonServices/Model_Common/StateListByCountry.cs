﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class StateListByCountry
    {
        public int State_ID { get; set; }
        public string State_Desc { get; set; }
    }
}
