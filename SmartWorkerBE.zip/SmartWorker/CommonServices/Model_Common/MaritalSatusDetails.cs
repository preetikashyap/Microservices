﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class MaritalSatusDetails
    {
        public int maritalstatus_id { get; set; }
        public string maritalstatus_vc { get; set; }
    }
}
