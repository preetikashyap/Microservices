﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class EmploymentTypeDetails
    {
        public int EmploymentType_ID { get; set; }
        public string EmploymentType_Desc { get; set; }
        public string EmploymentCode_VC { get; set; }
    }
}
