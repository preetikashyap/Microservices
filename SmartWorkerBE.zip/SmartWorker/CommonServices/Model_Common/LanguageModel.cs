﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class LanguageModel
    {
        public int language_id { get; set; }
        public string language_vc { get; set; }
    }
}
