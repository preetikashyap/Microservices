﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WokerEnrolment.Model_WE
{
    public class Country
    {
        public class CountryDetails
        {
            public int CountryId { get; set; }
            public string CountryName { get; set; }
        }

        public class CountryCodesandRegexDetails
        {
            public int CountryId { get; set; }
            public string CountryCode { get; set; }
            public string MobileValidation { get; set; }
        }
    }

}
