﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class IDProofDetails
    {
        public int IDProof_ID { get; set; }
        public string IDProofName_VC { get; set; }
        public int? Country_ID { get; set; }
        public string IDProofPattern { get; set; }
        public string IDValidation_VC { get; set; }
        public bool? DemographicFlag_BT { get; set; }
        public bool? IsRequiredKYC_BT { get; set; }
        public bool? HasissuedOn_BT { get; set; }
        public bool? HasExpiryOn_BT { get; set; }

    }
}
