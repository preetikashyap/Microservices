﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Model_Common
{
    public class SubContractorDropDownDetails
    {
        public string SubContractorName { get; set; }
        public string SubContractorCode { get; set; }
    }
}
