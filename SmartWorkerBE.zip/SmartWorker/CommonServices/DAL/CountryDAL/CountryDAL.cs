﻿using CommonServices.Entity_Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WokerEnrolment.Model_WE;
using static WokerEnrolment.Model_WE.Country;

namespace CommonService.DAL.CountryDAL
{
    public class CountryDAL : IcountryDAL
    {

        private SmartWorker_DbContext _smartWorker_DbContext;

        public CountryDAL(SmartWorker_DbContext smartWorker_DbContext)
        {
            _smartWorker_DbContext = smartWorker_DbContext;
        }
        #region Country 
        public async Task<List<CountryDetails>> GetCountryList()
        {
            List<CountryDetails> result = new List<CountryDetails>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    var countryList = (from c in _smartWorker_DbContext.WmaMCountries.Where(x => x.IsactiveBt == true)
                                       select new CountryDetails
                                       {
                                           CountryId = c.CountryId,
                                           CountryName = c.CountryVc
                                       }).ToList();

                    if (countryList?.Count > 0)
                    {
                        result = countryList;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return await Task.FromResult(result);
        }
        #endregion


        #region GetCountryCodesandRegexList
        public async Task<List<CountryCodesandRegexDetails>> GetCountryCodesandRegexList()
        {
            List<CountryCodesandRegexDetails> result = new List<CountryCodesandRegexDetails>();
            try
            {
                using(var objDB = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMCountries.Select(c => new CountryCodesandRegexDetails { CountryId = c.CountryId, CountryCode = c.CountrycodeVc, MobileValidation = c.MobilevalidationVc }).ToList();
                }
            }
            catch(Exception ex)
            {

            }

            return await Task.FromResult(result);
        }
        #endregion GetCountryCodesandRegexList
    }
}
