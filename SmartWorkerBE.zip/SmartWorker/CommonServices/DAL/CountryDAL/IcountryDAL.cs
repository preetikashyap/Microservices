﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WokerEnrolment.Model_WE;
using static WokerEnrolment.Model_WE.Country;

namespace CommonService.DAL.CountryDAL
{
    public interface IcountryDAL
    {
        Task<List<CountryDetails>> GetCountryList();

        Task<List<CountryCodesandRegexDetails>> GetCountryCodesandRegexList();
    }
}
