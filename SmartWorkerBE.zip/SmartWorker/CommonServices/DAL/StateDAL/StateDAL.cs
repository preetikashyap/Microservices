﻿using CommonServices.Entity_Common;
using CommonServices.Model_Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.DAL.StateDAL
{
    public class StateDAL : IStateDAL
    {
        private SmartWorker_DbContext _smartWorker_DbContext;

        public StateDAL(SmartWorker_DbContext smartWorker_DbContext)
        {
            _smartWorker_DbContext = smartWorker_DbContext;
        }
        public async Task<List<StateListByCountry>> GetStateListByCountryId(int CountryId)
        {
            List<StateListByCountry> objStateList = new List<StateListByCountry>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    objStateList = (from sta in _smartWorker_DbContext.WmaMStates.AsNoTracking().Where(x => x.IsactiveBt == true && (x.CountryId == CountryId || x.CountryId == 1))

                                    orderby sta.StateVc ascending

                                    select new StateListByCountry()
                                    {
                                        State_ID = sta.StateId,
                                        State_Desc = sta.StateVc
                                    }).ToList();
                }
            }
            catch (Exception exp)
            {
                //ExceptionLogging.LogError(exp);
                //LogTrace.SaveLogMessage("RiggingPermit -WebPortal DAL - GetLiftList", "ERROR", string.Empty);

            }
            return await Task.FromResult(objStateList);
        }
    }
}
