﻿using CommonServices.Entity_Common;
using CommonServices.Model_Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.DAL.CommonDAL
{
    public class CommonDAL : IcommonDAL
    {
        private SmartWorker_DbContext _smartWorker_DbContext;

        public CommonDAL(SmartWorker_DbContext smartWorker_DbContext)
        {
            _smartWorker_DbContext = smartWorker_DbContext;
        }
        #region IDProodType_LIST
        public async Task<List<IDProofDetails>> getIDProofList(int CountryId)
        {
            List<IDProofDetails> objIDProofList = new List<IDProofDetails>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    objIDProofList = (from idproof in _smartWorker_DbContext.WmaMIdproofs.AsNoTracking().Where(x => x.IsactiveBt == true && (x.CountryId == CountryId || x.CountryId == 1))

                                      orderby idproof.IdproofnameVc ascending

                                      select new IDProofDetails()
                                      {
                                          IDProof_ID = idproof.IdproofId,
                                          IDProofName_VC = idproof.IdproofnameVc,
                                          IDProofPattern = idproof.IdvalidationVc,
                                          DemographicFlag_BT = idproof.DemographicflagBt,
                                          HasissuedOn_BT = idproof.HasissuedonBt,
                                          HasExpiryOn_BT = idproof.HasexpiryonBt
                                      }).ToList();
                }
            }
            catch (Exception exp)
            {
                //ExceptionLogging.LogError(exp);
                //LogTrace.SaveLogMessage("RiggingPermit -WebPortal DAL - GetLiftList", "ERROR", string.Empty);

            }
            return await Task.FromResult(objIDProofList);
        }
        #endregion

        #region IC Region
        public async Task<List<ICDetails>> GetICList()
        {
            List<ICDetails> result = new List<ICDetails>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMIcs.AsNoTracking().Select(x => new ICDetails { IC_ID = x.IcId, IC_VC = x.IcnameVc }).ToList();
                }
            }
            catch (Exception ex)
            {
                //ExceptionLogging.LogError(ex);
            }
            return await Task.FromResult(result);
        }

        #endregion

        #region EmployementType Region

        public async Task<List<EmploymentTypeDetails>> GetEmploymentTypeList()
        {
            List<EmploymentTypeDetails> objEmpTypeList = new List<EmploymentTypeDetails>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    _smartWorker_DbContext.ChangeTracker.LazyLoadingEnabled = false;

                    objEmpTypeList = (from emp in _smartWorker_DbContext.WmaMEmploymenttypes.Where(x => x.IsactiveBt == true)

                                      orderby emp.EmploymenttypedescVc ascending

                                      select new EmploymentTypeDetails()
                                      {
                                          EmploymentType_ID = emp.EmploymenttypeId,
                                          EmploymentType_Desc = emp.EmploymenttypedescVc,
                                          EmploymentCode_VC = emp.EmploymentcodeVc
                                      }).ToList();

                }
            }
            catch (Exception exp)
            {
                //ExceptionLogging.LogError(exp);
                //LogTrace.SaveLogMessage("RiggingPermit -WebPortal DAL - GetLiftList", "ERROR", string.Empty);

            }
            return await Task.FromResult(objEmpTypeList);

        }

        #endregion

        #region languages
        public async Task<List<LanguageModel>> GetLanguagesByCountry(int CountryId)
        {
            List<LanguageModel> result = new List<LanguageModel>();
            try
            {
                using(var objDB = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMLanguages.AsNoTracking().Where(c=> c.CountryId == CountryId).Select(c => new LanguageModel { language_id = c.LanguageId, language_vc = c.LanguageVc }).ToList(); 
                }
            }
            catch(Exception ex)
            {

            }
            return await Task.FromResult(result);
        }
        #endregion languages

        #region Marital Status
        public async Task<List<MaritalSatusDetails>> GetMaritalSatusList()
        {
            List<MaritalSatusDetails> result = new List<MaritalSatusDetails>();
            try
            {
                using(var objDB = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMMaritalstatuses.AsNoTracking().Select(x => new MaritalSatusDetails { maritalstatus_id = x.MaritalstatusId, maritalstatus_vc = x.MaritalstatusVc }).ToList();
                }
            }
            catch(Exception ex)
            {

            }

            return await Task.FromResult(result);
        }
        #endregion Marital Status

        #region subcontractortypes
        public async Task<List<SubContractorDropDownDetails>> GetSubContractorTypes()
        {
            List<SubContractorDropDownDetails> result = new List<SubContractorDropDownDetails>();
            try
            {
                using(var objDB = _smartWorker_DbContext.Database.BeginTransaction())
                {
                   result = _smartWorker_DbContext.WmaMSubcontractortypes.AsNoTracking().Select(x => new SubContractorDropDownDetails { SubContractorName = x.ScnameVc, SubContractorCode = x.ScnameVc }).ToList();
                }
            }
            catch(Exception ex)
            {

            }
            return await Task.FromResult(result);
        }
        #endregion subcontractortypes

        #region pincodevalidation
        public async Task<PinCodeValidationDetails> GetPinCodeValidationDetailsByCountry(int CountryId)
        {
            PinCodeValidationDetails result = new PinCodeValidationDetails();
            try
            {
                using (var objDB = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMCountries.Where(c => c.CountryId == CountryId).Select(x => new PinCodeValidationDetails { RegexString = x.Pincodevalidation }).FirstOrDefault();
                }
            }
            catch(Exception ex)
            {

            }
            return await Task.FromResult(result);
        }
        #endregion pincodevalidation
    }
}
