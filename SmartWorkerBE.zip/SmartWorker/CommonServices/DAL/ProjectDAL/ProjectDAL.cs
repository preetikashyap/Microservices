﻿using CommonServices.Entity_Common;
using CommonServices.Model_Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.DAL.ProjectDAL
{
    public class ProjectDAL : IprojectDAL
    {

        private SmartWorker_DbContext _smartWorker_DbContext;

        public ProjectDAL(SmartWorker_DbContext smartWorker_DbContext)
        {
            _smartWorker_DbContext = smartWorker_DbContext;
        }
        public async Task<List<ProjectDetails>> GetProjectList()
        {
            List<ProjectDetails> result = new List<ProjectDetails>();
            try
            {
                using (var dbcontext = _smartWorker_DbContext.Database.BeginTransaction())
                {
                    result = _smartWorker_DbContext.WmaMProjects.AsNoTracking()
                                    .Select(x => new ProjectDetails { Project_ID = x.ProjectId, ProjectDescription_VC = x.ProjectdescriptionVc }).ToList();
                }
            }
            catch (Exception ex)
            {
                //ExceptionLogging.LogError(ex);
            }
            return await Task.FromResult(result);
        }
    }
}
