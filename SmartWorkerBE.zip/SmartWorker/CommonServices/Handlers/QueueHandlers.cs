﻿using CommonServices.Model_Common;
using Microsoft.Extensions.Configuration;
using MQAzureBus;
using MQAzureBus.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Handlers
{
    public class QueueHandlers
    {
        public readonly IBusService _busService;
        private readonly IConfiguration _config;
        public QueueHandlers(IConfiguration configuration)
        {
            _config = configuration;
            //if (_config["AzureBus:isAzureBus"] == "true")
            //    _busService = new BusService(_config["AzureBus:BusEndpoint"]);
            //else
                _busService = new MqBusService(_config["AzureBus:MQEndPoint"]);
        }
        public async Task<string> SendQueueStatus(string sessionId, Response response, string functionType)
        {
            MessageProp messProp = new MessageProp();
            messProp.SenderQueueName = _config["AzureBus:ResponseQueueName"];
            messProp.Message = _busService.GeneratePayload(response, functionType);
            messProp.SessionId = sessionId;
            var result = await _busService.SendSessionMessagesWithSessionIdAsync(messProp);

            return result.SessionId;

        }


        

    
}
}
