﻿using CommonServices.BL_Layer.StateBL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CommonServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {

        private readonly IStateBL _stateBL;
        public StateController(IStateBL stateBL)
        {
            _stateBL = stateBL;
        }


        [HttpGet]
        [Route("GetStateListByCountry/{CountryId}")]
        public async Task<IActionResult> GetStateListByCountryId(int CountryId)
        {
            var StateList = await _stateBL.getStateList(CountryId);
            if (StateList != null)
            {

                return Ok(StateList);
            }
            else
                return NotFound("The State List was not found");
        }


    }
}
