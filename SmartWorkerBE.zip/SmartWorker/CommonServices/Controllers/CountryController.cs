﻿using CommonService.BL_Layer.CountryBL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CommonService.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class CountryController : ControllerBase
    {
        private readonly ICountryBL _ICountryBL;
        public CountryController(ICountryBL countryBL)
        {
            _ICountryBL = countryBL;
        }

        // GET: api/<ValuesController>
        [HttpGet]
        [Route("GetcountryList")]
        public async Task<IActionResult> Getcountry()
        {
            var CountryLIst = await _ICountryBL.GetCountryList();
            if (CountryLIst != null)
            {

                return Ok(CountryLIst);
            }
            else
                return NotFound("The CountryList was not found");
        }

        [HttpGet]
        [Route("GetCountryCodesandRegexList")]
        public  async Task<IActionResult> GetCountryCodesandRegexList()
        {
            var list = await _ICountryBL.GetCountryCodesandRegexList();
            if(list!=null)
            {
                return Ok(list);
            }
            else
            {
                return NotFound("List was not found");
            }
        }
    }
}
