﻿using CommonServices.BL_Layer.CommonBL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CommonServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private IcommonBL _icommonBL;

        public CommonController(IcommonBL icommonBL)
        {
            _icommonBL = icommonBL;
        }
        [HttpGet]
        [Route("GetIdProofListByCountry/{CountryId}")]
        public async Task<IActionResult> GetIdProofListByCountryId(int CountryId)
        {
            var StateList = await _icommonBL.getIDProofList(CountryId);
            if (StateList != null)
            {
                return Ok(StateList);
            }
            else
                return NotFound("The IdProof List was not found");
        }


        [HttpGet]
        [Route("GetICList")]
        public async Task<IActionResult> GetListIC()
        {
            var ICLIst = await _icommonBL.GetICList();
            if (ICLIst != null)
            {

                return Ok(ICLIst);
            }
            else
                return NotFound("The IC List was not found");
        }

        [HttpGet]
        [Route("GetEmploymentTypeList")]
        public async Task<IActionResult> GetEmploymentTypeList()
        {
            var EmployemtList = await _icommonBL.GetEmploymentList();
            if (EmployemtList != null)
            {
                return Ok(EmployemtList);
            }
            else
                return NotFound("The Employemt List was not found");
        }

        #region Languages
        [HttpGet]
        [Route("GetLanguagesByCountry/{CountryId}")]
        public async Task<IActionResult> GetLanguagesByCountry(int CountryId)
        {
            var languagelist = await _icommonBL.GetLanguagesByCountry(CountryId);
            if(languagelist != null)
            {
                return Ok(languagelist);
            }
            else
            {
                return NotFound("Languages list was not found");
            }
        }
        #endregion Languages

        #region Marital Status
        [HttpGet]
        [Route("GetMaritalSatusList")]
        public async Task<IActionResult> GetMaritalSatusList()
        {
            var mslist = await _icommonBL.GetMaritalStatusList();
            if(mslist!=null)
            {
                return Ok(mslist);
            }
            else
            {
                return NotFound("Marital Status List Not Found");
            }
        }
        #endregion Marital Status

        #region subcontractortypes
        [HttpGet]
        [Route("GetSubContractorTypes")]
        public async Task<IActionResult> GetSubContractorTypes()
        {
            var scList = await _icommonBL.GetSubContractorTypes();
            if(scList!=null)
            {
                return Ok(scList);
            }
            else
            {
                return NotFound("Sub Contractors Types Not Found");
            }
        }
        #endregion subcontractortypes

        #region pincodevalidation
        [HttpGet]
        [Route("GetPinCodeValidationDetailsByCountry/{CountryId}")]
        public async Task<ActionResult> GetPinCodeValidationDetailsByCountry(int CountryId)
        {
            var List = await _icommonBL.GetPinCodeValidationDetailsByCountry(CountryId);
            if(List != null)
            {
                return Ok(List);
            }
            else
            {
                return NotFound("Validation Regex Not Found");
            }
        }
        #endregion pincodevalidation


       
    }
}
