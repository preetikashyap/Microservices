﻿using CommonServices.BL_Layer.ProjectBL;
using CommonServices.Handlers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CommonServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private IprojectBL _IprojectBL;
        private readonly IConfiguration _config;
        private readonly QueueHandlers _queueHandlers;

        public ProjectController(IprojectBL iprojectBL, IConfiguration configuration)
        {
            _IprojectBL = iprojectBL;
            _config = configuration;
            _queueHandlers = new QueueHandlers(_config);
        }
        [HttpGet]
        [Route("GetProjectList")]
        public async Task<IActionResult> GetProjectList()
        {
            var ProjectList = await _IprojectBL.GetProjectList();
            if (ProjectList != null)
            {

                return Ok(ProjectList);
            }
            else
                return NotFound("The Project List was not found");
        }
    }
}
