﻿using CommonServices.BL_Layer.ProjectBL;
using CommonServices.Handlers;
using CommonServices.Model_Common;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.Services
{
    public class QueueServiceTasks
    {
        private QueueHandlers _queueHandler;
        private readonly IServiceProvider _services;
        private readonly IConfiguration _config;
       

        public QueueServiceTasks(QueueHandlers queueHandler, IServiceProvider services)
        {
            _services = services;
            _queueHandler = queueHandler;
       
        }
        public async Task Handle(string type, string sessionId, string message)
        {
            

            using (var scope = _services.CreateScope())
            {

                if (type == "TriggerGetProjects")
                {
                    //var iprojectBL = new IprojectBL();
                    //var emp = iprojectBL.GetProjectList();
                    await _queueHandler.SendQueueStatus(sessionId, new Response(1, "Success", "2"), type);
                }

            }

        }
    }
}
