﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Serilog;
using System.Text;
using System.Threading;
using CommonServices.Handlers;
using MQAzureBus.Models;

namespace CommonServices.Services
{
    public class MqQueueService : IHostedService, IDisposable
    {
        private readonly string _busUri;
        private readonly IConfiguration _config;
        private readonly IServiceProvider _services;
        private QueueHandlers _queueHandler;
        private QueueServiceTasks _qsTasks;
        private IModel _channel;
        public MqQueueService(IConfiguration config, IServiceProvider services)
        {
            _config = config;
            _services = services;
            _queueHandler = new QueueHandlers(_config);
            _qsTasks = new QueueServiceTasks(_queueHandler, _services);
            _busUri = _config["AzureBus:MQEndPoint"];
        }

        Task IHostedService.StartAsync(CancellationToken cancellationToken)
        {
            Log.Information("Queue Hosted Service is started.");
            string queueName = _config["AzureBus:RequestQueueName"];
            var factory = new ConnectionFactory() { Uri = new System.Uri(_busUri) };
            var connection = factory.CreateConnection();
            _channel = connection.CreateModel();
            _channel.QueueDeclare(queue: queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);
            _channel.BasicQos(0, 1, false);
            var consumer = new EventingBasicConsumer(_channel);
            _channel.BasicConsume(queue: queueName, autoAck: false, consumer: consumer);

            consumer.Received += async (sender, args) =>
            {
                try
                {
                    await ProcessMessagesAsync(sender, args);
                    _channel.BasicAck(args.DeliveryTag, false);
                }
                catch (Exception e)
                {
                    await ExceptionReceivedHandler(e);
                    _channel.BasicNack(args.DeliveryTag, false, false);
                }

            };
            return Task.CompletedTask;
        }



        public async Task ProcessMessagesAsync(object model, BasicDeliverEventArgs ea)
        {
            var body = ea.Body.ToArray();
            var props = ea.BasicProperties;
            var replyProps = _channel.CreateBasicProperties();
            replyProps.CorrelationId = props.CorrelationId;

            Log.Information("Queue Process started with message id  :" + props.CorrelationId);
            // Process the message.           

            var decodedStr = Encoding.UTF8.GetString(body);
            Payload payload = JsonConvert.DeserializeObject<Payload>(decodedStr);
            var data = JsonConvert.DeserializeObject<string>(payload.PlMessage);
            var checkPay = JsonConvert.DeserializeObject<string>(payload.PlMessage);
            await _qsTasks.Handle(payload.Type, props.CorrelationId, checkPay);

            Log.Information("Queue Process completed with message id  :" + props.CorrelationId);
        }


        static Task ExceptionReceivedHandler(Exception ex)
        {
            StringBuilder errorData = new StringBuilder();
            errorData.Append($"Message handler encountered an exception {ex.Message}.");
            var context = ex.InnerException;
            errorData.Append("Exception context for troubleshooting:");
            Log.Error(errorData.ToString());
            return Task.CompletedTask;
        }



        void IDisposable.Dispose()
        {
            throw new NotImplementedException();
        }

        Task IHostedService.StopAsync(CancellationToken cancellationToken)
        {
            Log.Information("Queue Hosted Service is stopping.");
            return Task.CompletedTask;
        }
    }
}
