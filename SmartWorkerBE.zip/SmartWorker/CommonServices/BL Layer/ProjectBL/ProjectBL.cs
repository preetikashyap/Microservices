﻿using CommonServices.DAL.ProjectDAL;
using CommonServices.Model_Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.BL_Layer.ProjectBL
{
    public class ProjectBL : IprojectBL
    {

        private IprojectDAL _IprojectDAL;

        public ProjectBL(IprojectDAL iprojectDAL)
        {
            _IprojectDAL = iprojectDAL;
        }
        #region Project
        public async Task<List<ProjectDetails>> GetProjectList()
        {
            List<ProjectDetails> result = new List<ProjectDetails>();
            try
            {
                result = await _IprojectDAL.GetProjectList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        #endregion
    }
}
