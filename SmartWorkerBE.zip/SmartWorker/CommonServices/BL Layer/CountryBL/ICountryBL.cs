﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WokerEnrolment.Model_WE;
using static WokerEnrolment.Model_WE.Country;

namespace CommonService.BL_Layer.CountryBL
{
    public interface ICountryBL
    {
        Task<List<CountryDetails>> GetCountryList();
        Task<List<CountryCodesandRegexDetails>> GetCountryCodesandRegexList();
    }
}
