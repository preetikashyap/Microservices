﻿using CommonService.DAL.CountryDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WokerEnrolment.Model_WE;
using static WokerEnrolment.Model_WE.Country;

namespace CommonService.BL_Layer.CountryBL
{
    public class CountryBL : ICountryBL
    {
        private IcountryDAL _icountryDAL;

        public CountryBL(IcountryDAL icountryDAL)
        {
            _icountryDAL = icountryDAL;
        }
        #region Country
        public async Task<List<CountryDetails>> GetCountryList()
        {
            List<CountryDetails> result = new List<CountryDetails>();
            try
            {
                result = await _icountryDAL.GetCountryList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return result;
        }
        #endregion

        #region GetCountryCodesandRegexList
        public async Task<List<CountryCodesandRegexDetails>> GetCountryCodesandRegexList()
        {
            List<CountryCodesandRegexDetails> list = new List<CountryCodesandRegexDetails>();
            list = await _icountryDAL.GetCountryCodesandRegexList();
            return list;
        }
# endregion GetCountryCodesandRegexList
    }
}
