﻿using CommonServices.Model_Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.BL_Layer.CommonBL
{
    public interface IcommonBL
    {
        Task<List<IDProofDetails>> getIDProofList(int CountryId);

        Task<List<ICDetails>> GetICList();
        Task<List<EmploymentTypeDetails>> GetEmploymentList();
        Task<List<LanguageModel>> GetLanguagesByCountry(int CountryId);
        Task<List<MaritalSatusDetails>> GetMaritalStatusList();
        Task<List<SubContractorDropDownDetails>> GetSubContractorTypes();
        Task<PinCodeValidationDetails> GetPinCodeValidationDetailsByCountry(int CountryId);

    }
}
