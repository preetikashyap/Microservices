﻿using CommonServices.DAL.CommonDAL;
using CommonServices.Model_Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommonServices.BL_Layer.CommonBL
{
    public class CommonBL : IcommonBL
    {
        private IcommonDAL _icommonDAL;

        public CommonBL(IcommonDAL icommonDAL)
        {
            _icommonDAL = icommonDAL;
        }

        #region ID Proof LIst
        public async Task<List<IDProofDetails>> getIDProofList(int CountryId)
        {
            List<IDProofDetails> IDProofList = await _icommonDAL.getIDProofList(CountryId);
            return IDProofList;
        }
        #endregion

        #region ICList
        public async Task<List<ICDetails>> GetICList()
        {
            List<ICDetails> IClist = await _icommonDAL.GetICList();
            return IClist;
        }
        #endregion

        #region EmploymentType
        public async Task<List<EmploymentTypeDetails>> GetEmploymentList()
        {
            List<EmploymentTypeDetails> EmploymentTypeList = await _icommonDAL.GetEmploymentTypeList();
            return EmploymentTypeList;
        }
        #endregion

        #region language
        public async Task<List<LanguageModel>> GetLanguagesByCountry(int CountryId)
        {
            List<LanguageModel> langlist = await _icommonDAL.GetLanguagesByCountry(CountryId);
            return langlist;
        }
        #endregion language

        #region Marital Status
        public async Task<List<MaritalSatusDetails>> GetMaritalStatusList()
        {
            List<MaritalSatusDetails> List = await _icommonDAL.GetMaritalSatusList();
            return List;
        }
        #endregion Marital Status
        #region subcontractortypes
        public async Task<List<SubContractorDropDownDetails>> GetSubContractorTypes()
        {
            List<SubContractorDropDownDetails> List = await _icommonDAL.GetSubContractorTypes();
            return List;
        }
        #endregion subcontractortypes
        #region pincodevalidation
        public async Task<PinCodeValidationDetails> GetPinCodeValidationDetailsByCountry(int CountryId)
        {
            PinCodeValidationDetails pvd = await _icommonDAL.GetPinCodeValidationDetailsByCountry(CountryId);
            return pvd;
        }
        #endregion pincodevalidation
    }
}
