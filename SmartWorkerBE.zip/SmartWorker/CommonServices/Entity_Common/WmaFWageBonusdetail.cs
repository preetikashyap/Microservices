﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageBonusdetail
    {
        public int Id { get; set; }
        public int Projectid { get; set; }
        public string Bonusname { get; set; }
        public int Bonustypeid { get; set; }
        public decimal Value { get; set; }
        public bool Ispercent { get; set; }
        public int? Componentid { get; set; }
        public DateTime Effectivefrom { get; set; }
        public DateTime Effectiveto { get; set; }
        public int? Eligibility { get; set; }
        public bool Isactive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public virtual WmaMBonustype Bonustype { get; set; }
    }
}
