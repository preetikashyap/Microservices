﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFBiometricscheduler
    {
        public WmaFBiometricscheduler()
        {
            WmaFBiometricfilelogs = new HashSet<WmaFBiometricfilelog>();
        }

        public int BiometricschedulerId { get; set; }
        public DateTime? SchedulerstartsatDt { get; set; }
        public DateTime? SchedulerendsatDt { get; set; }
        public string SchedulerstatusVc { get; set; }
        public string SchedulermesageVc { get; set; }

        public virtual ICollection<WmaFBiometricfilelog> WmaFBiometricfilelogs { get; set; }
    }
}
