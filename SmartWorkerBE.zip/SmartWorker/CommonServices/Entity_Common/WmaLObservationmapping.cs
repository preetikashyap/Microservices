﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLObservationmapping
    {
        public int ObservationmappingId { get; set; }
        public int? ObservationcategoryId { get; set; }
        public int? ObservationsubcategoryId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMObservationcategory Observationcategory { get; set; }
        public virtual WmaMObservationsubcategory Observationsubcategory { get; set; }
    }
}
