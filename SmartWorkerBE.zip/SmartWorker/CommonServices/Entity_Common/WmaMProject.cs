﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMProject
    {
        public WmaMProject()
        {
            Testworkflows = new HashSet<Testworkflow>();
            WmaFAppreciations = new HashSet<WmaFAppreciation>();
            WmaFCompliancedetails = new HashSet<WmaFCompliancedetail>();
            WmaFReleaserequestExistingprojects = new HashSet<WmaFReleaserequest>();
            WmaFReleaserequestRequestingprojects = new HashSet<WmaFReleaserequest>();
            WmaFReleaserequesthistoryExistingprojects = new HashSet<WmaFReleaserequesthistory>();
            WmaFReleaserequesthistoryRequestingprojects = new HashSet<WmaFReleaserequesthistory>();
            WmaFSubcontractorselfdeclarations = new HashSet<WmaFSubcontractorselfdeclaration>();
            WmaFTraProjecttrainingdetails = new HashSet<WmaFTraProjecttrainingdetail>();
            WmaFWageAttendanceregularisations = new HashSet<WmaFWageAttendanceregularisation>();
            WmaFWageOtregularisations = new HashSet<WmaFWageOtregularisation>();
            WmaFWorkerleavebalancehistories = new HashSet<WmaFWorkerleavebalancehistory>();
            WmaFWorkerleavebalances = new HashSet<WmaFWorkerleavebalance>();
            WmaFWorkerleavedetails = new HashSet<WmaFWorkerleavedetail>();
            WmaFWorkerobservationdetails = new HashSet<WmaFWorkerobservationdetail>();
            WmaLProjectMedicalperiodicchecklistmappings = new HashSet<WmaLProjectMedicalperiodicchecklistmapping>();
            WmaLProjectattachments = new HashSet<WmaLProjectattachment>();
            WmaLProjectchecklistmaps = new HashSet<WmaLProjectchecklistmap>();
            WmaLProjectrlsworkflowmaps = new HashSet<WmaLProjectrlsworkflowmap>();
            WmaLProjectrlsworkflowmaptest1s = new HashSet<WmaLProjectrlsworkflowmaptest1>();
            WmaLProjectworkerevaluationchecklistmappings = new HashSet<WmaLProjectworkerevaluationchecklistmapping>();
            WmaLProjectworkflowmaps = new HashSet<WmaLProjectworkflowmap>();
            WmaLUserprojectrolemaps = new HashSet<WmaLUserprojectrolemap>();
            WmaLWorkerprojecttradedetails = new HashSet<WmaLWorkerprojecttradedetail>();
            WmaLWorkerprojecttradedetailshistories = new HashSet<WmaLWorkerprojecttradedetailshistory>();
            WmaMLabourcolonyBuildings = new HashSet<WmaMLabourcolonyBuilding>();
        }

        public int ProjectId { get; set; }
        public string ProjectcodeVc { get; set; }
        public string ProjectdescriptionVc { get; set; }
        public int? IcId { get; set; }
        public int? SbgId { get; set; }
        public int? BuId { get; set; }
        public int? ClusterId { get; set; }
        public string JobcityVc { get; set; }
        public string JobstateVc { get; set; }
        public bool IsautoreleaseBt { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? CompanycodeId { get; set; }
        public string JobpincodeVc { get; set; }
        public string JoboriginlocationVc { get; set; }
        public int? SegmentId { get; set; }
        public int? JobcountryId { get; set; }
        public bool? IsdefaultprojectBt { get; set; }
        public int? SerialnumberinitNb { get; set; }
        public bool? Iswagemoduleenabled { get; set; }
        public string Establishment { get; set; }
        public string Employerwithaddress { get; set; }
        public int? Zonemappingid { get; set; }
        public int? Govermenttypeid { get; set; }
        public bool? Ismainproject { get; set; }
        public int? Mainprojectid { get; set; }
        public int? Sectionid { get; set; }
        public bool? Caninductworker { get; set; }
        public DateTime? Lastsyncedon { get; set; }
        public string Lastsyncedremarks { get; set; }
        public DateTime? Lastsyncedon1 { get; set; }
        public bool? Islongabsencedaysreq { get; set; }
        public int? Longabsencedays { get; set; }

        public virtual WmaMBu Bu { get; set; }
        public virtual WmaMCluster Cluster { get; set; }
        public virtual WmaMIc Ic { get; set; }
        public virtual WmaMSbg Sbg { get; set; }
        public virtual ICollection<Testworkflow> Testworkflows { get; set; }
        public virtual ICollection<WmaFAppreciation> WmaFAppreciations { get; set; }
        public virtual ICollection<WmaFCompliancedetail> WmaFCompliancedetails { get; set; }
        public virtual ICollection<WmaFReleaserequest> WmaFReleaserequestExistingprojects { get; set; }
        public virtual ICollection<WmaFReleaserequest> WmaFReleaserequestRequestingprojects { get; set; }
        public virtual ICollection<WmaFReleaserequesthistory> WmaFReleaserequesthistoryExistingprojects { get; set; }
        public virtual ICollection<WmaFReleaserequesthistory> WmaFReleaserequesthistoryRequestingprojects { get; set; }
        public virtual ICollection<WmaFSubcontractorselfdeclaration> WmaFSubcontractorselfdeclarations { get; set; }
        public virtual ICollection<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetails { get; set; }
        public virtual ICollection<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisations { get; set; }
        public virtual ICollection<WmaFWageOtregularisation> WmaFWageOtregularisations { get; set; }
        public virtual ICollection<WmaFWorkerleavebalancehistory> WmaFWorkerleavebalancehistories { get; set; }
        public virtual ICollection<WmaFWorkerleavebalance> WmaFWorkerleavebalances { get; set; }
        public virtual ICollection<WmaFWorkerleavedetail> WmaFWorkerleavedetails { get; set; }
        public virtual ICollection<WmaFWorkerobservationdetail> WmaFWorkerobservationdetails { get; set; }
        public virtual ICollection<WmaLProjectMedicalperiodicchecklistmapping> WmaLProjectMedicalperiodicchecklistmappings { get; set; }
        public virtual ICollection<WmaLProjectattachment> WmaLProjectattachments { get; set; }
        public virtual ICollection<WmaLProjectchecklistmap> WmaLProjectchecklistmaps { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmap> WmaLProjectrlsworkflowmaps { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmaptest1> WmaLProjectrlsworkflowmaptest1s { get; set; }
        public virtual ICollection<WmaLProjectworkerevaluationchecklistmapping> WmaLProjectworkerevaluationchecklistmappings { get; set; }
        public virtual ICollection<WmaLProjectworkflowmap> WmaLProjectworkflowmaps { get; set; }
        public virtual ICollection<WmaLUserprojectrolemap> WmaLUserprojectrolemaps { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetailshistory> WmaLWorkerprojecttradedetailshistories { get; set; }
        public virtual ICollection<WmaMLabourcolonyBuilding> WmaMLabourcolonyBuildings { get; set; }
    }
}
