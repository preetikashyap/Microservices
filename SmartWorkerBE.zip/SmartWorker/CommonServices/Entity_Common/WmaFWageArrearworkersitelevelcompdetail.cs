﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageArrearworkersitelevelcompdetail
    {
        public long Id { get; set; }
        public long Arrearid { get; set; }
        public long Projectid { get; set; }
        public int Componentid { get; set; }
        public decimal Amount { get; set; }
        public bool Isallowancecomp { get; set; }
        public DateTime Processingmonth { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? Isactive { get; set; }
    }
}
