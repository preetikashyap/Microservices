﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLTraProjecttrainingconcernedusersmapping
    {
        public long ProjecttrainingconcernedusermapId { get; set; }
        public long ProjecttrainingId { get; set; }
        public long? ConcerneduserId { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaFTraProjecttrainingdetail Projecttraining { get; set; }
    }
}
