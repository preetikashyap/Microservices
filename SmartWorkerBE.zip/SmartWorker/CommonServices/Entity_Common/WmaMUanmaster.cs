﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMUanmaster
    {
        public int UanmasterId { get; set; }
        public long? MemberidNb { get; set; }
        public long? UanNb { get; set; }
        public string UannameVc { get; set; }
        public string GenderVc { get; set; }
        public DateTime? DobDt { get; set; }
        public DateTime? DojDt { get; set; }
        public string FathernameorhusbandnameVc { get; set; }
        public string RelationVc { get; set; }
        public string MaritalstatusVc { get; set; }
        public long? AadharnumberNb { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
