﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class Wrongempdatum
    {
        public long? Eipid { get; set; }
        public string RemarksVc { get; set; }
    }
}
