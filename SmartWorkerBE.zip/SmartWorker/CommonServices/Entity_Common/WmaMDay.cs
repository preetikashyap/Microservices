﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMDay
    {
        public int Dayid { get; set; }
        public int Day { get; set; }
        public string Daysrefname { get; set; }
    }
}
