﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class Tbltriggertest
    {
        public int Pkid { get; set; }
        public DateTime? Orderapprovaldatetime { get; set; }
        public string Orderstatus { get; set; }
    }
}
