﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMRisklevel
    {
        public WmaMRisklevel()
        {
            WmaFWorkercovid19maphistories = new HashSet<WmaFWorkercovid19maphistory>();
            WmaFWorkercovid19maps = new HashSet<WmaFWorkercovid19map>();
        }

        public int Risklevelid { get; set; }
        public string Risklevel { get; set; }
        public bool Isactive { get; set; }

        public virtual ICollection<WmaFWorkercovid19maphistory> WmaFWorkercovid19maphistories { get; set; }
        public virtual ICollection<WmaFWorkercovid19map> WmaFWorkercovid19maps { get; set; }
    }
}
