﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMObservationcategory
    {
        public WmaMObservationcategory()
        {
            WmaFAppreciations = new HashSet<WmaFAppreciation>();
            WmaFWorkerobservationdetails = new HashSet<WmaFWorkerobservationdetail>();
            WmaLObservationmappings = new HashSet<WmaLObservationmapping>();
        }

        public int ObservationcategoryId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaFAppreciation> WmaFAppreciations { get; set; }
        public virtual ICollection<WmaFWorkerobservationdetail> WmaFWorkerobservationdetails { get; set; }
        public virtual ICollection<WmaLObservationmapping> WmaLObservationmappings { get; set; }
    }
}
