﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLMobileloginOtp
    {
        public long Runningid { get; set; }
        public DateTime? DateTime { get; set; }
        public long? Loginuserid { get; set; }
        public string Smsuserid { get; set; }
        public string Otp { get; set; }
        public string SmsaknId { get; set; }
    }
}
