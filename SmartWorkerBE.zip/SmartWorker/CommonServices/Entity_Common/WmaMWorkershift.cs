﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWorkershift
    {
        public long WorkershiftId { get; set; }
        public string WorkershiftVc { get; set; }
        public TimeSpan? ShiftstarttimeT { get; set; }
        public TimeSpan? ShiftendtimeT { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? ProjectId { get; set; }
        public TimeSpan? MarginstarttimeT { get; set; }
        public TimeSpan? MarginendtimeT { get; set; }
        public string ShiftCode { get; set; }
    }
}
