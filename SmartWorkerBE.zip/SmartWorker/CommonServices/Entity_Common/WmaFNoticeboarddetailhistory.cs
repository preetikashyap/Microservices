﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFNoticeboarddetailhistory
    {
        public long HistoryId { get; set; }
        public long Noticeboarddetailid { get; set; }
        public string Noticecategoryname { get; set; }
        public short CategoryId { get; set; }
        public short? SubcategoryId { get; set; }
        public double Revision { get; set; }
        public string ViewAccess { get; set; }
        public string Remarks { get; set; }
        public int Createdbyroleid { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsActive { get; set; }

        public virtual WmaMUser CreatedByNavigation { get; set; }
    }
}
