﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFAwsfacerecognitiontransaction
    {
        public long AwsfacerecognitiontransactionId { get; set; }
        public long WisaId { get; set; }
        public long? AwsrunningId { get; set; }
        public string ImageuploadedurlVc { get; set; }
        public string ReferenceimageurlVc { get; set; }
        public string MatchingpercentageVc { get; set; }
        public DateTime? AttendancedateDt { get; set; }
        public int? AttendancemarkedbyId { get; set; }
        public bool? Attendancemarked { get; set; }
        public string Errormessage { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string AttendancebaseimageurlVc { get; set; }
        public int? ProjectId { get; set; }
    }
}
