﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageSitelevelcomponent
    {
        public WmaFWageSitelevelcomponent()
        {
            WmaFWageComponentsdeductiblefrommaps = new HashSet<WmaFWageComponentsdeductiblefrommap>();
        }

        public long CompTxnId { get; set; }
        public int Componentid { get; set; }
        public decimal Value { get; set; }
        public bool Ispercent { get; set; }
        public bool Isallowancecomponent { get; set; }
        public DateTime Effectivefrom { get; set; }
        public DateTime Effectiveto { get; set; }
        public bool Isactive { get; set; }
        public bool? Isapproved { get; set; }
        public string Approverremarks { get; set; }
        public int CreatedbyId { get; set; }
        public DateTime CreatedonDt { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public long? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public long? ModifiedbyId { get; set; }

        public virtual WmaMUser ApprovedByNavigation { get; set; }
        public virtual WmaMWageSitecomponentMst Component { get; set; }
        public virtual ICollection<WmaFWageComponentsdeductiblefrommap> WmaFWageComponentsdeductiblefrommaps { get; set; }
    }
}
