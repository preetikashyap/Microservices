﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMLabourcolonyRoom
    {
        public long RoomId { get; set; }
        public string RoomnameVc { get; set; }
        public long? FloorId { get; set; }
        public int? RoomcapactiyNb { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
