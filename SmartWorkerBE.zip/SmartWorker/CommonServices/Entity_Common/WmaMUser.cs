﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMUser
    {
        public WmaMUser()
        {
            WmaFNoticeboarddetailCreatedByNavigations = new HashSet<WmaFNoticeboarddetail>();
            WmaFNoticeboarddetailModifiedByNavigations = new HashSet<WmaFNoticeboarddetail>();
            WmaFNoticeboarddetailhistories = new HashSet<WmaFNoticeboarddetailhistory>();
            WmaFReleaserequesthistories = new HashSet<WmaFReleaserequesthistory>();
            WmaFTraProjecttrainingdetailApprovedbies = new HashSet<WmaFTraProjecttrainingdetail>();
            WmaFTraProjecttrainingdetailClosedbies = new HashSet<WmaFTraProjecttrainingdetail>();
            WmaFTraProjecttrainingdetailProjecttrainingapprovers = new HashSet<WmaFTraProjecttrainingdetail>();
            WmaFWageAttendanceregularisationApprovedbyNavigations = new HashSet<WmaFWageAttendanceregularisation>();
            WmaFWageAttendanceregularisationCreatedByNavigations = new HashSet<WmaFWageAttendanceregularisation>();
            WmaFWageOtregularisationApprovalrequestedtos = new HashSet<WmaFWageOtregularisation>();
            WmaFWageOtregularisationApprovedbyNavigations = new HashSet<WmaFWageOtregularisation>();
            WmaFWageOtregularisationCreatedByNavigations = new HashSet<WmaFWageOtregularisation>();
            WmaFWageSitelevelcomponents = new HashSet<WmaFWageSitelevelcomponent>();
            WmaFWorkflowAssignedbies = new HashSet<WmaFWorkflow>();
            WmaFWorkflowAssignedtos = new HashSet<WmaFWorkflow>();
            WmaFWorkflowhistoryAssignedbies = new HashSet<WmaFWorkflowhistory>();
            WmaFWorkflowhistoryAssignedtos = new HashSet<WmaFWorkflowhistory>();
            WmaLActivityprojectrolemappings = new HashSet<WmaLActivityprojectrolemapping>();
            WmaLAdminuserprojectlevelaccesses = new HashSet<WmaLAdminuserprojectlevelaccess>();
            WmaLAdminuserprojectlevelaccesshistories = new HashSet<WmaLAdminuserprojectlevelaccesshistory>();
            WmaLUseradminrolemaps = new HashSet<WmaLUseradminrolemap>();
            WmaLUserprojectrolemaps = new HashSet<WmaLUserprojectrolemap>();
            WmaLUsertreemaps = new HashSet<WmaLUsertreemap>();
            WmaLWorkerprojecttradedetails = new HashSet<WmaLWorkerprojecttradedetail>();
        }

        public long UserId { get; set; }
        public string UsernameVc { get; set; }
        public long? EipuserId { get; set; }
        public string PsnoVc { get; set; }
        public bool? IslntemployeeBt { get; set; }
        public string LoginnameVc { get; set; }
        public string PasswordVc { get; set; }
        public string EmailidVc { get; set; }
        public long? MobilenoNb { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string CustomaccesstokenVc { get; set; }
        public string MedicalregidVc { get; set; }
        public string ClientipVc { get; set; }
        public DateTime? LastloginDt { get; set; }
        public int? WrongattemptNb { get; set; }
        public bool? IsaccountlockedBt { get; set; }
        public DateTime? MobilelastloginDt { get; set; }
        public DateTime? WeblastloginDt { get; set; }
        public string CountrycodeVc { get; set; }
        public short? ResetattemptNb { get; set; }
        public DateTime? LastresetonDt { get; set; }
        public DateTime? PasswordvalidityDt { get; set; }
        public string QuerystringVc { get; set; }
        public DateTime? QuerystringgeneratedonDt { get; set; }

        public virtual ICollection<WmaFNoticeboarddetail> WmaFNoticeboarddetailCreatedByNavigations { get; set; }
        public virtual ICollection<WmaFNoticeboarddetail> WmaFNoticeboarddetailModifiedByNavigations { get; set; }
        public virtual ICollection<WmaFNoticeboarddetailhistory> WmaFNoticeboarddetailhistories { get; set; }
        public virtual ICollection<WmaFReleaserequesthistory> WmaFReleaserequesthistories { get; set; }
        public virtual ICollection<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetailApprovedbies { get; set; }
        public virtual ICollection<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetailClosedbies { get; set; }
        public virtual ICollection<WmaFTraProjecttrainingdetail> WmaFTraProjecttrainingdetailProjecttrainingapprovers { get; set; }
        public virtual ICollection<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisationApprovedbyNavigations { get; set; }
        public virtual ICollection<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisationCreatedByNavigations { get; set; }
        public virtual ICollection<WmaFWageOtregularisation> WmaFWageOtregularisationApprovalrequestedtos { get; set; }
        public virtual ICollection<WmaFWageOtregularisation> WmaFWageOtregularisationApprovedbyNavigations { get; set; }
        public virtual ICollection<WmaFWageOtregularisation> WmaFWageOtregularisationCreatedByNavigations { get; set; }
        public virtual ICollection<WmaFWageSitelevelcomponent> WmaFWageSitelevelcomponents { get; set; }
        public virtual ICollection<WmaFWorkflow> WmaFWorkflowAssignedbies { get; set; }
        public virtual ICollection<WmaFWorkflow> WmaFWorkflowAssignedtos { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistoryAssignedbies { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistoryAssignedtos { get; set; }
        public virtual ICollection<WmaLActivityprojectrolemapping> WmaLActivityprojectrolemappings { get; set; }
        public virtual ICollection<WmaLAdminuserprojectlevelaccess> WmaLAdminuserprojectlevelaccesses { get; set; }
        public virtual ICollection<WmaLAdminuserprojectlevelaccesshistory> WmaLAdminuserprojectlevelaccesshistories { get; set; }
        public virtual ICollection<WmaLUseradminrolemap> WmaLUseradminrolemaps { get; set; }
        public virtual ICollection<WmaLUserprojectrolemap> WmaLUserprojectrolemaps { get; set; }
        public virtual ICollection<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
    }
}
