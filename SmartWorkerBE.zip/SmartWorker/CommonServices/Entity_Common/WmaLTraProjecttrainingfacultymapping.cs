﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLTraProjecttrainingfacultymapping
    {
        public long ProjecttrainingfacultymappingId { get; set; }
        public long ProjecttrainingId { get; set; }
        public string FacultynameVc { get; set; }
        public bool? IsexternalBt { get; set; }
        public string FacultyemailidVc { get; set; }
        public string FacultydesignationVc { get; set; }
        public string FacultyorganizationVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
