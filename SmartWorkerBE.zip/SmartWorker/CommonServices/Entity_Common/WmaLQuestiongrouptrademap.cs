﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLQuestiongrouptrademap
    {
        public long QuestiongrouptrademapId { get; set; }
        public long ChecklistquestiongroupId { get; set; }
        public int? TradeId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaLChecklistquestiongroupmap Checklistquestiongroup { get; set; }
        public virtual WmaMTrade Trade { get; set; }
    }
}
