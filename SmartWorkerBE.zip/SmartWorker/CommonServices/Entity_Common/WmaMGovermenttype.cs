﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMGovermenttype
    {
        public int Typeofgovermentid { get; set; }
        public string Typeofgoverment { get; set; }
        public int? Countryid { get; set; }
        public int? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public int? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public bool? Isactive { get; set; }

        public virtual WmaMGovermenttype TypeofgovermentNavigation { get; set; }
        public virtual WmaMGovermenttype InverseTypeofgovermentNavigation { get; set; }
    }
}
