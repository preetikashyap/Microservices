﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTradesubgroup
    {
        public int TradesubgroupId { get; set; }
        public string TradesubgroupVc { get; set; }
        public int TradegroupId { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMTradegroup Tradegroup { get; set; }
    }
}
