﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageDeductionhistory
    {
        public int Deductionhistoryid { get; set; }
        public int Deductionid { get; set; }
        public int Countryid { get; set; }
        public decimal? Pf { get; set; }
        public decimal? Esic { get; set; }
        public decimal? Society { get; set; }
        public decimal? Incometax { get; set; }
        public decimal? Insurance { get; set; }
        public decimal? Others { get; set; }
        public decimal? Recoveries { get; set; }
        public DateTime Migrateddate { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }
        public long? Projectid { get; set; }
        public DateTime? Fromdate { get; set; }
        public DateTime? Todate { get; set; }
    }
}
