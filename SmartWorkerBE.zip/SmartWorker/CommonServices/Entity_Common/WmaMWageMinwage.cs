﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageMinwage
    {
        public long Wageid { get; set; }
        public int Zonemappingid { get; set; }
        public int Natureofworkid { get; set; }
        public int Tradeid { get; set; }
        public int Tradecategoryid { get; set; }
        public int Tradelevelid { get; set; }
        public decimal Basicwage { get; set; }
        public decimal Da { get; set; }
        public DateTime Effectfrom { get; set; }
        public DateTime Effecttill { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public decimal Others { get; set; }

        public virtual WmaMWageNatureofwork Natureofwork { get; set; }
        public virtual WmaMTrade Trade { get; set; }
        public virtual WmaMSkillcategory Tradecategory { get; set; }
        public virtual WmaMSkilllevel Tradelevel { get; set; }
    }
}
