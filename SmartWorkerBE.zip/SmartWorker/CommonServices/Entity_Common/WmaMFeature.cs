﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMFeature
    {
        public int FeatureId { get; set; }
        public string Featurename { get; set; }
        public string FeaturedescVc { get; set; }
        public string FeaturecodeVc { get; set; }
        public bool? IsaddonfeatureBt { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
