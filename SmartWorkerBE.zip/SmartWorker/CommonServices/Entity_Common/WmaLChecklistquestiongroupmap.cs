﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLChecklistquestiongroupmap
    {
        public WmaLChecklistquestiongroupmap()
        {
            WmaLChecklistquestionsmaps = new HashSet<WmaLChecklistquestionsmap>();
            WmaLQuestiongrouptrademaps = new HashSet<WmaLQuestiongrouptrademap>();
        }

        public long ChecklistquestiongroupId { get; set; }
        public string ChecklistquestiongroupdescVc { get; set; }
        public long ChecklistId { get; set; }
        public int? TradeId { get; set; }
        public int? ValidityperiodNb { get; set; }
        public bool? IsdefaultBt { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMChecklist Checklist { get; set; }
        public virtual WmaMTrade Trade { get; set; }
        public virtual ICollection<WmaLChecklistquestionsmap> WmaLChecklistquestionsmaps { get; set; }
        public virtual ICollection<WmaLQuestiongrouptrademap> WmaLQuestiongrouptrademaps { get; set; }
    }
}
