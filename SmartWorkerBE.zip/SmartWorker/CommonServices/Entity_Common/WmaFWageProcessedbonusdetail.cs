﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageProcessedbonusdetail
    {
        public long Id { get; set; }
        public long Workerwagemappingid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public long Tradeid { get; set; }
        public int Componentid { get; set; }
        public decimal Amount { get; set; }
        public DateTime Processingmonth { get; set; }
        public bool Ispercent { get; set; }
        public DateTime Effectivefrom { get; set; }
        public DateTime Effectiveto { get; set; }
        public bool? Isactive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
