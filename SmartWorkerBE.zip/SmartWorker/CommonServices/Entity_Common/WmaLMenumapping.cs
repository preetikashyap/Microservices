﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLMenumapping
    {
        public long MenumappingId { get; set; }
        public int MainmenuId { get; set; }
        public int? SubmenuId { get; set; }
        public string ControllernameVc { get; set; }
        public string ActionnameVc { get; set; }
        public int? OrderbyId { get; set; }
        public string ImagepathVc { get; set; }
        public int? RoleId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMMainmenu Mainmenu { get; set; }
    }
}
