﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMSubprojectjoineip
    {
        public long Subprojectjoineipid { get; set; }
        public int Subprojectid { get; set; }
        public int Workerid { get; set; }
        public bool? Isalreadyjoinedeip { get; set; }
    }
}
