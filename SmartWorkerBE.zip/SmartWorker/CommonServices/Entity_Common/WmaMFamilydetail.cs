﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMFamilydetail
    {
        public long Familyid { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public int? RelationTypeid { get; set; }
        public string Name { get; set; }
        public string Remarls { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
