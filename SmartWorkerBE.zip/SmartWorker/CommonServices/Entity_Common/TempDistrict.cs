﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class TempDistrict
    {
        public int? Id { get; set; }
        public string Statecode { get; set; }
        public string Statename { get; set; }
        public string Xdistrictcode { get; set; }
        public string Districtcode { get; set; }
        public string District { get; set; }
        public string Title { get; set; }
    }
}
