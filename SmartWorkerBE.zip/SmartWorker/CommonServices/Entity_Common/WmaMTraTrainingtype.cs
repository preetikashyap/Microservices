﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTraTrainingtype
    {
        public WmaMTraTrainingtype()
        {
            WmaFTraTrainings = new HashSet<WmaFTraTraining>();
        }

        public int TrainingtypeId { get; set; }
        public string TrainingtypeVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual ICollection<WmaFTraTraining> WmaFTraTrainings { get; set; }
    }
}
