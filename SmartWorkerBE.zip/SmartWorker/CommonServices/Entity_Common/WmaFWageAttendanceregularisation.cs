﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageAttendanceregularisation
    {
        public long AttendanceRegularisationId { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Intime { get; set; }
        public TimeSpan Outtime { get; set; }
        public int Shiftid { get; set; }
        public int Regularisationtypeid { get; set; }
        public long Approvalrequestedtoid { get; set; }
        public bool? Isapproved { get; set; }
        public string Requestremarks { get; set; }
        public string Approvalremarks { get; set; }
        public long? Approvedby { get; set; }
        public DateTime? Approvedon { get; set; }
        public bool Isprocessed { get; set; }
        public bool Isexcelupload { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }

        public virtual WmaMUser ApprovedbyNavigation { get; set; }
        public virtual WmaMUser CreatedByNavigation { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaMRegularisationtype Regularisationtype { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
