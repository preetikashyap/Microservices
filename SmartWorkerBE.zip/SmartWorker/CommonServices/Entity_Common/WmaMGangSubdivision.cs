﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMGangSubdivision
    {
        public long SubdivisionId { get; set; }
        public string SubdivisionnameVc { get; set; }
        public string SubdivisiondescriptionVc { get; set; }
        public long? DivisionId { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public long? Subdivisionloe { get; set; }
    }
}
