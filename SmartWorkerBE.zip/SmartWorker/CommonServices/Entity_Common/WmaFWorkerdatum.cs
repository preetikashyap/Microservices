﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWorkerdatum
    {
        public WmaFWorkerdatum()
        {
            WmaFAppreciations = new HashSet<WmaFAppreciation>();
            WmaFAwsrequestresponsedetails = new HashSet<WmaFAwsrequestresponsedetail>();
            WmaFBlacklists = new HashSet<WmaFBlacklist>();
            WmaFChecklistquestionsresponses = new HashSet<WmaFChecklistquestionsresponse>();
            WmaFMedicalchecklistquestionsresponses = new HashSet<WmaFMedicalchecklistquestionsresponse>();
            WmaFRankingchecklistquestionsresponses = new HashSet<WmaFRankingchecklistquestionsresponse>();
            WmaFReleaserequesthistories = new HashSet<WmaFReleaserequesthistory>();
            WmaFReleaserequests = new HashSet<WmaFReleaserequest>();
            WmaFWageAttendanceregularisations = new HashSet<WmaFWageAttendanceregularisation>();
            WmaFWageFullandfinalsettlements = new HashSet<WmaFWageFullandfinalsettlement>();
            WmaFWageOtregularisations = new HashSet<WmaFWageOtregularisation>();
            WmaFWorkerattachments = new HashSet<WmaFWorkerattachment>();
            WmaFWorkercovid19maphistories = new HashSet<WmaFWorkercovid19maphistory>();
            WmaFWorkercovid19maps = new HashSet<WmaFWorkercovid19map>();
            WmaFWorkerleavebalancehistories = new HashSet<WmaFWorkerleavebalancehistory>();
            WmaFWorkerleavedetails = new HashSet<WmaFWorkerleavedetail>();
            WmaFWorkerobservationdetails = new HashSet<WmaFWorkerobservationdetail>();
            WmaFWorkerselfdeclarationmaps = new HashSet<WmaFWorkerselfdeclarationmap>();
            WmaFWorkertravellinghistories = new HashSet<WmaFWorkertravellinghistory>();
            WmaFWorkervitals = new HashSet<WmaFWorkervital>();
            WmaFWorkflowhistories = new HashSet<WmaFWorkflowhistory>();
            WmaFWorkflows = new HashSet<WmaFWorkflow>();
            WmaLCertificationdetails = new HashSet<WmaLCertificationdetail>();
            WmaLChecklistfortestvalidities = new HashSet<WmaLChecklistfortestvalidity>();
            WmaLEducationdetails = new HashSet<WmaLEducationdetail>();
            WmaLExperiences = new HashSet<WmaLExperience>();
            WmaLTraProjecttrainingattendances = new HashSet<WmaLTraProjecttrainingattendance>();
            WmaLWorkerbankdetails = new HashSet<WmaLWorkerbankdetail>();
            WmaLWorkerkycdocuments = new HashSet<WmaLWorkerkycdocument>();
            WmaLWorkerkycs = new HashSet<WmaLWorkerkyc>();
            WmaLWorkerprojecttradedetails = new HashSet<WmaLWorkerprojecttradedetail>();
            WmaLWorkerprojecttradedetailshistories = new HashSet<WmaLWorkerprojecttradedetailshistory>();
            WmaMFamilydetails = new HashSet<WmaMFamilydetail>();
            WmaMReferredbydetails = new HashSet<WmaMReferredbydetail>();
        }

        public long WorkerId { get; set; }
        public long? AadhaarnoNb { get; set; }
        public long? EipId { get; set; }
        public string WorkernameVc { get; set; }
        public string FatherSpouseVc { get; set; }
        public int? EmploymenttypeId { get; set; }
        public string SubcontractornameVc { get; set; }
        public string PresentAddrVc { get; set; }
        public string PermanentAddrVc { get; set; }
        public string BirthplaceVc { get; set; }
        public DateTime? DobDt { get; set; }
        public int? AgeNb { get; set; }
        public string GenderVc { get; set; }
        public long? MobilenoNb { get; set; }
        public long? TelephonenoNb { get; set; }
        public int? MaritalstatusId { get; set; }
        public int? ChildernNb { get; set; }
        public int? LanguageId { get; set; }
        public string LanguagesknownVc { get; set; }
        public string EmergencycontactnameVc { get; set; }
        public long? EmergencycontactnumberNb { get; set; }
        public string EmergencycontactaddressVc { get; set; }
        public string EmergencycontactrelationVc { get; set; }
        public string IdentificationmarkVc { get; set; }
        public bool? IsguiltyforcrimeBt { get; set; }
        public string GuiltyCrimeVc { get; set; }
        public int? NationalityId { get; set; }
        public bool? HastakencstiBt { get; set; }
        public string CstiidVc { get; set; }
        public string Ehsinductionid { get; set; }
        public string WorkerrecordstatusVc { get; set; }
        public int? ProjectId { get; set; }
        public string PhotourlVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? IsnapsBt { get; set; }
        public string IdprooftypeVc { get; set; }
        public string IdproofnumberVc { get; set; }
        public string Vendorcode { get; set; }
        public string QrcodeurlVc { get; set; }
        public DateTime? QrcodeissuedDt { get; set; }
        public long? EntrypassvalidityNb { get; set; }
        public DateTime? QrexpiryonDt { get; set; }
        public string QrstatusVc { get; set; }
        public string CountrycodeVc { get; set; }
        public string EmergencycountrycodeVc { get; set; }
        public string BloodgroupVc { get; set; }
        public string PresentAddr1Vc { get; set; }
        public string PresentAddr2Vc { get; set; }
        public string PresentCityVc { get; set; }
        public int? PresentStateNb { get; set; }
        public string PresentPincodeVc { get; set; }
        public int? PresentCountryNb { get; set; }
        public string PermanentAddr1Vc { get; set; }
        public string PermanentAddr2Vc { get; set; }
        public string PermanentCityVc { get; set; }
        public int? PermanentStateNb { get; set; }
        public string PermanentPincodeVc { get; set; }
        public int? PermanentCountryNb { get; set; }
        public bool? HitjoinapiBt { get; set; }
        public bool? IsRlsWorker { get; set; }
        public string WorkeremailVc { get; set; }
        public bool? Isrlsacquaintancesinlnt { get; set; }
        public string NameofrelativeVc { get; set; }
        public string RelationtypeVc { get; set; }
        public DateTime? Rlsfromdate { get; set; }
        public DateTime? Rlstodate { get; set; }

        public virtual WmaMEmploymenttype Employmenttype { get; set; }
        public virtual WmaMLanguage Language { get; set; }
        public virtual WmaMMaritalstatus Maritalstatus { get; set; }
        public virtual WmaMCountry Nationality { get; set; }
        public virtual ICollection<WmaFAppreciation> WmaFAppreciations { get; set; }
        public virtual ICollection<WmaFAwsrequestresponsedetail> WmaFAwsrequestresponsedetails { get; set; }
        public virtual ICollection<WmaFBlacklist> WmaFBlacklists { get; set; }
        public virtual ICollection<WmaFChecklistquestionsresponse> WmaFChecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFMedicalchecklistquestionsresponse> WmaFMedicalchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFRankingchecklistquestionsresponse> WmaFRankingchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFReleaserequesthistory> WmaFReleaserequesthistories { get; set; }
        public virtual ICollection<WmaFReleaserequest> WmaFReleaserequests { get; set; }
        public virtual ICollection<WmaFWageAttendanceregularisation> WmaFWageAttendanceregularisations { get; set; }
        public virtual ICollection<WmaFWageFullandfinalsettlement> WmaFWageFullandfinalsettlements { get; set; }
        public virtual ICollection<WmaFWageOtregularisation> WmaFWageOtregularisations { get; set; }
        public virtual ICollection<WmaFWorkerattachment> WmaFWorkerattachments { get; set; }
        public virtual ICollection<WmaFWorkercovid19maphistory> WmaFWorkercovid19maphistories { get; set; }
        public virtual ICollection<WmaFWorkercovid19map> WmaFWorkercovid19maps { get; set; }
        public virtual ICollection<WmaFWorkerleavebalancehistory> WmaFWorkerleavebalancehistories { get; set; }
        public virtual ICollection<WmaFWorkerleavedetail> WmaFWorkerleavedetails { get; set; }
        public virtual ICollection<WmaFWorkerobservationdetail> WmaFWorkerobservationdetails { get; set; }
        public virtual ICollection<WmaFWorkerselfdeclarationmap> WmaFWorkerselfdeclarationmaps { get; set; }
        public virtual ICollection<WmaFWorkertravellinghistory> WmaFWorkertravellinghistories { get; set; }
        public virtual ICollection<WmaFWorkervital> WmaFWorkervitals { get; set; }
        public virtual ICollection<WmaFWorkflowhistory> WmaFWorkflowhistories { get; set; }
        public virtual ICollection<WmaFWorkflow> WmaFWorkflows { get; set; }
        public virtual ICollection<WmaLCertificationdetail> WmaLCertificationdetails { get; set; }
        public virtual ICollection<WmaLChecklistfortestvalidity> WmaLChecklistfortestvalidities { get; set; }
        public virtual ICollection<WmaLEducationdetail> WmaLEducationdetails { get; set; }
        public virtual ICollection<WmaLExperience> WmaLExperiences { get; set; }
        public virtual ICollection<WmaLTraProjecttrainingattendance> WmaLTraProjecttrainingattendances { get; set; }
        public virtual ICollection<WmaLWorkerbankdetail> WmaLWorkerbankdetails { get; set; }
        public virtual ICollection<WmaLWorkerkycdocument> WmaLWorkerkycdocuments { get; set; }
        public virtual ICollection<WmaLWorkerkyc> WmaLWorkerkycs { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetailshistory> WmaLWorkerprojecttradedetailshistories { get; set; }
        public virtual ICollection<WmaMFamilydetail> WmaMFamilydetails { get; set; }
        public virtual ICollection<WmaMReferredbydetail> WmaMReferredbydetails { get; set; }
    }
}
