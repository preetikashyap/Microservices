﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMCluster
    {
        public WmaMCluster()
        {
            WmaLUsertreemaps = new HashSet<WmaLUsertreemap>();
            WmaMProjects = new HashSet<WmaMProject>();
        }

        public int ClusterId { get; set; }
        public string ClustercodeVc { get; set; }
        public string ClusternameVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? SegmentId { get; set; }

        public virtual ICollection<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
        public virtual ICollection<WmaMProject> WmaMProjects { get; set; }
    }
}
