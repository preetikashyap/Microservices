﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFReleaserequest
    {
        public WmaFReleaserequest()
        {
            WmaFReleaserequesthistories = new HashSet<WmaFReleaserequesthistory>();
        }

        public long ReleaserequestId { get; set; }
        public int ExistingprojectId { get; set; }
        public int RequestingprojectId { get; set; }
        public long WorkerId { get; set; }
        public int SubmittedbyId { get; set; }
        public DateTime? SubmittedonDt { get; set; }
        public string CommentsVc { get; set; }
        public bool IsreleasedBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMProject Existingproject { get; set; }
        public virtual WmaMProject Requestingproject { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
        public virtual ICollection<WmaFReleaserequesthistory> WmaFReleaserequesthistories { get; set; }
    }
}
