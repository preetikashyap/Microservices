﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMState
    {
        public WmaMState()
        {
            WmaFWorkertravellinghistories = new HashSet<WmaFWorkertravellinghistory>();
            WmaLWageZonemappings = new HashSet<WmaLWageZonemapping>();
            WmaMCities = new HashSet<WmaMCity>();
        }

        public int StateId { get; set; }
        public string StateVc { get; set; }
        public int CountryId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string LatitudeVc { get; set; }
        public string LongitudeVc { get; set; }

        public virtual WmaMCountry Country { get; set; }
        public virtual ICollection<WmaFWorkertravellinghistory> WmaFWorkertravellinghistories { get; set; }
        public virtual ICollection<WmaLWageZonemapping> WmaLWageZonemappings { get; set; }
        public virtual ICollection<WmaMCity> WmaMCities { get; set; }
    }
}
