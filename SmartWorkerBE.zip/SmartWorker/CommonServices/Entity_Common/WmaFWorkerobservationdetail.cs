﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWorkerobservationdetail
    {
        public int WorkerobservationdetailId { get; set; }
        public long? WorkerId { get; set; }
        public int? ObservationcategoryId { get; set; }
        public int? ObservationsubcategoryId { get; set; }
        public string ObservationdescriptionVc { get; set; }
        public DateTime? ObservationraisedonDt { get; set; }
        public string ObservationraisedbyVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string ObservationlocationVc { get; set; }
        public int? ProjectId { get; set; }

        public virtual WmaMObservationcategory Observationcategory { get; set; }
        public virtual WmaMObservationsubcategory Observationsubcategory { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
