﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMApiconfigdetail
    {
        public int ApiconfigdetailsId { get; set; }
        public string ApikeyVc { get; set; }
        public string ApiurlVc { get; set; }
        public string ApiusernameVc { get; set; }
        public string ApipasswordVc { get; set; }
        public string ApicompanycodeVc { get; set; }
        public string ApiVendorcodeVc { get; set; }
        public string ClientidVc { get; set; }
        public string SecretkeyVc { get; set; }
        public string DtcodeVc { get; set; }
        public string EnvironmentVc { get; set; }
        public string EnvironmentIpAddressVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public int? ApplicationId { get; set; }
    }
}
