﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMLicensetype
    {
        public WmaMLicensetype()
        {
            WmaFCompliancedetails = new HashSet<WmaFCompliancedetail>();
            WmaLProjectattachments = new HashSet<WmaLProjectattachment>();
        }

        public int LicensetypeId { get; set; }
        public string LicensetypeVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaFCompliancedetail> WmaFCompliancedetails { get; set; }
        public virtual ICollection<WmaLProjectattachment> WmaLProjectattachments { get; set; }
    }
}
