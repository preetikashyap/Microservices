﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLGenericmessage
    {
        public long Id { get; set; }
        public string Messagetype { get; set; }
        public string Functionality { get; set; }
        public DateTime? Effectfrom { get; set; }
        public DateTime? Effecttill { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public string Message { get; set; }
    }
}
