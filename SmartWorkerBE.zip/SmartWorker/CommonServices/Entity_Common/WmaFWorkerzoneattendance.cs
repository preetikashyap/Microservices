﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWorkerzoneattendance
    {
        public long WorkerzoneattendanceId { get; set; }
        public long? WorkerId { get; set; }
        public long? ZoneId { get; set; }
        public long? ProjectId { get; set; }
        public DateTime? InattendanceDt { get; set; }
        public DateTime? OutattendanceDt { get; set; }
        public bool IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
