﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWorkerleavedetail
    {
        public long Id { get; set; }
        public long Workerid { get; set; }
        public int Projectid { get; set; }
        public DateTime Fromdate { get; set; }
        public DateTime Todate { get; set; }
        public int Leavetypeid { get; set; }
        public long Attachmentid { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }
        public int? Modifiedby { get; set; }
        public DateTime? Modifiedon { get; set; }

        public virtual WmaMLeavetype Leavetype { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
