﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFBiometricfilelog
    {
        public WmaFBiometricfilelog()
        {
            WmaFBiometricdata = new HashSet<WmaFBiometricdatum>();
            WmaFBiometricdatajunkdata = new HashSet<WmaFBiometricdatajunkdatum>();
        }

        public long BiometricfilelogId { get; set; }
        public DateTime? ProcessstartsatDt { get; set; }
        public DateTime? ProcessendsatDt { get; set; }
        public int? NoofworkersInt { get; set; }
        public string FilestatusVc { get; set; }
        public string MessageVc { get; set; }
        public string FilenameVc { get; set; }
        public int? BiometricschedulerId { get; set; }

        public virtual WmaFBiometricscheduler Biometricscheduler { get; set; }
        public virtual ICollection<WmaFBiometricdatum> WmaFBiometricdata { get; set; }
        public virtual ICollection<WmaFBiometricdatajunkdatum> WmaFBiometricdatajunkdata { get; set; }
    }
}
