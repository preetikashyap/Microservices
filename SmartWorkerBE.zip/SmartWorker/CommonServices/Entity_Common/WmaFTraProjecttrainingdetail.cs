﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFTraProjecttrainingdetail
    {
        public WmaFTraProjecttrainingdetail()
        {
            WmaLTraProjecttrainingattachments = new HashSet<WmaLTraProjecttrainingattachment>();
            WmaLTraProjecttrainingattendances = new HashSet<WmaLTraProjecttrainingattendance>();
            WmaLTraProjecttrainingconcernedusersmappings = new HashSet<WmaLTraProjecttrainingconcernedusersmapping>();
            WmaLTraProjecttrainingsubcontractormappings = new HashSet<WmaLTraProjecttrainingsubcontractormapping>();
        }

        public long ProjecttrainingId { get; set; }
        public int TrainingId { get; set; }
        public int ProjectId { get; set; }
        public DateTime? Trainingscheduleddate { get; set; }
        public int? ParticipantsexpectedcountNb { get; set; }
        public string Venueormaterials { get; set; }
        public string Trainingoverallbenefits { get; set; }
        public string Trainingremarks { get; set; }
        public long? ProjecttrainingapproverId { get; set; }
        public string ProjecttrainingstatusVc { get; set; }
        public long? ApprovedbyId { get; set; }
        public DateTime? ApprovedonDt { get; set; }
        public string Projecttrainingfeedback { get; set; }
        public string Projecttrainingscopeforimprovement { get; set; }
        public long? ClosedbyId { get; set; }
        public DateTime? ClosedonDt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string RemarksVc { get; set; }

        public virtual WmaMUser Approvedby { get; set; }
        public virtual WmaMUser Closedby { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual WmaMUser Projecttrainingapprover { get; set; }
        public virtual WmaFTraTraining Training { get; set; }
        public virtual ICollection<WmaLTraProjecttrainingattachment> WmaLTraProjecttrainingattachments { get; set; }
        public virtual ICollection<WmaLTraProjecttrainingattendance> WmaLTraProjecttrainingattendances { get; set; }
        public virtual ICollection<WmaLTraProjecttrainingconcernedusersmapping> WmaLTraProjecttrainingconcernedusersmappings { get; set; }
        public virtual ICollection<WmaLTraProjecttrainingsubcontractormapping> WmaLTraProjecttrainingsubcontractormappings { get; set; }
    }
}
