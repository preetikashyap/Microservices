﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLProjectrlsworkflowmap
    {
        public long ProjectworkflowmapId { get; set; }
        public string WorkflowstageVc { get; set; }
        public int ProjectId { get; set; }
        public int SortorderNb { get; set; }
        public long? ChecklistId { get; set; }
        public long ApprovalroleId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMRole Approvalrole { get; set; }
        public virtual WmaMChecklist Checklist { get; set; }
        public virtual WmaMProject Project { get; set; }
    }
}
