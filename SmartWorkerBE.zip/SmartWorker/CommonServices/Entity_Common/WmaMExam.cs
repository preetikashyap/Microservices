﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMExam
    {
        public WmaMExam()
        {
            WmaLEducationdetails = new HashSet<WmaLEducationdetail>();
        }

        public int ExamId { get; set; }
        public string ExamVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual ICollection<WmaLEducationdetail> WmaLEducationdetails { get; set; }
    }
}
