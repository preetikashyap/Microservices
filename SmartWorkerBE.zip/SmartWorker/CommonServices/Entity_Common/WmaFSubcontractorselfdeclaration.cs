﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFSubcontractorselfdeclaration
    {
        public long Subcontractorsdid { get; set; }
        public string Vendorcode { get; set; }
        public string Vendorname { get; set; }
        public int Noofworkers { get; set; }
        public long Attachmentid { get; set; }
        public int Projectid { get; set; }
        public bool Isactive { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string Contractorname { get; set; }
        public string Mobileno { get; set; }

        public virtual WmaMProject Project { get; set; }
    }
}
