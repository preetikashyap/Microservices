﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMChecklist
    {
        public WmaMChecklist()
        {
            Testworkflows = new HashSet<Testworkflow>();
            WmaFChecklistquestionsresponses = new HashSet<WmaFChecklistquestionsresponse>();
            WmaFMedicalchecklistquestionsresponses = new HashSet<WmaFMedicalchecklistquestionsresponse>();
            WmaFRankingchecklistquestionsresponses = new HashSet<WmaFRankingchecklistquestionsresponse>();
            WmaLChecklistfortestvalidities = new HashSet<WmaLChecklistfortestvalidity>();
            WmaLChecklistquesresponsetypemaps = new HashSet<WmaLChecklistquesresponsetypemap>();
            WmaLChecklistquestiongroupmaps = new HashSet<WmaLChecklistquestiongroupmap>();
            WmaLProjectMedicalperiodicchecklistmappings = new HashSet<WmaLProjectMedicalperiodicchecklistmapping>();
            WmaLProjectchecklistmaps = new HashSet<WmaLProjectchecklistmap>();
            WmaLProjectrlsworkflowmaps = new HashSet<WmaLProjectrlsworkflowmap>();
            WmaLProjectrlsworkflowmaptest1s = new HashSet<WmaLProjectrlsworkflowmaptest1>();
            WmaLProjectworkerevaluationchecklistmappings = new HashSet<WmaLProjectworkerevaluationchecklistmapping>();
            WmaLProjectworkflowmaps = new HashSet<WmaLProjectworkflowmap>();
        }

        public long ChecklistId { get; set; }
        public string ChecklistcodeVc { get; set; }
        public string ChecklistnameVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public long? ChecklistclonedfromId { get; set; }
        public bool? IsspecialchecklistBt { get; set; }
        public int? AssignedtoroleId { get; set; }
        public bool? IsrankedchecklistBt { get; set; }
        public bool? Ismedicalchecklist { get; set; }
        public long? ChecklistCategoryid { get; set; }

        public virtual ICollection<Testworkflow> Testworkflows { get; set; }
        public virtual ICollection<WmaFChecklistquestionsresponse> WmaFChecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFMedicalchecklistquestionsresponse> WmaFMedicalchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFRankingchecklistquestionsresponse> WmaFRankingchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaLChecklistfortestvalidity> WmaLChecklistfortestvalidities { get; set; }
        public virtual ICollection<WmaLChecklistquesresponsetypemap> WmaLChecklistquesresponsetypemaps { get; set; }
        public virtual ICollection<WmaLChecklistquestiongroupmap> WmaLChecklistquestiongroupmaps { get; set; }
        public virtual ICollection<WmaLProjectMedicalperiodicchecklistmapping> WmaLProjectMedicalperiodicchecklistmappings { get; set; }
        public virtual ICollection<WmaLProjectchecklistmap> WmaLProjectchecklistmaps { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmap> WmaLProjectrlsworkflowmaps { get; set; }
        public virtual ICollection<WmaLProjectrlsworkflowmaptest1> WmaLProjectrlsworkflowmaptest1s { get; set; }
        public virtual ICollection<WmaLProjectworkerevaluationchecklistmapping> WmaLProjectworkerevaluationchecklistmappings { get; set; }
        public virtual ICollection<WmaLProjectworkflowmap> WmaLProjectworkflowmaps { get; set; }
    }
}
