﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLProjectfeaturemapping
    {
        public int ProjectfeaturemappingId { get; set; }
        public int? ProjectId { get; set; }
        public int? FeatureId { get; set; }
        public DateTime? ValidfromDt { get; set; }
        public DateTime? ValidtillDt { get; set; }
        public bool? IsactiveBt { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public long? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
