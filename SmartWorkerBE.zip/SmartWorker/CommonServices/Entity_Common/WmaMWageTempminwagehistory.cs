﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageTempminwagehistory
    {
        public long Wagetemphistoryid { get; set; }
        public long Wageid { get; set; }
        public int Zonemappingid { get; set; }
        public decimal Oldwage { get; set; }
        public decimal Newwage { get; set; }
        public DateTime? Oldeffectfrom { get; set; }
        public DateTime? Oldeffecttill { get; set; }
        public DateTime? Effectfrom { get; set; }
        public DateTime? Effecttill { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public decimal Oldda { get; set; }
        public decimal Newda { get; set; }
        public decimal Oldothers { get; set; }
        public decimal Newothers { get; set; }
    }
}
