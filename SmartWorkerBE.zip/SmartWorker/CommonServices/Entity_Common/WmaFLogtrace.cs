﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFLogtrace
    {
        public int LogId { get; set; }
        public string UseridVc { get; set; }
        public string LogmessageVc { get; set; }
        public string LogtypeVc { get; set; }
        public DateTime? LogdateDt { get; set; }
    }
}
