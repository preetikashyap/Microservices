﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFNoticeboardrolecategorymap
    {
        public short Id { get; set; }
        public long RoleId { get; set; }
        public short CategoryId { get; set; }
        public bool? IsSubcategory { get; set; }
        public bool ReadAccess { get; set; }
        public bool UploadAccess { get; set; }
        public bool DeleteAccess { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsActive { get; set; }

        public virtual WmaMRole Role { get; set; }
    }
}
