﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTraTrainingmode
    {
        public int TrainingmodeId { get; set; }
        public string TrainingmodeVc { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
    }
}
