﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageArreartype
    {
        public int Arreartypeid { get; set; }
        public string Arreartype { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public bool? Isactive { get; set; }
    }
}
