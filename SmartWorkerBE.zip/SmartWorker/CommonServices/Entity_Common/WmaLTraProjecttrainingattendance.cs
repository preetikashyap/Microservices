﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLTraProjecttrainingattendance
    {
        public long ProjecttrainingattendanceId { get; set; }
        public long? ProjecttrainingId { get; set; }
        public string TrainingattendancetypeVc { get; set; }
        public long? WorkerId { get; set; }
        public DateTime? AttendancesubmittedDt { get; set; }
        public string ErrormessageVc { get; set; }
        public long? AwsfacerecognitiontransactionId { get; set; }
        public long? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }

        public virtual WmaFTraProjecttrainingdetail Projecttraining { get; set; }
        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
