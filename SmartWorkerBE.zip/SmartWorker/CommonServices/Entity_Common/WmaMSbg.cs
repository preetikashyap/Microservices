﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMSbg
    {
        public WmaMSbg()
        {
            WmaLUsertreemaps = new HashSet<WmaLUsertreemap>();
            WmaMBus = new HashSet<WmaMBu>();
            WmaMProjects = new HashSet<WmaMProject>();
        }

        public int SbgId { get; set; }
        public string SbgcodeVc { get; set; }
        public string SbgnameVc { get; set; }
        public int IcId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMIc Ic { get; set; }
        public virtual ICollection<WmaLUsertreemap> WmaLUsertreemaps { get; set; }
        public virtual ICollection<WmaMBu> WmaMBus { get; set; }
        public virtual ICollection<WmaMProject> WmaMProjects { get; set; }
    }
}
