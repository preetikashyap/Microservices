﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWorkerattachment
    {
        public WmaFWorkerattachment()
        {
            WmaFCoviddocumentmaps = new HashSet<WmaFCoviddocumentmap>();
        }

        public long WorkerattachmentId { get; set; }
        public long? WorkerId { get; set; }
        public string WorkerattachmentnameVc { get; set; }
        public string WorkerattachmenturlVc { get; set; }
        public string WorkerattachmentformatVc { get; set; }
        public string WorkerattachmentcategoryVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? Isactive { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
        public virtual ICollection<WmaFCoviddocumentmap> WmaFCoviddocumentmaps { get; set; }
    }
}
