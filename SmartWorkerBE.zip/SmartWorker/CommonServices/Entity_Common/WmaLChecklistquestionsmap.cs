﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLChecklistquestionsmap
    {
        public WmaLChecklistquestionsmap()
        {
            WmaFChecklistquestionsresponses = new HashSet<WmaFChecklistquestionsresponse>();
            WmaFMedicalchecklistquestionsresponses = new HashSet<WmaFMedicalchecklistquestionsresponse>();
            WmaFRankingchecklistquestionsresponses = new HashSet<WmaFRankingchecklistquestionsresponse>();
            WmaLChecklistquesresponsetypemaps = new HashSet<WmaLChecklistquesresponsetypemap>();
        }

        public long ChecklistquestionsmapId { get; set; }
        public string ChecklistquestionsdescVc { get; set; }
        public long ChecklistquestiongrpId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaLChecklistquestiongroupmap Checklistquestiongrp { get; set; }
        public virtual ICollection<WmaFChecklistquestionsresponse> WmaFChecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFMedicalchecklistquestionsresponse> WmaFMedicalchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaFRankingchecklistquestionsresponse> WmaFRankingchecklistquestionsresponses { get; set; }
        public virtual ICollection<WmaLChecklistquesresponsetypemap> WmaLChecklistquesresponsetypemaps { get; set; }
    }
}
