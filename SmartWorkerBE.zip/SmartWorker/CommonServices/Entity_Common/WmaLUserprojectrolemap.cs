﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLUserprojectrolemap
    {
        public WmaLUserprojectrolemap()
        {
            WmaLUsertradeapprovermaps = new HashSet<WmaLUsertradeapprovermap>();
        }

        public long UserprojectrolemapId { get; set; }
        public long UserId { get; set; }
        public long RoleId { get; set; }
        public int ProjectId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMProject Project { get; set; }
        public virtual WmaMRole Role { get; set; }
        public virtual WmaMUser User { get; set; }
        public virtual ICollection<WmaLUsertradeapprovermap> WmaLUsertradeapprovermaps { get; set; }
    }
}
