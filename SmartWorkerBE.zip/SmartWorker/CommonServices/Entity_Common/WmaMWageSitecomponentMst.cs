﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageSitecomponentMst
    {
        public WmaMWageSitecomponentMst()
        {
            WmaFWageComponentsdeductiblefrommaps = new HashSet<WmaFWageComponentsdeductiblefrommap>();
            WmaFWageSitelevelcomponents = new HashSet<WmaFWageSitelevelcomponent>();
            WmaFWageWorkersitelevelcompdetails = new HashSet<WmaFWageWorkersitelevelcompdetail>();
        }

        public int Componentid { get; set; }
        public string Componentname { get; set; }
        public bool Isstandardcomponent { get; set; }
        public int? Projectid { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModififiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Isactive { get; set; }

        public virtual ICollection<WmaFWageComponentsdeductiblefrommap> WmaFWageComponentsdeductiblefrommaps { get; set; }
        public virtual ICollection<WmaFWageSitelevelcomponent> WmaFWageSitelevelcomponents { get; set; }
        public virtual ICollection<WmaFWageWorkersitelevelcompdetail> WmaFWageWorkersitelevelcompdetails { get; set; }
    }
}
