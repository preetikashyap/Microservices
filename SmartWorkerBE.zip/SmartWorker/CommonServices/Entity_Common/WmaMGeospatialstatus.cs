﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMGeospatialstatus
    {
        public WmaMGeospatialstatus()
        {
            WmaFWorkertravellinghistories = new HashSet<WmaFWorkertravellinghistory>();
        }

        public int Geospatialstatusid { get; set; }
        public string Geospatialstatusvalue { get; set; }

        public virtual ICollection<WmaFWorkertravellinghistory> WmaFWorkertravellinghistories { get; set; }
    }
}
