﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageMinwagehistory
    {
        public long Wagehistoryid { get; set; }
        public long Wageid { get; set; }
        public decimal Basicwage { get; set; }
        public decimal Da { get; set; }
        public DateTime Effectfrom { get; set; }
        public DateTime Effecttill { get; set; }
        public DateTime? Historycreatedon { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public decimal Others { get; set; }
    }
}
