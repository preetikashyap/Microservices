﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageNatureofwork
    {
        public WmaMWageNatureofwork()
        {
            WmaMWageMinwages = new HashSet<WmaMWageMinwage>();
        }

        public int Natureofworkid { get; set; }
        public string Natureofwork { get; set; }
        public int? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public int? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public bool? Isactive { get; set; }

        public virtual ICollection<WmaMWageMinwage> WmaMWageMinwages { get; set; }
    }
}
