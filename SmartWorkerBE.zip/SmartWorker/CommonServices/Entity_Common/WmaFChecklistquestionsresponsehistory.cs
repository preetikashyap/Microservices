﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFChecklistquestionsresponsehistory
    {
        public long ChecklistresponsehistoryId { get; set; }
        public long? ChecklistresponseId { get; set; }
        public long WorkerId { get; set; }
        public long ChecklistquestionsmapId { get; set; }
        public long ChecklistId { get; set; }
        public string ResponseVc { get; set; }
        public string ResponsecommentsVc { get; set; }
        public string AttachmentnameVc { get; set; }
        public string AttachmenttypeVc { get; set; }
        public string AttachmenturlVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
