﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFApirequestresponsedetail
    {
        public long ReqresId { get; set; }
        public string ActionnameVc { get; set; }
        public string FullurlVc { get; set; }
        public string RequestVc { get; set; }
        public string ResponseVc { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? Projectid { get; set; }
    }
}
