﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLProjectchecklistmap
    {
        public long ProjectchecklistmapId { get; set; }
        public long ChecklistId { get; set; }
        public int ProjectId { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaMChecklist Checklist { get; set; }
        public virtual WmaMProject Project { get; set; }
    }
}
