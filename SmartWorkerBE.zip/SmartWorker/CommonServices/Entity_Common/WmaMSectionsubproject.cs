﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMSectionsubproject
    {
        public int SectionsubprojectidId { get; set; }
        public int SectionidId { get; set; }
        public int Masterprojectid { get; set; }
        public int Subprojectid { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
    }
}
