﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFWageWageprocesslog
    {
        public long Wagprocesslogid { get; set; }
        public int Projectid { get; set; }
        public DateTime Processingmonth { get; set; }
        public bool Status { get; set; }
        public string Remarks { get; set; }
        public DateTime Processstartdatetime { get; set; }
        public DateTime Processenddatetime { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }
        public int? Modifiedby { get; set; }
        public DateTime? Modifiedon { get; set; }
    }
}
