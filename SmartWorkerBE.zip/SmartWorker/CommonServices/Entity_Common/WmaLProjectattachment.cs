﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLProjectattachment
    {
        public WmaLProjectattachment()
        {
            WmaFNoticeboarddocumentsmaps = new HashSet<WmaFNoticeboarddocumentsmap>();
        }

        public int ProjectattachmentId { get; set; }
        public int? LicenseId { get; set; }
        public string ProjectattachmentnameVc { get; set; }
        public string ProjectattachmenturlVc { get; set; }
        public string ProjectattachmentformatVc { get; set; }
        public string ProjectattachmentcategoryVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? Isactive { get; set; }
        public int? ProjectId { get; set; }

        public virtual WmaMLicensetype License { get; set; }
        public virtual WmaMProject Project { get; set; }
        public virtual ICollection<WmaFNoticeboarddocumentsmap> WmaFNoticeboarddocumentsmaps { get; set; }
    }
}
