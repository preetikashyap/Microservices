﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaLWageZonemapping
    {
        public int Zonemappingid { get; set; }
        public int? Zoneid { get; set; }
        public int Typeofgovernmentid { get; set; }
        public int? Stateid { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }

        public virtual WmaMState State { get; set; }
        public virtual WmaLWageZonemapping Zonemapping { get; set; }
        public virtual WmaLWageZonemapping InverseZonemapping { get; set; }
    }
}
