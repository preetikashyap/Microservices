﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaFAwsrequestresponsedetail
    {
        public long AwsrequestresponsedetailId { get; set; }
        public long? WorkerId { get; set; }
        public string RequesttypeVc { get; set; }
        public string ApinameVc { get; set; }
        public string RequestcontentVc { get; set; }
        public string ResponsecontentVc { get; set; }
        public string ResponsestauscodeVc { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }

        public virtual WmaFWorkerdatum Worker { get; set; }
    }
}
