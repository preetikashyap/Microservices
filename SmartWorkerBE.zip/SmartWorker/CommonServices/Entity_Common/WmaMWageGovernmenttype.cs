﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageGovernmenttype
    {
        public int Typeofgovernmentid { get; set; }
        public string Typeofgovernment { get; set; }
        public int? Countryid { get; set; }
        public bool? Isactive { get; set; }
        public long? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
        public long? Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }

        public virtual WmaMCountry Country { get; set; }
    }
}
