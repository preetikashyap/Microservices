﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMWageSundayworkingtrademst
    {
        public long Id { get; set; }
        public int Tradeid { get; set; }
        public long Isactive { get; set; }
        public int? Createdby { get; set; }
        public DateTime? Createddate { get; set; }
    }
}
