﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMThirdpartyuser
    {
        public int CuserId { get; set; }
        public string UsernameVc { get; set; }
        public string PasswordVc { get; set; }
        public string CompanynameVc { get; set; }
        public string CompanycodeVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public DateTime? CreatedonDt { get; set; }
    }
}
