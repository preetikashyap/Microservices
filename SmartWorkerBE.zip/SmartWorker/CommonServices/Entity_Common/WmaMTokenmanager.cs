﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTokenmanager
    {
        public int TokenmanagerId { get; set; }
        public string TokenVc { get; set; }
        public DateTime? CreatedonDt { get; set; }
    }
}
