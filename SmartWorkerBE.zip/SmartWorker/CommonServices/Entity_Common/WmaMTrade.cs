﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTrade
    {
        public WmaMTrade()
        {
            WmaFWageWorkersitelevelcompdetails = new HashSet<WmaFWageWorkersitelevelcompdetail>();
            WmaLChecklistquestiongroupmaps = new HashSet<WmaLChecklistquestiongroupmap>();
            WmaLChecklisttraderoleapprovalmaps = new HashSet<WmaLChecklisttraderoleapprovalmap>();
            WmaLExperiences = new HashSet<WmaLExperience>();
            WmaLQuestiongrouptrademaps = new HashSet<WmaLQuestiongrouptrademap>();
            WmaLTraTrainingtrademaps = new HashSet<WmaLTraTrainingtrademap>();
            WmaLUsertradeapprovermaps = new HashSet<WmaLUsertradeapprovermap>();
            WmaLWorkerprojecttradedetails = new HashSet<WmaLWorkerprojecttradedetail>();
            WmaLWorkerprojecttradedetailshistories = new HashSet<WmaLWorkerprojecttradedetailshistory>();
            WmaMWageMinwages = new HashSet<WmaMWageMinwage>();
        }

        public int TradeId { get; set; }
        public string TradeVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string TradecodeVc { get; set; }
        public int? TradesubgroupId { get; set; }
        public int? TradegroupId { get; set; }
        public int? TradecategoryId { get; set; }
        public int? SkillmasterId { get; set; }

        public virtual ICollection<WmaFWageWorkersitelevelcompdetail> WmaFWageWorkersitelevelcompdetails { get; set; }
        public virtual ICollection<WmaLChecklistquestiongroupmap> WmaLChecklistquestiongroupmaps { get; set; }
        public virtual ICollection<WmaLChecklisttraderoleapprovalmap> WmaLChecklisttraderoleapprovalmaps { get; set; }
        public virtual ICollection<WmaLExperience> WmaLExperiences { get; set; }
        public virtual ICollection<WmaLQuestiongrouptrademap> WmaLQuestiongrouptrademaps { get; set; }
        public virtual ICollection<WmaLTraTrainingtrademap> WmaLTraTrainingtrademaps { get; set; }
        public virtual ICollection<WmaLUsertradeapprovermap> WmaLUsertradeapprovermaps { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetail> WmaLWorkerprojecttradedetails { get; set; }
        public virtual ICollection<WmaLWorkerprojecttradedetailshistory> WmaLWorkerprojecttradedetailshistories { get; set; }
        public virtual ICollection<WmaMWageMinwage> WmaMWageMinwages { get; set; }
    }
}
