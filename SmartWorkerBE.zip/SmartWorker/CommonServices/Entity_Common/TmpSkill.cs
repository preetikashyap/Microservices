﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class TmpSkill
    {
        public int Id { get; set; }
        public string Skillgroup { get; set; }
        public string Skillgroupdesc { get; set; }
        public string Skillsubgroupdesc { get; set; }
        public string Skilldescription { get; set; }
        public int Skillcode { get; set; }
        public string Skillcategory { get; set; }
    }
}
