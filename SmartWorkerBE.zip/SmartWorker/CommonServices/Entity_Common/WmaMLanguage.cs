﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMLanguage
    {
        public WmaMLanguage()
        {
            WmaFWorkerdata = new HashSet<WmaFWorkerdatum>();
        }

        public int LanguageId { get; set; }
        public string LanguageVc { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public int? CountryId { get; set; }

        public virtual ICollection<WmaFWorkerdatum> WmaFWorkerdata { get; set; }
    }
}
