﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMLeavetype
    {
        public WmaMLeavetype()
        {
            WmaFWorkerleavebalancehistories = new HashSet<WmaFWorkerleavebalancehistory>();
            WmaFWorkerleavebalances = new HashSet<WmaFWorkerleavebalance>();
            WmaFWorkerleavedetails = new HashSet<WmaFWorkerleavedetail>();
        }

        public int Id { get; set; }
        public string Leavename { get; set; }
        public string Leavecode { get; set; }

        public virtual ICollection<WmaFWorkerleavebalancehistory> WmaFWorkerleavebalancehistories { get; set; }
        public virtual ICollection<WmaFWorkerleavebalance> WmaFWorkerleavebalances { get; set; }
        public virtual ICollection<WmaFWorkerleavedetail> WmaFWorkerleavedetails { get; set; }
    }
}
