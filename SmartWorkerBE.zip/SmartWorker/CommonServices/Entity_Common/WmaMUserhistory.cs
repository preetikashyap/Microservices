﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMUserhistory
    {
        public long HistoryId { get; set; }
        public long UserId { get; set; }
        public string UsernameVc { get; set; }
        public long? EipuserId { get; set; }
        public string PsnoVc { get; set; }
        public bool? IslntemployeeBt { get; set; }
        public string LoginnameVc { get; set; }
        public string PasswordVc { get; set; }
        public string EmailidVc { get; set; }
        public long? MobilenoNb { get; set; }
        public bool? IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string CustomaccesstokenVc { get; set; }
        public string MedicalregidVc { get; set; }
        public string ClientipVc { get; set; }
        public DateTime? LastloginDt { get; set; }
        public int? WrongattemptNb { get; set; }
        public bool? IsaccountlockedBt { get; set; }
        public DateTime? MobilelastloginDt { get; set; }
        public DateTime? WeblastloginDt { get; set; }
        public string CountrycodeVc { get; set; }
        public short? ResetattemptNb { get; set; }
        public DateTime? LastresetonDt { get; set; }
        public DateTime? PasswordvalidityDt { get; set; }
        public string QuerystringVc { get; set; }
        public DateTime? QuerystringgeneratedonDt { get; set; }
    }
}
