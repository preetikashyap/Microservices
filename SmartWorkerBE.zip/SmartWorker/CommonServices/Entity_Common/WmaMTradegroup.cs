﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class WmaMTradegroup
    {
        public WmaMTradegroup()
        {
            WmaLUsertradeapprovermaps = new HashSet<WmaLUsertradeapprovermap>();
            WmaMTradesubgroups = new HashSet<WmaMTradesubgroup>();
        }

        public int TradegroupId { get; set; }
        public string TradegroupVc { get; set; }
        public bool IsactiveBt { get; set; }
        public int? CreatedbyId { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public string TradegroupcodeVc { get; set; }

        public virtual ICollection<WmaLUsertradeapprovermap> WmaLUsertradeapprovermaps { get; set; }
        public virtual ICollection<WmaMTradesubgroup> WmaMTradesubgroups { get; set; }
    }
}
