﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CommonServices.Entity_Common
{
    public partial class KycDummydoc
    {
        public int KycId { get; set; }
        public long? WorkerId { get; set; }
        public int? IdproofId { get; set; }
        public string IdproofvalueVc { get; set; }
        public DateTime? IssuedonDt { get; set; }
        public DateTime? ExpiryonDt { get; set; }
        public DateTime? CreatedonDt { get; set; }
        public int? CreatedbyId { get; set; }
        public int? ModifiedbyId { get; set; }
        public DateTime? ModifiedonDt { get; set; }
        public bool? IsactiveBt { get; set; }
    }
}
